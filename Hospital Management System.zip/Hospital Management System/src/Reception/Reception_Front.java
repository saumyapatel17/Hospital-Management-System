/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reception;
import hospital.management.system.HospitalManagementSystem;
import java.sql.*;
import java.lang.*;
import java.awt.CardLayout;
import Login.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.text.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import jdk.jfr.Period;
import net.proteanit.sql.DbUtils;
import com.email.durgesh.Email;
import java.awt.Font;
import java.awt.HeadlessException;
import java.io.UnsupportedEncodingException;
import javax.mail.MessagingException;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author HP
 */
public class Reception_Front extends HospitalManagementSystem{

    /**
     * Creates new form Reception_Front
     */
    
    CardLayout maincardlayout,cardlayout,labcardlayout,appointmentcardlayout,bedcardlayout,indoorpatientcardlayout,PDcardlayout,viewappointmentcardlayout,viewbedcardlayout,recordscardlayout;
    
    Statement stmt;
    PreparedStatement pstmt;
    Connection con;
    
    public Reception_Front() {
        con=DB_Link();
        initComponents();
        //patient db add patient 
        lblPDAddMandatory.setVisible(false);
        lblPDAddInvalidDate.setVisible(false);
        jcalPDAddDOB.setDateFormatString("dd-MM-yyyy");
        
        //Book Appointment
        lblBAppointmentMandatory.setVisible(false);
        lblBAppointmentMandatory1.setVisible(false);
        lblBAppointmentInvalidDate.setVisible(false);
        jcalADate.setDateFormatString("dd-MM-yyyy");
        
        //bed booking
        pnlBedRoomBooking.setVisible(false);
        pnlBedWardBooking.setVisible(false);
        cbBedRoom.setVisible(true);
        cbBedWard.setVisible(true);
        rbtnBedRoomAC.setSelected(true);
        rbtnBedWardAC.setSelected(true);
        tblBedWard.setVisible(false);
        spBedWard.setVisible(false);
        tblBedRoom.setVisible(false);
        spBedRoom.setVisible(false);
        btnBedWardProceed2Book.setVisible(false);
       lblBedWardBookingWarning.setVisible(false);
       btnBedRoomProceed2Book.setVisible(false);
       lblBedRoomBookingWarning.setVisible(false);
        
        //doctor db
        rbtnDDSearchName.setSelected(true);
        txtDDSearch.setVisible(true);
        
        //lab
        lblLabNewTestWarning.setVisible(false);
        
        //discharge
        lblDischargeWarning.setVisible(false);
        
        //indoor list view
        rbtnIndoorViewListName.setSelected(true);
        txtIndoorViewListSearch.setText("Patient Name");
        
        //indoor list view expand
        rbtnIndoorViewListNameExpand.setSelected(true);
        txtIndoorViewListSearchExpand.setText("Patient Name");
       
       //bed list
       rbtnViewBedRoomAll.setSelected(true);
       rbtnViewBedWardAll.setSelected(true);
       
       //bed list expand
       rbtnViewBedRoomAllExpand.setSelected(true);
       rbtnViewBedWardAllExpand.setSelected(true);
        
        
        //main cardlayout
        maincardlayout=(CardLayout)(pnlMainContainer.getLayout());
        maincardlayout.show(pnlMainContainer,"MainDashCard");

        //main dash cardlayout
        cardlayout=(CardLayout)(pnlRecepContentContainer.getLayout());
        cardlayout.show(pnlRecepContentContainer,"DashMainCard");
        
        //lab cardlayout
        labcardlayout=(CardLayout)(pnlLabContainer.getLayout());
        labcardlayout.show(pnlLabContainer,"NewTestCard");
        
        //appointment cardlayout
        appointmentcardlayout=(CardLayout)(pnlAppointmentContainer.getLayout());
        appointmentcardlayout.show(pnlAppointmentContainer,"AppointmentBookingCard");
        
        //indoor cardlayout
        indoorpatientcardlayout=(CardLayout)(pnlIndoorPatientContainer.getLayout());
        indoorpatientcardlayout.show(pnlIndoorPatientContainer,"IndoorPatientAdmitCard");
        
        //bed booking cardlayout
        bedcardlayout=(CardLayout)(pnlBedContainer.getLayout());
        bedcardlayout.show(pnlBedContainer,"BedWardCard");
        
        //patient db cardlayout
        PDcardlayout=(CardLayout)(pnlPDContainer.getLayout());
        PDcardlayout.show(pnlPDContainer,"PDAddCard");
        
        //bed list cardlayout
        viewbedcardlayout=(CardLayout)(pnlViewBedContainer.getLayout());
        viewbedcardlayout.show(pnlViewBedContainer,"ViewWardCard");
        
        //records cardlayout
        recordscardlayout=(CardLayout)(pnlRecordsContainer.getLayout());
        recordscardlayout.show(pnlRecordsContainer,"RecordLabCard");
      
        //main dashboard marks
        markRecords.setVisible(false);
        markDash.setVisible(true);
        markPD.setVisible(false);
        markSettings.setVisible(false);
        markHelp.setVisible(false);
        markRecords.setVisible(false);
        markDD.setVisible(false);
        
        // lab marks
        markLabNewTest.setVisible(true);
        
        
        //appointment marks
        markAppointmentBook.setVisible(true);
        markAppointmentView.setVisible(false);
        
        //bed booking marks
        markBedBookingWard.setVisible(true);
        markBedBookingRoom.setVisible(false);
        
        //indoor patient marks
        markAdmitPatient.setVisible(true);
        markIndoorList.setVisible(false);
        markDischargePatient.setVisible(false);
        
        //pd marks
        markAddPatient.setVisible(true);
        markPDConfirm.setVisible(false);
        markPdSearch.setVisible(false);
        
        //bed list marks
        markBedListWard.setVisible(true);
        markBedListRoom.setVisible(false);
        
        //records marks
        markRecordsConsultancy.setVisible(false);
        markRecordsIndoor.setVisible(false);
        markRecordsLab.setVisible(true);
        try{
        stmt=con.createStatement();
        
        
        //bed booking comboboxes
        ResultSet wardac=stmt.executeQuery("select distinct WARD_TYPE,WARD_CHARGES from WARD where AC_NONAC='A.C.'");
            cbBedWard.addItem("Select Ward Type");
            while(wardac.next())
            {
                cbBedWard.addItem(wardac.getString("WARD_TYPE"));
                
            }
            
        ResultSet roomac=stmt.executeQuery("select distinct ROOM_TYPE,ROOM_CHARGES from ROOM where AC_NONAC='A.C.'");
            cbBedRoom.addItem("Select Room Type");
            while(roomac.next())
            {
                cbBedRoom.addItem(roomac.getString("Room_TYPE"));
                
            }
            
            
        
        // pd add patient state combobox
        ResultSet rs=stmt.executeQuery("select distinct STATES from statewise_cities");
        cbPDAddState.addItem("Select State");
        while(rs.next())
        {
        cbPDAddState.addItem(rs.getString("STATES"));
        
        }
        
        
        //appointment specialisation combobox
        ResultSet rst=stmt.executeQuery("select distinct SPECIALISATION from DOCTOR_INFO");
        cbDepartment.addItem("Select Specialisation");
        while(rst.next())
        {
        cbDepartment.addItem(rst.getString("SPECIALISATION"));
        
        }
        
        
        //indoor patient admid doc-specialisation combobox
        ResultSet Doc_Ref=stmt.executeQuery("select NAME,SPECIALISATION from DOCTOR_INFO");
        jComboBox2.addItem("Select Doctor");
        while(Doc_Ref.next())
        {
        jComboBox2.addItem("Dr."+Doc_Ref.getString("NAME")+"-"+Doc_Ref.getString("SPECIALISATION"));
        
        }
        
        
        //pd search table
        ResultSet rstv=stmt.executeQuery("select PATIENT_ID,NAME,KIN,ADDRESS from PATIENT_INFO");
        tblPDSearch.setModel(DbUtils.resultSetToTableModel(rstv));
        tblPDSearch.setEnabled(false);
            customtable(tblPDSearch);
            
         //pd search table expand   
         ResultSet rstv_expand=stmt.executeQuery("select PATIENT_ID,NAME,KIN,ADDRESS from PATIENT_INFO");
        tblPDSearchExpand.setModel(DbUtils.resultSetToTableModel(rstv_expand));
        tblPDSearchExpand.setEnabled(false);
            customtable(tblPDSearchExpand);
        
            
         //dd search table
        ResultSet x=stmt.executeQuery("select NAME,SPECIALISATION,CONTACT,DOC_CHARGES from DOCTOR_INFO");
        tblDDSearch.setModel(DbUtils.resultSetToTableModel(x));
        tblDDSearch.setEnabled(false);
            customtable(tblDDSearch);
        
        
        //lab new test table    
         ResultSet lab_test=stmt.executeQuery("select LAB_TEST,LAB_CHARGES from LAB");
        tblLabNewTest.setModel(DbUtils.resultSetToTableModel(lab_test));
        tblLabNewTest.setRowSelectionAllowed(true);
        tblLabNewTest.setEnabled(true);
            customtable(tblLabNewTest);
        
            
         // indoor patient view table   
        ResultSet rstmt =stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR where DISCHARGE_DATE is null");
        jTable1.setModel(DbUtils.resultSetToTableModel(rstmt));
        jTable1.setEnabled(false);
            customtable(jTable1);
            
            
         // indoor patient view table expand  
        ResultSet rstmt_expand =stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR where DISCHARGE_DATE is null");
        jTable1Expand.setModel(DbUtils.resultSetToTableModel(rstmt_expand));
        jTable1Expand.setEnabled(false);
            customtable(jTable1Expand);
        
      
        //appointment search table
        ResultSet pat_search=stmt.executeQuery("select PATIENT_ID,NAME,CONTACT,SPECIALISATION,DOC_NAME,DATE,TIME from APPOINTMENTS_RECORD_TEMPORARY ");       
        tblAppointmentSearch.setModel(DbUtils.resultSetToTableModel(pat_search));
        tblAppointmentSearch.setEnabled(false);
            customtable(tblAppointmentSearch);
        
         //appointment search expand table   
        ResultSet pat_search_expand=stmt.executeQuery("select PATIENT_ID,NAME,CONTACT,SPECIALISATION,DOC_NAME,DATE,TIME from APPOINTMENTS_RECORD_TEMPORARY ");       
        tblAppointmentSearchExpand.setModel(DbUtils.resultSetToTableModel(pat_search_expand));
        tblAppointmentSearchExpand.setEnabled(false);
            customtable(tblAppointmentSearchExpand);    
            
        // view bed tables    
        ResultSet view_ward=stmt.executeQuery("select * from WARD");
        tblViewBedWard.setModel(DbUtils.resultSetToTableModel(view_ward));
            customtable(tblViewBedWard);
        
        ResultSet view_room=stmt.executeQuery("select * from ROOM");
        tblViewBedRoom.setModel(DbUtils.resultSetToTableModel(view_room));
            customtable(tblViewBedRoom);
            
        // view bed tables expand   
        ResultSet view_ward_expand=stmt.executeQuery("select * from WARD");
        tblViewBedWardExpand.setModel(DbUtils.resultSetToTableModel(view_ward_expand));
            customtable(tblViewBedWardExpand);
        
        ResultSet view_room_expand=stmt.executeQuery("select * from ROOM");
        tblViewBedRoomExpand.setModel(DbUtils.resultSetToTableModel(view_room_expand));
            customtable(tblViewBedRoomExpand);
        
            
        //confirmation table
        ResultSet pd_confirm=stmt.executeQuery("select NAME,KIN,GENDER,DOB,EMAIL,CONTACT,BG,ADDRESS,USERNAME from PATIENT_INFO_TEMPORARY");
        tblPDConfirm.setModel(DbUtils.resultSetToTableModel(pd_confirm));
            customtable(tblPDConfirm);
            
            
        //confirmation table expand
        ResultSet pd_confirm_expand=stmt.executeQuery("select NAME,KIN,GENDER,DOB,EMAIL,CONTACT,BG,ADDRESS,USERNAME from PATIENT_INFO_TEMPORARY");
        tblPDConfirmExpand.setModel(DbUtils.resultSetToTableModel(pd_confirm_expand));
            customtable(tblPDConfirmExpand);
            
            
            
         //records table + expand
                ResultSet B1=stmt.executeQuery("select BILL_NO,PATIENT_ID,NAME,CONSULTATION_CHARGES,UTILITY_CHARGES,SERVICE_CHARGES,TOTAL_AMT from INDOOR");
        tblRecordsIndoor.setModel(DbUtils.resultSetToTableModel(B1));
        tblRecordsIndoor.setEnabled(false);
            customtable(tblRecordsIndoor);
            ResultSet B12=stmt.executeQuery("select BILL_NO,PATIENT_ID,NAME,CONSULTATION_CHARGES,UTILITY_CHARGES,SERVICE_CHARGES,TOTAL_AMT from INDOOR");
        tblRecordsIndoorExpand.setModel(DbUtils.resultSetToTableModel(B12));
        tblRecordsIndoorExpand.setEnabled(false);
        customtable(tblRecordsIndoorExpand);
        
        
        ResultSet B2=stmt.executeQuery("select BILL_NO,PATIENT_ID,NAME,DOC_CHARGES,AMOUNT from APPOINTMENTS_RECORD");
        tblRecordsConsultancy.setModel(DbUtils.resultSetToTableModel(B2));
        tblRecordsConsultancy.setEnabled(false);
            customtable(tblRecordsConsultancy);
        ResultSet B22=stmt.executeQuery("select BILL_NO,PATIENT_ID,NAME,DOC_CHARGES,AMOUNT from APPOINTMENTS_RECORD");
        tblRecordsConsultancyExpand.setModel(DbUtils.resultSetToTableModel(B22));
        tblRecordsConsultancyExpand.setEnabled(false);
            customtable(tblRecordsConsultancyExpand);
        
        ResultSet B3=stmt.executeQuery("select * from LAB_BILL");
        tblRecordsLab.setModel(DbUtils.resultSetToTableModel(B3));
        tblRecordsLab.setEnabled(false);
            customtable(tblRecordsLab);
            ResultSet B31=stmt.executeQuery("select * from LAB_BILL");
        tblRecordsLabExpand.setModel(DbUtils.resultSetToTableModel(B31));
        tblRecordsLabExpand.setEnabled(false);
        customtable(tblRecordsLabExpand);
        
        }
        catch(SQLException e){
            e.getMessage();
        }

} 
      

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btngrpBedWardAC_NAC = new javax.swing.ButtonGroup();
        btngrpIndoorPatientViewListSort = new javax.swing.ButtonGroup();
        dateUtil1 = new com.toedter.calendar.DateUtil();
        minMaxDateEvaluator1 = new com.toedter.calendar.MinMaxDateEvaluator();
        btngrpDDSearchFilter = new javax.swing.ButtonGroup();
        btngrpViewBedWardrev_avlb = new javax.swing.ButtonGroup();
        btngrpViewBedRoomrev_avlb = new javax.swing.ButtonGroup();
        btngrpBedRoomAC_NAC = new javax.swing.ButtonGroup();
        pnlMainContainer = new javax.swing.JPanel();
        pnlMainDashContainer = new javax.swing.JPanel();
        kpnlRecepDash = new keeptoo.KGradientPanel();
        lblRecepFrontLogout = new javax.swing.JLabel();
        lblRecepFrontHelp = new javax.swing.JLabel();
        lblRecepFrontPDB = new javax.swing.JLabel();
        lblRecepFrontIcon = new javax.swing.JLabel();
        lblRecepFrontUname = new javax.swing.JLabel();
        lblRecepFrontDash = new javax.swing.JLabel();
        lblRecepFrontSetting = new javax.swing.JLabel();
        lblRecepFrontRecords = new javax.swing.JLabel();
        markSettings = new keeptoo.KGradientPanel();
        markDash = new keeptoo.KGradientPanel();
        markPD = new keeptoo.KGradientPanel();
        markRecords = new keeptoo.KGradientPanel();
        markHelp = new keeptoo.KGradientPanel();
        lblRecepFrontDDB = new javax.swing.JLabel();
        markDD = new keeptoo.KGradientPanel();
        pnlRecepContentContainer = new javax.swing.JPanel();
        pnlLabCard = new javax.swing.JPanel();
        kpnlLabMenuBar = new keeptoo.KGradientPanel();
        btnNewLabTest = new keeptoo.KButton();
        lblLabBack = new javax.swing.JLabel();
        markLabNewTest = new keeptoo.KGradientPanel();
        pnlLabContainer = new javax.swing.JPanel();
        pnlNewTest = new javax.swing.JPanel();
        lblNTestPatientID = new javax.swing.JLabel();
        txtNTestPatientID = new javax.swing.JTextField();
        lblNTestTest = new javax.swing.JLabel();
        btnNTestGenerateReciept = new keeptoo.KButton();
        txtLabNewTest = new javax.swing.JTextField();
        lblLabNewTestWarning = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblLabNewTest = new javax.swing.JTable();
        pnlLabRecieptContainer = new javax.swing.JPanel();
        pnlLabReciept = new javax.swing.JPanel();
        lblLabRecieptBillNoTag = new javax.swing.JLabel();
        lblLabRecieptLogo = new javax.swing.JLabel();
        lblLabRecieptBillNo = new javax.swing.JLabel();
        lblLabRecieptNameTag = new javax.swing.JLabel();
        lblLabRecieptName = new javax.swing.JLabel();
        lblLabRecieptKin = new javax.swing.JLabel();
        lblLabRecieptKinTag = new javax.swing.JLabel();
        lblLabRecieptAgeTag = new javax.swing.JLabel();
        lblLabRecieptAge = new javax.swing.JLabel();
        lblLabRecieptDateTag = new javax.swing.JLabel();
        lblLabRecieptSex = new javax.swing.JLabel();
        lblLabRecieptSexTag = new javax.swing.JLabel();
        lblLabRecieptDate = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        lblLabRecieptTestName = new javax.swing.JLabel();
        lblLabRecieptTestRate = new javax.swing.JLabel();
        lblLabRecieptSTax = new javax.swing.JLabel();
        lblLabRecieptCTax = new javax.swing.JLabel();
        lblLabRecieptAmountPaid = new javax.swing.JLabel();
        lblLabRecieptSTaxTag = new javax.swing.JLabel();
        lblLabRecieptCTaxTag = new javax.swing.JLabel();
        lblLabRecieptAmountPaidTag = new javax.swing.JLabel();
        lblLabRecieptRecepTag = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        lblLabRecieptPrintIcon = new javax.swing.JLabel();
        lblLabRecieptBackIcon = new javax.swing.JLabel();
        pnlDashMainCard = new javax.swing.JPanel();
        btnRecepFrontLab = new javax.swing.JButton();
        btnRecepFrontBed = new javax.swing.JButton();
        btnRecepFrontAppointment = new javax.swing.JButton();
        btnRecepFrontAdmitPatient = new javax.swing.JButton();
        pnlAppointmentCard = new javax.swing.JPanel();
        kpnlAppointmentMenuBar = new keeptoo.KGradientPanel();
        btnViewAppointment = new keeptoo.KButton();
        btnBookAppointment = new keeptoo.KButton();
        lblAppointmentBack = new javax.swing.JLabel();
        markAppointmentView = new keeptoo.KGradientPanel();
        markAppointmentBook = new keeptoo.KGradientPanel();
        pnlAppointmentContainer = new javax.swing.JPanel();
        pnlViewAppointment = new javax.swing.JPanel();
        txtViewAppointmentSearch = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblAppointmentSearch = new javax.swing.JTable();
        lblAppointmentViewExpand = new javax.swing.JLabel();
        pnlBAppointment = new javax.swing.JPanel();
        lblPatientID = new javax.swing.JLabel();
        txtPatientID = new javax.swing.JTextField();
        lblPhnNum = new javax.swing.JLabel();
        txtPhnNum = new javax.swing.JTextField();
        lblDepartment = new javax.swing.JLabel();
        cbDepartment = new javax.swing.JComboBox<>();
        lblDocName = new javax.swing.JLabel();
        cbDocName = new javax.swing.JComboBox<>();
        lblADate = new javax.swing.JLabel();
        jcalADate = new com.toedter.calendar.JDateChooser();
        lblATime = new javax.swing.JLabel();
        cbATime = new javax.swing.JComboBox<>();
        btnBAppointmentSubmit = new keeptoo.KButton();
        cbPhnNum = new javax.swing.JComboBox<>();
        lblBAppointmentMandatory = new javax.swing.JLabel();
        btnBAppointmentReset = new keeptoo.KButton();
        lblBAppointmentInvalidDate = new javax.swing.JLabel();
        pnlAppointmentRecieptContainer = new javax.swing.JPanel();
        pnlApointmentReciept = new javax.swing.JPanel();
        lblAppointmentRecieptBillNoTag = new javax.swing.JLabel();
        lblAppointmentRecieptLogo = new javax.swing.JLabel();
        lblAppointmentRecieptBillNo = new javax.swing.JLabel();
        lblAppointmentRecieptNameTag = new javax.swing.JLabel();
        lblAppointmentRecieptName = new javax.swing.JLabel();
        lblAppointmentRecieptKin = new javax.swing.JLabel();
        lblAppointmentRecieptKinTag = new javax.swing.JLabel();
        lblAppointmentRecieptAgeTag = new javax.swing.JLabel();
        lblAppointmentRecieptAge = new javax.swing.JLabel();
        lblAppointmentRecieptDateTag = new javax.swing.JLabel();
        lblAppointmentRecieptSex = new javax.swing.JLabel();
        lblAppointmentRecieptSexTag = new javax.swing.JLabel();
        lblAppointmentRecieptDate = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        lblAppointmentRecieptDocName = new javax.swing.JLabel();
        lblAppointmentRecieptConChrg = new javax.swing.JLabel();
        lblAppointmentRecieptSTax = new javax.swing.JLabel();
        lblAppointmentRecieptCTax = new javax.swing.JLabel();
        lblAppointmentRecieptAmountPaid = new javax.swing.JLabel();
        lblAppointmentRecieptSTaxTag = new javax.swing.JLabel();
        lblAppointmentRecieptCTaxTag = new javax.swing.JLabel();
        lblAppointmentRecieptAmountPaidTag = new javax.swing.JLabel();
        lblAppointmentRecieptRecepTag = new javax.swing.JLabel();
        lblAppointmentRecieptConChrgTag = new javax.swing.JLabel();
        lblAppointmentRecieptDocSpec = new javax.swing.JLabel();
        lblAppointmentRecieptAppointmentDate = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lblAppointmentRecieptPrintIcon = new javax.swing.JLabel();
        lblAppointmentRecieptBackIcon = new javax.swing.JLabel();
        pnlBedCard = new javax.swing.JPanel();
        kGradientPanel1 = new keeptoo.KGradientPanel();
        btnBedWard = new keeptoo.KButton();
        btnBedRoom = new keeptoo.KButton();
        lblBedBack = new javax.swing.JLabel();
        markBedBookingRoom = new keeptoo.KGradientPanel();
        markBedBookingWard = new keeptoo.KGradientPanel();
        pnlBedContainer = new javax.swing.JPanel();
        pnlBedWard = new javax.swing.JPanel();
        rbtnBedWardAC = new javax.swing.JRadioButton();
        rbtnBedWardNAC = new javax.swing.JRadioButton();
        lblBedWard1 = new javax.swing.JLabel();
        cbBedWard = new javax.swing.JComboBox<>();
        pnlBedWardBooking = new javax.swing.JPanel();
        lblBedWardBookingPatientID = new javax.swing.JLabel();
        txtBedWardBookingPatientID = new javax.swing.JTextField();
        lblBedWardBookingWardTypeTag = new javax.swing.JLabel();
        lblBedWardBookingBedNTag = new javax.swing.JLabel();
        lblBedWardBookingWardType = new javax.swing.JLabel();
        lblBedWardBookingBedN = new javax.swing.JLabel();
        btnBedWardBookingCancel = new keeptoo.KButton();
        btnBedWardBookingBook = new keeptoo.KButton();
        lblBedWardBookingWardNoTag = new javax.swing.JLabel();
        lblBedWardBookingWardN = new javax.swing.JLabel();
        lblBedWardBookingWarning = new javax.swing.JLabel();
        btnBedWardProceed2Book = new keeptoo.KButton();
        btnBedWardCheckAvail = new keeptoo.KButton();
        spBedWard = new javax.swing.JScrollPane();
        tblBedWard = new javax.swing.JTable();
        pnlBedRoom = new javax.swing.JPanel();
        rbtnBedRoomAC = new javax.swing.JRadioButton();
        rbtnBedRoomNAC = new javax.swing.JRadioButton();
        lblBedRoom1 = new javax.swing.JLabel();
        cbBedRoom = new javax.swing.JComboBox<>();
        spBedRoom = new javax.swing.JScrollPane();
        tblBedRoom = new javax.swing.JTable();
        btnBedRoomProceed2Book = new keeptoo.KButton();
        btnBedRoomCheckAvail = new keeptoo.KButton();
        pnlBedRoomBooking = new javax.swing.JPanel();
        lblBedRoomBookingPatientID = new javax.swing.JLabel();
        txtBedRoomBookingPatientID = new javax.swing.JTextField();
        lblBedRoomBookingRoomTypeTag = new javax.swing.JLabel();
        lblBedRoomBookingBedNTag = new javax.swing.JLabel();
        lblBedRoomBookingRoomType = new javax.swing.JLabel();
        lblBedRoomBookingBedN = new javax.swing.JLabel();
        btnBedRoomBookingCancel = new keeptoo.KButton();
        btnBedRoomBookingBook = new keeptoo.KButton();
        lblBedRoomBookingRoomNoTag = new javax.swing.JLabel();
        lblBedRoomBookingRoomN = new javax.swing.JLabel();
        lblBedRoomBookingWarning = new javax.swing.JLabel();
        pnlAddPatientCard = new javax.swing.JPanel();
        kGradientPanel2 = new keeptoo.KGradientPanel();
        lblAddPatientBack = new javax.swing.JLabel();
        btnAddPatientViewList = new keeptoo.KButton();
        btnAddPatientDischarge = new keeptoo.KButton();
        btnAddPatientAdmit = new keeptoo.KButton();
        markAdmitPatient = new keeptoo.KGradientPanel();
        markDischargePatient = new keeptoo.KGradientPanel();
        markIndoorList = new keeptoo.KGradientPanel();
        pnlIndoorPatientContainer = new javax.swing.JPanel();
        pnlIndoorPatientViewList = new javax.swing.JPanel();
        rbtnIndoorViewListID = new javax.swing.JRadioButton();
        rbtnIndoorViewListName = new javax.swing.JRadioButton();
        rbtnIndoorViewListDocRef = new javax.swing.JRadioButton();
        rbtnIndoorViewListR_W = new javax.swing.JRadioButton();
        txtIndoorViewListSearch = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        lblIndoorViewListExpand = new javax.swing.JLabel();
        pnlIndoorPatientDischarge = new javax.swing.JPanel();
        btnIndoorPatientDischargeGenerateBill = new keeptoo.KButton();
        txtIndoorPatientDischargePatientID = new javax.swing.JTextField();
        lblDischargeWarning = new javax.swing.JLabel();
        pnlIndoorPatientBillContainer = new javax.swing.JPanel();
        pnlIndoorBill = new javax.swing.JPanel();
        lblIndoorBilBillNoTag = new javax.swing.JLabel();
        lblIndoorBilLogo = new javax.swing.JLabel();
        lblIndoorBilBillNo = new javax.swing.JLabel();
        lblIndoorBilNameTag = new javax.swing.JLabel();
        lblIndoorBilName = new javax.swing.JLabel();
        lblIndoorBilKin = new javax.swing.JLabel();
        lblIndoorBilKinTag = new javax.swing.JLabel();
        lblIndoorBilAgeTag = new javax.swing.JLabel();
        lblIndoorBilAge = new javax.swing.JLabel();
        lblIndoorBilDateTag = new javax.swing.JLabel();
        lblIndoorBilSex = new javax.swing.JLabel();
        lblIndoorBilSexTag = new javax.swing.JLabel();
        lblIndoorBilDate = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        lblIndoorBilDocName = new javax.swing.JLabel();
        lblIndoorBilConChrg = new javax.swing.JLabel();
        lblIndoorBilRoomChrgTag = new javax.swing.JLabel();
        lblIndoorBilCTaxTag = new javax.swing.JLabel();
        lblIndoorBilAmountPaidTag = new javax.swing.JLabel();
        lblIndoorBilRecepTag = new javax.swing.JLabel();
        lblIndoorBilConChrgTag = new javax.swing.JLabel();
        lblIndoorBilDocSpec = new javax.swing.JLabel();
        lblIndoorBillAdmitDateTag = new javax.swing.JLabel();
        lblIndoorBilAdmitDate = new javax.swing.JLabel();
        lblIndoorBilDischargeDateTag = new javax.swing.JLabel();
        lblIndoorBilDischargeDate = new javax.swing.JLabel();
        lblIndoorBilDiseaseTag = new javax.swing.JLabel();
        lblIndoorBilDisease = new javax.swing.JLabel();
        lblIndoorBilTDays = new javax.swing.JLabel();
        lblIndoorBilTDaysTag = new javax.swing.JLabel();
        lblIndoorBilSTaxTag = new javax.swing.JLabel();
        lblIndoorBilSCTag = new javax.swing.JLabel();
        lblIndoorBilRoomChrg = new javax.swing.JLabel();
        lblIndoorBilSC = new javax.swing.JLabel();
        lblIndoorBilSTax = new javax.swing.JLabel();
        lblIndoorBilCTax = new javax.swing.JLabel();
        lblIndoorBilAmountPaid = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        lblIndoorBilPrintIcon = new javax.swing.JLabel();
        lblIndoorBilBackIcon = new javax.swing.JLabel();
        pnlIndoorPatientAdmit = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        btnIndoorPatientAdmitAdmit = new keeptoo.KButton();
        lblBAppointmentMandatory1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        pnlPDCard = new javax.swing.JPanel();
        kpnlPDMenuBar = new keeptoo.KGradientPanel();
        btnPDAddPatient = new keeptoo.KButton();
        btnPDConfirm = new keeptoo.KButton();
        lblPDBack = new javax.swing.JLabel();
        btnPDSearchDb1 = new keeptoo.KButton();
        markPDConfirm = new keeptoo.KGradientPanel();
        markPdSearch = new keeptoo.KGradientPanel();
        markAddPatient = new keeptoo.KGradientPanel();
        pnlPDContainer = new javax.swing.JPanel();
        pnlPDAdd = new javax.swing.JPanel();
        lblPDAddPatientNameTag = new javax.swing.JLabel();
        txtPDAddPatientName = new javax.swing.JTextField();
        lblPDAddKinTag = new javax.swing.JLabel();
        txtPDAddKin = new javax.swing.JTextField();
        cbPDAddGender = new javax.swing.JComboBox<>();
        lblPDAddGenderTag = new javax.swing.JLabel();
        lblPDAddDOBTag = new javax.swing.JLabel();
        jcalPDAddDOB = new com.toedter.calendar.JDateChooser();
        lblPDAddContactTag = new javax.swing.JLabel();
        txtPDAddContact = new javax.swing.JTextField();
        lblPDAddBloodGrpTag = new javax.swing.JLabel();
        cbPDAddBloodGrp = new javax.swing.JComboBox<>();
        lblPDAddStreetTag = new javax.swing.JLabel();
        txtPDAddStreet = new javax.swing.JTextField();
        lblPDAddStateTag = new javax.swing.JLabel();
        cbPDAddState = new javax.swing.JComboBox<>();
        cbPDAddCity = new javax.swing.JComboBox<>();
        lblPDAddCityTag = new javax.swing.JLabel();
        btnPDAddAddPatient = new keeptoo.KButton();
        lblPDAddMandatory = new javax.swing.JLabel();
        cbPDAddContact = new javax.swing.JComboBox<>();
        lblPDAddInvalidDate = new javax.swing.JLabel();
        pnlPDSearch = new javax.swing.JPanel();
        txtPDSearch = new javax.swing.JTextField();
        spPDSearch = new javax.swing.JScrollPane();
        tblPDSearch = new javax.swing.JTable();
        lblPDSearchExpand = new javax.swing.JLabel();
        pnlPDConfirm = new javax.swing.JPanel();
        spPDSearch1 = new javax.swing.JScrollPane();
        tblPDConfirm = new javax.swing.JTable();
        btnPDConfirmPatient = new keeptoo.KButton();
        lblPDConfirmExpand = new javax.swing.JLabel();
        pnlDDCard = new javax.swing.JPanel();
        txtDDSearch = new javax.swing.JTextField();
        spDDSearch = new javax.swing.JScrollPane();
        tblDDSearch = new javax.swing.JTable();
        kpnlDDtMenuBar = new keeptoo.KGradientPanel();
        lblDDBack = new javax.swing.JLabel();
        rbtnDDSearchName = new javax.swing.JRadioButton();
        rbtnDDSearchSpecialisation = new javax.swing.JRadioButton();
        pnlViewBedCard = new javax.swing.JPanel();
        kpnlViewBedMenuBar = new keeptoo.KGradientPanel();
        btnViewBedWard = new keeptoo.KButton();
        btnViewBedRoom = new keeptoo.KButton();
        lblViewBedBack = new javax.swing.JLabel();
        markBedListRoom = new keeptoo.KGradientPanel();
        markBedListWard = new keeptoo.KGradientPanel();
        pnlViewBedContainer = new javax.swing.JPanel();
        pnlViewBedRoom = new javax.swing.JPanel();
        rbtnViewBedRoomAvbl = new javax.swing.JRadioButton();
        rbtnViewBedRoomRev = new javax.swing.JRadioButton();
        txtViewBedRoomSearch = new javax.swing.JTextField();
        rbtnViewBedRoomAll = new javax.swing.JRadioButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblViewBedRoom = new javax.swing.JTable();
        lblViewBedRoomExpand = new javax.swing.JLabel();
        pnlViewBedWard = new javax.swing.JPanel();
        txtViewBedWardSearch = new javax.swing.JTextField();
        rbtnViewBedWardAvbl = new javax.swing.JRadioButton();
        rbtnViewBedWardRev = new javax.swing.JRadioButton();
        rbtnViewBedWardAll = new javax.swing.JRadioButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblViewBedWard = new javax.swing.JTable();
        lblViewBedWardExpand = new javax.swing.JLabel();
        pnlRecords = new javax.swing.JPanel();
        kGradientPanel3 = new keeptoo.KGradientPanel();
        lblRecordsBack = new javax.swing.JLabel();
        btnRecordsConsultancy = new keeptoo.KButton();
        btnRecordsIndoor = new keeptoo.KButton();
        btnRecordsLab = new keeptoo.KButton();
        markRecordsLab = new keeptoo.KGradientPanel();
        markRecordsIndoor = new keeptoo.KGradientPanel();
        markRecordsConsultancy = new keeptoo.KGradientPanel();
        pnlRecordsContainer = new javax.swing.JPanel();
        pnlRecordsLab = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblRecordsLab = new javax.swing.JTable();
        lblRecordsLabExpand = new javax.swing.JLabel();
        pnlRecordsConsultancy = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblRecordsConsultancy = new javax.swing.JTable();
        lblRecordsConsultancyExpand = new javax.swing.JLabel();
        pnlRecordsIndoor = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        tblRecordsIndoor = new javax.swing.JTable();
        lblRecordsIndoorExpand = new javax.swing.JLabel();
        pnlRecordsLabExpand = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        tblRecordsLabExpand = new javax.swing.JTable();
        lblRecordsLabCollasp = new javax.swing.JLabel();
        txtRecordsLabExpandSearch = new javax.swing.JTextField();
        pnlRecordsConsultancyExpand = new javax.swing.JPanel();
        jScrollPane10 = new javax.swing.JScrollPane();
        tblRecordsConsultancyExpand = new javax.swing.JTable();
        lblRecordsConsultancyCollasp = new javax.swing.JLabel();
        txtRecordsConsultancyExpandSearch = new javax.swing.JTextField();
        pnlRecordsIndoorExpand = new javax.swing.JPanel();
        jScrollPane11 = new javax.swing.JScrollPane();
        tblRecordsIndoorExpand = new javax.swing.JTable();
        lblRecordsIndoorCollasp = new javax.swing.JLabel();
        txtRecordsIndoorExpandSearch = new javax.swing.JTextField();
        pnlAppointmentViewExpand = new javax.swing.JPanel();
        txtViewAppointmentExpandSearch = new javax.swing.JTextField();
        jScrollPane12 = new javax.swing.JScrollPane();
        tblAppointmentSearchExpand = new javax.swing.JTable();
        lblViewAppointmentCollasp = new javax.swing.JLabel();
        pnlIndoorPatientViewExpand = new javax.swing.JPanel();
        rbtnIndoorViewListIDExpand = new javax.swing.JRadioButton();
        rbtnIndoorViewListNameExpand = new javax.swing.JRadioButton();
        rbtnIndoorViewListDocRefExpand = new javax.swing.JRadioButton();
        rbtnIndoorViewListR_WExpand = new javax.swing.JRadioButton();
        txtIndoorViewListSearchExpand = new javax.swing.JTextField();
        jScrollPane15 = new javax.swing.JScrollPane();
        jTable1Expand = new javax.swing.JTable();
        lblIndoorPatientViewCollasp = new javax.swing.JLabel();
        pnlBedWardViewExpand = new javax.swing.JPanel();
        txtViewBedWardSearchExpand = new javax.swing.JTextField();
        rbtnViewBedWardAvblExpand = new javax.swing.JRadioButton();
        rbtnViewBedWardRevExpand = new javax.swing.JRadioButton();
        rbtnViewBedWardAllExpand = new javax.swing.JRadioButton();
        jScrollPane13 = new javax.swing.JScrollPane();
        tblViewBedWardExpand = new javax.swing.JTable();
        lblBedWardViewCollasp = new javax.swing.JLabel();
        pnlBedRoomViewExpand = new javax.swing.JPanel();
        rbtnViewBedRoomAvblExpand = new javax.swing.JRadioButton();
        rbtnViewBedRoomRevExpand = new javax.swing.JRadioButton();
        txtViewBedRoomSearchExpand = new javax.swing.JTextField();
        rbtnViewBedRoomAllExpand = new javax.swing.JRadioButton();
        jScrollPane14 = new javax.swing.JScrollPane();
        tblViewBedRoomExpand = new javax.swing.JTable();
        lblBedRoomViewCollasp = new javax.swing.JLabel();
        pnlPDSearchExpand = new javax.swing.JPanel();
        spPDSearch2 = new javax.swing.JScrollPane();
        tblPDSearchExpand = new javax.swing.JTable();
        txtPDExpandSearch = new javax.swing.JTextField();
        lblPDSearchCollasp = new javax.swing.JLabel();
        pnlPDConfirmExpand = new javax.swing.JPanel();
        spPDSearch3 = new javax.swing.JScrollPane();
        tblPDConfirmExpand = new javax.swing.JTable();
        btnPDConfirmPatientExpand = new keeptoo.KButton();
        lblPDConfirmCollasp = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1080, 768));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnlMainContainer.setLayout(new java.awt.CardLayout());

        kpnlRecepDash.setForeground(new java.awt.Color(255, 255, 255));
        kpnlRecepDash.setkBorderRadius(0);
        kpnlRecepDash.setkEndColor(new java.awt.Color(153, 153, 255));
        kpnlRecepDash.setkStartColor(new java.awt.Color(0, 0, 51));
        kpnlRecepDash.setPreferredSize(new java.awt.Dimension(310, 768));
        kpnlRecepDash.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblRecepFrontLogout.setBackground(new java.awt.Color(145, 128, 238));
        lblRecepFrontLogout.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblRecepFrontLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblRecepFrontLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/log-out.png"))); // NOI18N
        lblRecepFrontLogout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRecepFrontLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecepFrontLogoutMouseClicked(evt);
            }
        });
        kpnlRecepDash.add(lblRecepFrontLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 50, 50));

        lblRecepFrontHelp.setBackground(new java.awt.Color(145, 128, 238));
        lblRecepFrontHelp.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblRecepFrontHelp.setForeground(new java.awt.Color(255, 255, 255));
        lblRecepFrontHelp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/help_icon.png"))); // NOI18N
        lblRecepFrontHelp.setText("Help and Support");
        lblRecepFrontHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRecepFrontHelp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecepFrontHelpMouseClicked(evt);
            }
        });
        kpnlRecepDash.add(lblRecepFrontHelp, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 690, 300, 50));

        lblRecepFrontPDB.setBackground(new java.awt.Color(145, 128, 238));
        lblRecepFrontPDB.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblRecepFrontPDB.setForeground(new java.awt.Color(255, 255, 255));
        lblRecepFrontPDB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/Patient_DBLogo.png"))); // NOI18N
        lblRecepFrontPDB.setText("Patient Database");
        lblRecepFrontPDB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRecepFrontPDB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecepFrontPDBMouseClicked(evt);
            }
        });
        kpnlRecepDash.add(lblRecepFrontPDB, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 300, 50));

        lblRecepFrontIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/reception_logo.png"))); // NOI18N
        kpnlRecepDash.add(lblRecepFrontIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 50, 200, 200));

        lblRecepFrontUname.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblRecepFrontUname.setForeground(new java.awt.Color(255, 255, 255));
        lblRecepFrontUname.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRecepFrontUname.setText("Reception");
        kpnlRecepDash.add(lblRecepFrontUname, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 240, 50));

        lblRecepFrontDash.setBackground(new java.awt.Color(145, 128, 238));
        lblRecepFrontDash.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblRecepFrontDash.setForeground(new java.awt.Color(255, 255, 255));
        lblRecepFrontDash.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/dashboard-icon.png"))); // NOI18N
        lblRecepFrontDash.setText("Dashboard");
        lblRecepFrontDash.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRecepFrontDash.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecepFrontDashMouseClicked(evt);
            }
        });
        kpnlRecepDash.add(lblRecepFrontDash, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 390, 300, 50));

        lblRecepFrontSetting.setBackground(new java.awt.Color(145, 128, 238));
        lblRecepFrontSetting.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblRecepFrontSetting.setForeground(new java.awt.Color(255, 255, 255));
        lblRecepFrontSetting.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/d88y06v-9bf586ed-3aa1-42b8-8ca5-343fc26843a2.png"))); // NOI18N
        lblRecepFrontSetting.setText("Settings and Privacy");
        lblRecepFrontSetting.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRecepFrontSetting.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecepFrontSettingMouseClicked(evt);
            }
        });
        kpnlRecepDash.add(lblRecepFrontSetting, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 630, 300, 50));

        lblRecepFrontRecords.setBackground(new java.awt.Color(145, 128, 238));
        lblRecepFrontRecords.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblRecepFrontRecords.setForeground(new java.awt.Color(255, 255, 255));
        lblRecepFrontRecords.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/records_icon_50px.png"))); // NOI18N
        lblRecepFrontRecords.setText("Records");
        lblRecepFrontRecords.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRecepFrontRecords.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecepFrontRecordsMouseClicked(evt);
            }
        });
        kpnlRecepDash.add(lblRecepFrontRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 570, 300, 50));

        markSettings.setkBorderRadius(20);
        markSettings.setkEndColor(new java.awt.Color(255, 255, 0));
        markSettings.setkGradientFocus(30);
        markSettings.setkStartColor(new java.awt.Color(255, 153, 0));
        markSettings.setOpaque(false);

        javax.swing.GroupLayout markSettingsLayout = new javax.swing.GroupLayout(markSettings);
        markSettings.setLayout(markSettingsLayout);
        markSettingsLayout.setHorizontalGroup(
            markSettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        markSettingsLayout.setVerticalGroup(
            markSettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        kpnlRecepDash.add(markSettings, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 630, 10, 50));

        markDash.setkBorderRadius(20);
        markDash.setkEndColor(new java.awt.Color(255, 255, 0));
        markDash.setkGradientFocus(30);
        markDash.setkStartColor(new java.awt.Color(255, 153, 0));
        markDash.setOpaque(false);

        javax.swing.GroupLayout markDashLayout = new javax.swing.GroupLayout(markDash);
        markDash.setLayout(markDashLayout);
        markDashLayout.setHorizontalGroup(
            markDashLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        markDashLayout.setVerticalGroup(
            markDashLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        kpnlRecepDash.add(markDash, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 390, 10, 50));

        markPD.setkBorderRadius(20);
        markPD.setkEndColor(new java.awt.Color(255, 255, 0));
        markPD.setkGradientFocus(30);
        markPD.setkStartColor(new java.awt.Color(255, 153, 0));
        markPD.setOpaque(false);

        javax.swing.GroupLayout markPDLayout = new javax.swing.GroupLayout(markPD);
        markPD.setLayout(markPDLayout);
        markPDLayout.setHorizontalGroup(
            markPDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        markPDLayout.setVerticalGroup(
            markPDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        kpnlRecepDash.add(markPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 450, 10, 50));

        markRecords.setkBorderRadius(20);
        markRecords.setkEndColor(new java.awt.Color(255, 255, 0));
        markRecords.setkGradientFocus(30);
        markRecords.setkStartColor(new java.awt.Color(255, 153, 0));
        markRecords.setOpaque(false);

        javax.swing.GroupLayout markRecordsLayout = new javax.swing.GroupLayout(markRecords);
        markRecords.setLayout(markRecordsLayout);
        markRecordsLayout.setHorizontalGroup(
            markRecordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        markRecordsLayout.setVerticalGroup(
            markRecordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        kpnlRecepDash.add(markRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 570, 10, 50));

        markHelp.setkBorderRadius(20);
        markHelp.setkEndColor(new java.awt.Color(255, 255, 0));
        markHelp.setkGradientFocus(30);
        markHelp.setkStartColor(new java.awt.Color(255, 153, 0));
        markHelp.setOpaque(false);

        javax.swing.GroupLayout markHelpLayout = new javax.swing.GroupLayout(markHelp);
        markHelp.setLayout(markHelpLayout);
        markHelpLayout.setHorizontalGroup(
            markHelpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        markHelpLayout.setVerticalGroup(
            markHelpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        kpnlRecepDash.add(markHelp, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 690, 10, 50));

        lblRecepFrontDDB.setBackground(new java.awt.Color(145, 128, 238));
        lblRecepFrontDDB.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblRecepFrontDDB.setForeground(new java.awt.Color(255, 255, 255));
        lblRecepFrontDDB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/doc_DBLogo.png"))); // NOI18N
        lblRecepFrontDDB.setText("Doctor Database");
        lblRecepFrontDDB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRecepFrontDDB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecepFrontDDBMouseClicked(evt);
            }
        });
        kpnlRecepDash.add(lblRecepFrontDDB, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 510, 300, 50));

        markDD.setkBorderRadius(20);
        markDD.setkEndColor(new java.awt.Color(255, 255, 0));
        markDD.setkGradientFocus(30);
        markDD.setkStartColor(new java.awt.Color(255, 153, 0));
        markDD.setOpaque(false);

        javax.swing.GroupLayout markDDLayout = new javax.swing.GroupLayout(markDD);
        markDD.setLayout(markDDLayout);
        markDDLayout.setHorizontalGroup(
            markDDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        markDDLayout.setVerticalGroup(
            markDDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        kpnlRecepDash.add(markDD, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 510, 10, 50));

        pnlRecepContentContainer.setLayout(new java.awt.CardLayout());

        pnlLabCard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kpnlLabMenuBar.setkBorderRadius(0);
        kpnlLabMenuBar.setkEndColor(new java.awt.Color(153, 153, 255));
        kpnlLabMenuBar.setkGradientFocus(800);
        kpnlLabMenuBar.setkStartColor(new java.awt.Color(0, 0, 51));
        kpnlLabMenuBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnNewLabTest.setText("New Test");
        btnNewLabTest.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnNewLabTest.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnNewLabTest.setkBorderRadius(15);
        btnNewLabTest.setkEndColor(new java.awt.Color(102, 255, 102));
        btnNewLabTest.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnNewLabTest.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnNewLabTest.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnNewLabTest.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnNewLabTest.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnNewLabTest.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnNewLabTest.setkStartColor(new java.awt.Color(0, 153, 0));
        btnNewLabTest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewLabTestActionPerformed(evt);
            }
        });
        kpnlLabMenuBar.add(btnNewLabTest, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 5, -1, 50));

        lblLabBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/uturn_icon_50.png"))); // NOI18N
        lblLabBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblLabBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLabBackMouseClicked(evt);
            }
        });
        kpnlLabMenuBar.add(lblLabBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 5, -1, -1));

        markLabNewTest.setkBorderRadius(20);
        markLabNewTest.setkEndColor(new java.awt.Color(255, 255, 0));
        markLabNewTest.setkGradientFocus(120);
        markLabNewTest.setkStartColor(new java.awt.Color(255, 153, 0));
        markLabNewTest.setOpaque(false);

        javax.swing.GroupLayout markLabNewTestLayout = new javax.swing.GroupLayout(markLabNewTest);
        markLabNewTest.setLayout(markLabNewTestLayout);
        markLabNewTestLayout.setHorizontalGroup(
            markLabNewTestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markLabNewTestLayout.setVerticalGroup(
            markLabNewTestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kpnlLabMenuBar.add(markLabNewTest, new org.netbeans.lib.awtextra.AbsoluteConstraints(285, 50, 180, 10));

        pnlLabCard.add(kpnlLabMenuBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 60));

        pnlLabContainer.setLayout(new java.awt.CardLayout());

        pnlNewTest.setBackground(new java.awt.Color(255, 255, 255));

        lblNTestPatientID.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblNTestPatientID.setText("Patient ID");

        txtNTestPatientID.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtNTestPatientID.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        lblNTestTest.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblNTestTest.setText("Test");

        btnNTestGenerateReciept.setText("Generate Receipt");
        btnNTestGenerateReciept.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnNTestGenerateReciept.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnNTestGenerateReciept.setkBorderRadius(15);
        btnNTestGenerateReciept.setkEndColor(new java.awt.Color(102, 255, 102));
        btnNTestGenerateReciept.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnNTestGenerateReciept.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnNTestGenerateReciept.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnNTestGenerateReciept.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnNTestGenerateReciept.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnNTestGenerateReciept.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnNTestGenerateReciept.setkStartColor(new java.awt.Color(0, 153, 0));
        btnNTestGenerateReciept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNTestGenerateRecieptActionPerformed(evt);
            }
        });

        txtLabNewTest.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtLabNewTest.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtLabNewTest.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtLabNewTestKeyReleased(evt);
            }
        });

        lblLabNewTestWarning.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblLabNewTestWarning.setForeground(new java.awt.Color(255, 0, 0));
        lblLabNewTestWarning.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLabNewTestWarning.setText("**All fields are mandatory**");

        jScrollPane4.setBackground(new java.awt.Color(255, 255, 255));

        tblLabNewTest.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane4.setViewportView(tblLabNewTest);

        javax.swing.GroupLayout pnlNewTestLayout = new javax.swing.GroupLayout(pnlNewTest);
        pnlNewTest.setLayout(pnlNewTestLayout);
        pnlNewTestLayout.setHorizontalGroup(
            pnlNewTestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlNewTestLayout.createSequentialGroup()
                .addGap(178, 178, 178)
                .addGroup(pnlNewTestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblNTestPatientID, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNTestTest, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addGroup(pnlNewTestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(txtNTestPatientID, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                    .addComponent(txtLabNewTest, javax.swing.GroupLayout.Alignment.LEADING))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlNewTestLayout.createSequentialGroup()
                .addContainerGap(188, Short.MAX_VALUE)
                .addGroup(pnlNewTestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlNewTestLayout.createSequentialGroup()
                        .addComponent(lblLabNewTestWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(203, 203, 203))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlNewTestLayout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(181, 181, 181))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlNewTestLayout.createSequentialGroup()
                        .addComponent(btnNTestGenerateReciept, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(253, 253, 253))))
        );
        pnlNewTestLayout.setVerticalGroup(
            pnlNewTestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlNewTestLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(pnlNewTestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtNTestPatientID, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNTestPatientID, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(pnlNewTestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNTestTest, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtLabNewTest, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnNTestGenerateReciept, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLabNewTestWarning)
                .addGap(30, 30, 30))
        );

        pnlLabContainer.add(pnlNewTest, "NewTestCard");

        pnlLabRecieptContainer.setBackground(new java.awt.Color(255, 255, 255));

        pnlLabReciept.setBackground(new java.awt.Color(255, 255, 255));
        pnlLabReciept.setBorder(new javax.swing.border.MatteBorder(null));
        pnlLabReciept.setOpaque(false);

        lblLabRecieptBillNoTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblLabRecieptBillNoTag.setText("Bill No.    :");

        lblLabRecieptLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/logo.png"))); // NOI18N

        lblLabRecieptBillNo.setBackground(new java.awt.Color(51, 0, 51));
        lblLabRecieptBillNo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblLabRecieptNameTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblLabRecieptNameTag.setText("Name      :");

        lblLabRecieptName.setBackground(new java.awt.Color(51, 0, 51));
        lblLabRecieptName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblLabRecieptKin.setBackground(new java.awt.Color(51, 0, 51));
        lblLabRecieptKin.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblLabRecieptKinTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblLabRecieptKinTag.setText("Kin          :");

        lblLabRecieptAgeTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblLabRecieptAgeTag.setText("Age         :");

        lblLabRecieptAge.setBackground(new java.awt.Color(51, 0, 51));
        lblLabRecieptAge.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblLabRecieptDateTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblLabRecieptDateTag.setText("Date        :");

        lblLabRecieptSex.setBackground(new java.awt.Color(51, 0, 51));
        lblLabRecieptSex.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblLabRecieptSexTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblLabRecieptSexTag.setText("Sex         :");

        lblLabRecieptDate.setBackground(new java.awt.Color(51, 0, 51));
        lblLabRecieptDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));

        lblLabRecieptTestName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        lblLabRecieptTestRate.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblLabRecieptTestRate.setText("jLabel42");
        lblLabRecieptTestRate.setBorder(new javax.swing.border.MatteBorder(null));

        lblLabRecieptSTax.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblLabRecieptSTax.setText("jLabel43");
        lblLabRecieptSTax.setBorder(new javax.swing.border.MatteBorder(null));

        lblLabRecieptCTax.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblLabRecieptCTax.setText("jLabel43");
        lblLabRecieptCTax.setBorder(new javax.swing.border.MatteBorder(null));

        lblLabRecieptAmountPaid.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblLabRecieptAmountPaid.setText("jLabel43");
        lblLabRecieptAmountPaid.setBorder(new javax.swing.border.MatteBorder(null));

        lblLabRecieptSTaxTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblLabRecieptSTaxTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblLabRecieptSTaxTag.setText("State GST 9%");

        lblLabRecieptCTaxTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblLabRecieptCTaxTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblLabRecieptCTaxTag.setText("Central GST 9%");

        lblLabRecieptAmountPaidTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblLabRecieptAmountPaidTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblLabRecieptAmountPaidTag.setText("Total Amount Paid");

        lblLabRecieptRecepTag.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblLabRecieptRecepTag.setText("Receptionist");

        jLabel8.setFont(new java.awt.Font("MS UI Gothic", 1, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("UPSN HOSPITALS");

        jLabel9.setFont(new java.awt.Font("MS UI Gothic", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 102));
        jLabel9.setText("(A unit of UPSN Medical & Research Centre Pvt. Ltd.)");

        jLabel10.setFont(new java.awt.Font("MS UI Gothic", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 102));
        jLabel10.setText("Sector - 10, Near Mahindra SEZ, Ajmer Road, Mahapura, Rajasthan, 302026");

        jLabel14.setFont(new java.awt.Font("MS UI Gothic", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 102));
        jLabel14.setText("Tel. : 1234567 * Fax : 0011-1234567 * Email : support@upsnhospitals.in");

        jLabel15.setFont(new java.awt.Font("MS UI Gothic", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 102));
        jLabel15.setText("CIN No. X00000YZ1111JKL333333");

        javax.swing.GroupLayout pnlLabRecieptLayout = new javax.swing.GroupLayout(pnlLabReciept);
        pnlLabReciept.setLayout(pnlLabRecieptLayout);
        pnlLabRecieptLayout.setHorizontalGroup(
            pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLabRecieptLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(lblLabRecieptNameTag, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(lblLabRecieptName, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(298, 298, 298)
                .addComponent(lblLabRecieptDateTag, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(lblLabRecieptDate, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pnlLabRecieptLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(lblLabRecieptKinTag)
                .addGap(10, 10, 10)
                .addComponent(lblLabRecieptKin, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(298, 298, 298)
                .addComponent(lblLabRecieptSexTag, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(lblLabRecieptSex, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 748, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(pnlLabRecieptLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(lblLabRecieptTestName, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(196, 196, 196)
                .addComponent(lblLabRecieptTestRate, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pnlLabRecieptLayout.createSequentialGroup()
                .addGap(449, 449, 449)
                .addComponent(lblLabRecieptSTaxTag, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(lblLabRecieptSTax, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pnlLabRecieptLayout.createSequentialGroup()
                .addGap(557, 557, 557)
                .addComponent(lblLabRecieptRecepTag, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pnlLabRecieptLayout.createSequentialGroup()
                .addGap(420, 420, 420)
                .addGroup(pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblLabRecieptAmountPaidTag)
                    .addComponent(lblLabRecieptCTaxTag))
                .addGap(22, 22, 22)
                .addGroup(pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblLabRecieptCTax, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLabRecieptAmountPaid, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(pnlLabRecieptLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlLabRecieptLayout.createSequentialGroup()
                        .addComponent(lblLabRecieptBillNoTag)
                        .addGap(10, 10, 10)
                        .addComponent(lblLabRecieptBillNo, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(388, 388, 388)
                        .addComponent(lblLabRecieptAgeTag)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblLabRecieptAge, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlLabRecieptLayout.createSequentialGroup()
                        .addComponent(lblLabRecieptLogo)
                        .addGap(75, 75, 75)
                        .addGroup(pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
        );
        pnlLabRecieptLayout.setVerticalGroup(
            pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLabRecieptLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLabRecieptLogo)
                    .addGroup(pnlLabRecieptLayout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel10)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel15)
                .addGap(30, 30, 30)
                .addGroup(pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLabRecieptBillNoTag)
                    .addComponent(lblLabRecieptBillNo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLabRecieptAgeTag)
                    .addComponent(lblLabRecieptAge, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLabRecieptNameTag)
                    .addComponent(lblLabRecieptName, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLabRecieptDateTag)
                    .addComponent(lblLabRecieptDate, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLabRecieptKinTag)
                    .addComponent(lblLabRecieptKin, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLabRecieptSexTag)
                    .addComponent(lblLabRecieptSex, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addGroup(pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLabRecieptTestName, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLabRecieptTestRate, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLabRecieptSTaxTag, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLabRecieptSTax, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLabRecieptCTaxTag, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLabRecieptCTax, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlLabRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLabRecieptAmountPaidTag, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLabRecieptAmountPaid, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                .addComponent(lblLabRecieptRecepTag, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        lblLabRecieptPrintIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_print_64_64.png"))); // NOI18N
        lblLabRecieptPrintIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLabRecieptPrintIconMouseClicked(evt);
            }
        });

        lblLabRecieptBackIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_undo_black_64.png"))); // NOI18N
        lblLabRecieptBackIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblLabRecieptBackIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLabRecieptBackIconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlLabRecieptContainerLayout = new javax.swing.GroupLayout(pnlLabRecieptContainer);
        pnlLabRecieptContainer.setLayout(pnlLabRecieptContainerLayout);
        pnlLabRecieptContainerLayout.setHorizontalGroup(
            pnlLabRecieptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLabRecieptContainerLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(pnlLabRecieptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlLabReciept, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pnlLabRecieptContainerLayout.createSequentialGroup()
                        .addComponent(lblLabRecieptPrintIcon)
                        .addGap(636, 636, 636)
                        .addComponent(lblLabRecieptBackIcon)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pnlLabRecieptContainerLayout.setVerticalGroup(
            pnlLabRecieptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLabRecieptContainerLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(pnlLabRecieptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLabRecieptPrintIcon)
                    .addComponent(lblLabRecieptBackIcon))
                .addGap(40, 40, 40)
                .addComponent(pnlLabReciept, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pnlLabContainer.add(pnlLabRecieptContainer, "LabRecieptCard");

        pnlLabCard.add(pnlLabContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 770, 710));

        pnlRecepContentContainer.add(pnlLabCard, "LabCard");

        pnlDashMainCard.setBackground(new java.awt.Color(255, 255, 255));
        pnlDashMainCard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnRecepFrontLab.setBackground(new java.awt.Color(255, 255, 255));
        btnRecepFrontLab.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnRecepFrontLab.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/Lab_icon_250px.jpg"))); // NOI18N
        btnRecepFrontLab.setText("Lab");
        btnRecepFrontLab.setBorder(null);
        btnRecepFrontLab.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRecepFrontLab.setOpaque(false);
        btnRecepFrontLab.setPreferredSize(new java.awt.Dimension(250, 250));
        btnRecepFrontLab.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        btnRecepFrontLab.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnRecepFrontLab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecepFrontLabActionPerformed(evt);
            }
        });
        pnlDashMainCard.add(btnRecepFrontLab, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 460, 250, 250));

        btnRecepFrontBed.setBackground(new java.awt.Color(255, 255, 255));
        btnRecepFrontBed.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnRecepFrontBed.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/Patient_Bed_250px.jpg"))); // NOI18N
        btnRecepFrontBed.setText("Bed");
        btnRecepFrontBed.setBorder(null);
        btnRecepFrontBed.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRecepFrontBed.setOpaque(false);
        btnRecepFrontBed.setPreferredSize(new java.awt.Dimension(250, 250));
        btnRecepFrontBed.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        btnRecepFrontBed.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnRecepFrontBed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecepFrontBedActionPerformed(evt);
            }
        });
        pnlDashMainCard.add(btnRecepFrontBed, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 450, 250, 250));

        btnRecepFrontAppointment.setBackground(new java.awt.Color(255, 255, 255));
        btnRecepFrontAppointment.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnRecepFrontAppointment.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/Appointment icon 250px.png"))); // NOI18N
        btnRecepFrontAppointment.setText("Book Appointment");
        btnRecepFrontAppointment.setBorder(null);
        btnRecepFrontAppointment.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRecepFrontAppointment.setOpaque(false);
        btnRecepFrontAppointment.setPreferredSize(new java.awt.Dimension(250, 250));
        btnRecepFrontAppointment.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        btnRecepFrontAppointment.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnRecepFrontAppointment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecepFrontAppointmentActionPerformed(evt);
            }
        });
        pnlDashMainCard.add(btnRecepFrontAppointment, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, 250, 250));

        btnRecepFrontAdmitPatient.setBackground(new java.awt.Color(255, 255, 255));
        btnRecepFrontAdmitPatient.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnRecepFrontAdmitPatient.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/Add_Patient_250px.jpg"))); // NOI18N
        btnRecepFrontAdmitPatient.setText("Admit Patient");
        btnRecepFrontAdmitPatient.setBorder(null);
        btnRecepFrontAdmitPatient.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRecepFrontAdmitPatient.setOpaque(false);
        btnRecepFrontAdmitPatient.setPreferredSize(new java.awt.Dimension(250, 250));
        btnRecepFrontAdmitPatient.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        btnRecepFrontAdmitPatient.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnRecepFrontAdmitPatient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecepFrontAdmitPatientActionPerformed(evt);
            }
        });
        pnlDashMainCard.add(btnRecepFrontAdmitPatient, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 50, 250, 250));

        pnlRecepContentContainer.add(pnlDashMainCard, "DashMainCard");

        pnlAppointmentCard.setBackground(new java.awt.Color(255, 255, 255));
        pnlAppointmentCard.setPreferredSize(new java.awt.Dimension(770, 768));
        pnlAppointmentCard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kpnlAppointmentMenuBar.setkBorderRadius(0);
        kpnlAppointmentMenuBar.setkEndColor(new java.awt.Color(153, 153, 255));
        kpnlAppointmentMenuBar.setkGradientFocus(800);
        kpnlAppointmentMenuBar.setkStartColor(new java.awt.Color(0, 0, 51));
        kpnlAppointmentMenuBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnViewAppointment.setText("View");
        btnViewAppointment.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnViewAppointment.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnViewAppointment.setkBorderRadius(15);
        btnViewAppointment.setkEndColor(new java.awt.Color(102, 255, 102));
        btnViewAppointment.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnViewAppointment.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnViewAppointment.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnViewAppointment.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnViewAppointment.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnViewAppointment.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnViewAppointment.setkStartColor(new java.awt.Color(0, 153, 0));
        btnViewAppointment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAppointmentActionPerformed(evt);
            }
        });
        kpnlAppointmentMenuBar.add(btnViewAppointment, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 5, -1, 50));

        btnBookAppointment.setText("Book");
        btnBookAppointment.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBookAppointment.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBookAppointment.setkBorderRadius(15);
        btnBookAppointment.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBookAppointment.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBookAppointment.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBookAppointment.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBookAppointment.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBookAppointment.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBookAppointment.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBookAppointment.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBookAppointment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBookAppointmentActionPerformed(evt);
            }
        });
        kpnlAppointmentMenuBar.add(btnBookAppointment, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 5, -1, 50));

        lblAppointmentBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/uturn_icon_50.png"))); // NOI18N
        lblAppointmentBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblAppointmentBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAppointmentBackMouseClicked(evt);
            }
        });
        kpnlAppointmentMenuBar.add(lblAppointmentBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 5, -1, -1));

        markAppointmentView.setkBorderRadius(20);
        markAppointmentView.setkEndColor(new java.awt.Color(255, 255, 0));
        markAppointmentView.setkGradientFocus(120);
        markAppointmentView.setkStartColor(new java.awt.Color(255, 153, 0));
        markAppointmentView.setOpaque(false);

        javax.swing.GroupLayout markAppointmentViewLayout = new javax.swing.GroupLayout(markAppointmentView);
        markAppointmentView.setLayout(markAppointmentViewLayout);
        markAppointmentViewLayout.setHorizontalGroup(
            markAppointmentViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markAppointmentViewLayout.setVerticalGroup(
            markAppointmentViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kpnlAppointmentMenuBar.add(markAppointmentView, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 50, 180, 10));

        markAppointmentBook.setkBorderRadius(20);
        markAppointmentBook.setkEndColor(new java.awt.Color(255, 255, 0));
        markAppointmentBook.setkGradientFocus(120);
        markAppointmentBook.setkStartColor(new java.awt.Color(255, 153, 0));
        markAppointmentBook.setOpaque(false);

        javax.swing.GroupLayout markAppointmentBookLayout = new javax.swing.GroupLayout(markAppointmentBook);
        markAppointmentBook.setLayout(markAppointmentBookLayout);
        markAppointmentBookLayout.setHorizontalGroup(
            markAppointmentBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markAppointmentBookLayout.setVerticalGroup(
            markAppointmentBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kpnlAppointmentMenuBar.add(markAppointmentBook, new org.netbeans.lib.awtextra.AbsoluteConstraints(293, 50, 180, 10));

        pnlAppointmentCard.add(kpnlAppointmentMenuBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 60));

        pnlAppointmentContainer.setLayout(new java.awt.CardLayout());

        pnlViewAppointment.setBackground(new java.awt.Color(255, 255, 255));
        pnlViewAppointment.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtViewAppointmentSearch.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtViewAppointmentSearch.setText("Patient ID or Doctor Name");
        txtViewAppointmentSearch.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtViewAppointmentSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtViewAppointmentSearchMouseClicked(evt);
            }
        });
        txtViewAppointmentSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtViewAppointmentSearchActionPerformed(evt);
            }
        });
        txtViewAppointmentSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtViewAppointmentSearchKeyReleased(evt);
            }
        });
        pnlViewAppointment.add(txtViewAppointmentSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 70, 300, -1));

        tblAppointmentSearch.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(tblAppointmentSearch);

        pnlViewAppointment.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 750, 550));

        lblAppointmentViewExpand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_expand_40px.png"))); // NOI18N
        lblAppointmentViewExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAppointmentViewExpandMouseClicked(evt);
            }
        });
        pnlViewAppointment.add(lblAppointmentViewExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 20, -1, -1));

        pnlAppointmentContainer.add(pnlViewAppointment, "ViewAppointmentCard");

        pnlBAppointment.setBackground(new java.awt.Color(255, 255, 255));

        lblPatientID.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPatientID.setText("Patient ID");

        txtPatientID.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtPatientID.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtPatientID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPatientIDActionPerformed(evt);
            }
        });

        lblPhnNum.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPhnNum.setText("Phone Number: ");
        lblPhnNum.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentMoved(java.awt.event.ComponentEvent evt) {
                lblPhnNumComponentMoved(evt);
            }
        });

        txtPhnNum.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtPhnNum.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtPhnNum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPhnNumActionPerformed(evt);
            }
        });

        lblDepartment.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblDepartment.setText("Department");

        cbDepartment.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbDepartment.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbDepartmentItemStateChanged(evt);
            }
        });

        lblDocName.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblDocName.setText("Docter Name: ");

        cbDocName.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbDocName.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Doctor" }));
        cbDocName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbDocNameActionPerformed(evt);
            }
        });

        lblADate.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblADate.setText("Date of Appointment");

        jcalADate.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N

        lblATime.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblATime.setText("Time of Appointment");

        cbATime.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbATime.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Time", "10:00AM - 11:00AM", "12:00PM - 01:00PM", "04:00PM - 05:00PM", "07:00PM - 08:00PM" }));
        cbATime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbATimeActionPerformed(evt);
            }
        });

        btnBAppointmentSubmit.setText("Submit");
        btnBAppointmentSubmit.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBAppointmentSubmit.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBAppointmentSubmit.setkBorderRadius(15);
        btnBAppointmentSubmit.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBAppointmentSubmit.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBAppointmentSubmit.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBAppointmentSubmit.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBAppointmentSubmit.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBAppointmentSubmit.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBAppointmentSubmit.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBAppointmentSubmit.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBAppointmentSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBAppointmentSubmitActionPerformed(evt);
            }
        });

        cbPhnNum.setEditable(true);
        cbPhnNum.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        cbPhnNum.setForeground(new java.awt.Color(255, 255, 255));
        cbPhnNum.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "+91", "+43", "+32", "+359", "+385", "+357", "+420", "+33", "+49", "+39", "+47", "+34", "+44" }));
        cbPhnNum.setBorder(null);
        cbPhnNum.setDoubleBuffered(true);
        cbPhnNum.setOpaque(false);
        cbPhnNum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPhnNumActionPerformed(evt);
            }
        });

        lblBAppointmentMandatory.setBackground(new java.awt.Color(255, 255, 255));
        lblBAppointmentMandatory.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblBAppointmentMandatory.setForeground(new java.awt.Color(255, 0, 0));
        lblBAppointmentMandatory.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBAppointmentMandatory.setText("**All fields are mandatory**");

        btnBAppointmentReset.setText("Reset");
        btnBAppointmentReset.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBAppointmentReset.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBAppointmentReset.setkBorderRadius(15);
        btnBAppointmentReset.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBAppointmentReset.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBAppointmentReset.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBAppointmentReset.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBAppointmentReset.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBAppointmentReset.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBAppointmentReset.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBAppointmentReset.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBAppointmentReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBAppointmentResetActionPerformed(evt);
            }
        });

        lblBAppointmentInvalidDate.setBackground(new java.awt.Color(255, 255, 255));
        lblBAppointmentInvalidDate.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblBAppointmentInvalidDate.setForeground(new java.awt.Color(255, 0, 0));
        lblBAppointmentInvalidDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBAppointmentInvalidDate.setText("**Invalid Date of Appointment**");

        javax.swing.GroupLayout pnlBAppointmentLayout = new javax.swing.GroupLayout(pnlBAppointment);
        pnlBAppointment.setLayout(pnlBAppointmentLayout);
        pnlBAppointmentLayout.setHorizontalGroup(
            pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addComponent(lblATime)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cbATime, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(125, 125, 125))
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                                .addComponent(lblDocName)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cbDocName, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                                .addComponent(lblPatientID)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtPatientID, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                                .addComponent(lblPhnNum)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                                .addComponent(cbPhnNum, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtPhnNum, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                                .addComponent(lblDepartment)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cbDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(71, 71, 71))))
            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addComponent(btnBAppointmentSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(111, 111, 111)
                        .addComponent(btnBAppointmentReset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addGap(275, 275, 275)
                        .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblADate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jcalADate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addGap(247, 247, 247)
                        .addComponent(lblBAppointmentMandatory, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addGap(218, 218, 218)
                        .addComponent(lblBAppointmentInvalidDate, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlBAppointmentLayout.setVerticalGroup(
            pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblPatientID)
                    .addComponent(txtPatientID, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtPhnNum, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cbPhnNum, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblPhnNum))
                .addGap(26, 26, 26)
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cbDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDepartment))
                .addGap(27, 27, 27)
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cbDocName, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDocName))
                .addGap(18, 18, 18)
                .addComponent(lblADate)
                .addGap(18, 18, 18)
                .addComponent(jcalADate, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblATime)
                    .addComponent(cbATime, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(70, 70, 70)
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBAppointmentSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBAppointmentReset, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addComponent(lblBAppointmentMandatory)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblBAppointmentInvalidDate)
                .addGap(30, 30, 30))
        );

        pnlAppointmentContainer.add(pnlBAppointment, "AppointmentBookingCard");

        pnlApointmentReciept.setBackground(new java.awt.Color(255, 255, 255));
        pnlApointmentReciept.setBorder(new javax.swing.border.MatteBorder(null));

        lblAppointmentRecieptBillNoTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblAppointmentRecieptBillNoTag.setText("Bill No.    :");

        lblAppointmentRecieptLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/logo.png"))); // NOI18N

        lblAppointmentRecieptBillNo.setBackground(new java.awt.Color(51, 0, 51));
        lblAppointmentRecieptBillNo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblAppointmentRecieptNameTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblAppointmentRecieptNameTag.setText("Name      :");

        lblAppointmentRecieptName.setBackground(new java.awt.Color(51, 0, 51));
        lblAppointmentRecieptName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblAppointmentRecieptKin.setBackground(new java.awt.Color(51, 0, 51));
        lblAppointmentRecieptKin.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblAppointmentRecieptKinTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblAppointmentRecieptKinTag.setText("Kin          :");

        lblAppointmentRecieptAgeTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblAppointmentRecieptAgeTag.setText("Age         :");

        lblAppointmentRecieptAge.setBackground(new java.awt.Color(51, 0, 51));
        lblAppointmentRecieptAge.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblAppointmentRecieptDateTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblAppointmentRecieptDateTag.setText("Date        :");

        lblAppointmentRecieptSex.setBackground(new java.awt.Color(51, 0, 51));
        lblAppointmentRecieptSex.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblAppointmentRecieptSexTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblAppointmentRecieptSexTag.setText("Sex         :");

        lblAppointmentRecieptDate.setBackground(new java.awt.Color(51, 0, 51));
        lblAppointmentRecieptDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));

        lblAppointmentRecieptDocName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        lblAppointmentRecieptConChrg.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        lblAppointmentRecieptSTax.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        lblAppointmentRecieptCTax.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        lblAppointmentRecieptAmountPaid.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        lblAppointmentRecieptSTaxTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblAppointmentRecieptSTaxTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblAppointmentRecieptSTaxTag.setText("State GST 9%");

        lblAppointmentRecieptCTaxTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblAppointmentRecieptCTaxTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblAppointmentRecieptCTaxTag.setText("Central GST 9%");

        lblAppointmentRecieptAmountPaidTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblAppointmentRecieptAmountPaidTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblAppointmentRecieptAmountPaidTag.setText("Total Amount Paid");

        lblAppointmentRecieptRecepTag.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblAppointmentRecieptRecepTag.setText("Receptionist");

        lblAppointmentRecieptConChrgTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblAppointmentRecieptConChrgTag.setText("Consultation Charges");

        lblAppointmentRecieptDocSpec.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        lblAppointmentRecieptAppointmentDate.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        jLabel3.setFont(new java.awt.Font("MS UI Gothic", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 102));
        jLabel3.setText("UPSN HOSPITALS");

        jLabel4.setFont(new java.awt.Font("MS UI Gothic", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 102));
        jLabel4.setText("(A unit of UPSN Medical & Research Centre Pvt. Ltd.)");

        jLabel5.setFont(new java.awt.Font("MS UI Gothic", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("Sector - 10, Near Mahindra SEZ, Ajmer Road, Mahapura, Rajasthan, 302026");

        jLabel6.setFont(new java.awt.Font("MS UI Gothic", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("Tel. : 1234567 * Fax : 0011-1234567 * Email : support@upsnhospitals.in");

        jLabel7.setFont(new java.awt.Font("MS UI Gothic", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("CIN No. X00000YZ1111JKL333333");

        javax.swing.GroupLayout pnlApointmentRecieptLayout = new javax.swing.GroupLayout(pnlApointmentReciept);
        pnlApointmentReciept.setLayout(pnlApointmentRecieptLayout);
        pnlApointmentRecieptLayout.setHorizontalGroup(
            pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator2)
            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptBillNoTag)
                        .addGap(10, 10, 10)
                        .addComponent(lblAppointmentRecieptBillNo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlApointmentRecieptLayout.createSequentialGroup()
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblAppointmentRecieptNameTag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblAppointmentRecieptKinTag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblAppointmentRecieptKin, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlApointmentRecieptLayout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(lblAppointmentRecieptName, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblAppointmentRecieptDateTag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblAppointmentRecieptAgeTag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblAppointmentRecieptSexTag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblAppointmentRecieptDate, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                    .addComponent(lblAppointmentRecieptSex, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                    .addComponent(lblAppointmentRecieptAge, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlApointmentRecieptLayout.createSequentialGroup()
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblAppointmentRecieptRecepTag, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                                .addComponent(lblAppointmentRecieptConChrgTag, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblAppointmentRecieptDocName, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblAppointmentRecieptDocSpec, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblAppointmentRecieptAppointmentDate))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 118, Short.MAX_VALUE)
                                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblAppointmentRecieptSTaxTag, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblAppointmentRecieptAmountPaidTag, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblAppointmentRecieptCTaxTag, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addGap(18, 18, 18)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblAppointmentRecieptSTax, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                            .addComponent(lblAppointmentRecieptConChrg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblAppointmentRecieptCTax, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                            .addComponent(lblAppointmentRecieptAmountPaid, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE))))
                .addGap(61, 61, 61))
            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(lblAppointmentRecieptLogo)
                .addGap(75, 75, 75)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlApointmentRecieptLayout.setVerticalGroup(
            pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAppointmentRecieptLogo)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addGap(35, 35, 35)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblAppointmentRecieptAge, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAppointmentRecieptAgeTag))
                        .addGap(6, 6, 6)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                                .addComponent(lblAppointmentRecieptDate, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAppointmentRecieptSex, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                                .addComponent(lblAppointmentRecieptDateTag)
                                .addGap(6, 6, 6)
                                .addComponent(lblAppointmentRecieptSexTag))))
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblAppointmentRecieptBillNoTag, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAppointmentRecieptBillNo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblAppointmentRecieptNameTag)
                            .addComponent(lblAppointmentRecieptName, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblAppointmentRecieptKinTag, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAppointmentRecieptKin, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(34, 34, 34)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptConChrg, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblAppointmentRecieptSTax, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAppointmentRecieptSTaxTag, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptConChrgTag, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblAppointmentRecieptDocName, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAppointmentRecieptCTax, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAppointmentRecieptCTaxTag, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAppointmentRecieptDocSpec, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptAmountPaidTag, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                        .addComponent(lblAppointmentRecieptAppointmentDate)
                        .addGap(40, 40, 40)
                        .addComponent(lblAppointmentRecieptRecepTag, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptAmountPaid, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        lblAppointmentRecieptPrintIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_print_64_64.png"))); // NOI18N
        lblAppointmentRecieptPrintIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAppointmentRecieptPrintIconMouseClicked(evt);
            }
        });

        lblAppointmentRecieptBackIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_undo_black_64.png"))); // NOI18N
        lblAppointmentRecieptBackIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAppointmentRecieptBackIconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlAppointmentRecieptContainerLayout = new javax.swing.GroupLayout(pnlAppointmentRecieptContainer);
        pnlAppointmentRecieptContainer.setLayout(pnlAppointmentRecieptContainerLayout);
        pnlAppointmentRecieptContainerLayout.setHorizontalGroup(
            pnlAppointmentRecieptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAppointmentRecieptContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlAppointmentRecieptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlApointmentReciept, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAppointmentRecieptContainerLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptPrintIcon)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblAppointmentRecieptBackIcon)))
                .addContainerGap())
        );
        pnlAppointmentRecieptContainerLayout.setVerticalGroup(
            pnlAppointmentRecieptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAppointmentRecieptContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlAppointmentRecieptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAppointmentRecieptPrintIcon)
                    .addComponent(lblAppointmentRecieptBackIcon))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlApointmentReciept, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlAppointmentContainer.add(pnlAppointmentRecieptContainer, "AppointmentRecieptCard");

        pnlAppointmentCard.add(pnlAppointmentContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 770, 710));

        pnlRecepContentContainer.add(pnlAppointmentCard, "AppointmentCard");

        pnlBedCard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel1.setkBorderRadius(0);
        kGradientPanel1.setkEndColor(new java.awt.Color(153, 153, 255));
        kGradientPanel1.setkGradientFocus(800);
        kGradientPanel1.setkStartColor(new java.awt.Color(0, 0, 51));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnBedWard.setText("Ward");
        btnBedWard.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBedWard.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBedWard.setkBorderRadius(15);
        btnBedWard.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBedWard.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBedWard.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBedWard.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBedWard.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBedWard.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBedWard.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBedWard.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBedWard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBedWardActionPerformed(evt);
            }
        });
        kGradientPanel1.add(btnBedWard, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 5, -1, 50));

        btnBedRoom.setText("Room");
        btnBedRoom.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBedRoom.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBedRoom.setkBorderRadius(15);
        btnBedRoom.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBedRoom.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBedRoom.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBedRoom.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBedRoom.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBedRoom.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBedRoom.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBedRoom.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBedRoom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBedRoomActionPerformed(evt);
            }
        });
        kGradientPanel1.add(btnBedRoom, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 5, -1, 50));

        lblBedBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/uturn_icon_50.png"))); // NOI18N
        lblBedBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblBedBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblBedBackMouseClicked(evt);
            }
        });
        kGradientPanel1.add(lblBedBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 5, -1, -1));

        markBedBookingRoom.setkBorderRadius(20);
        markBedBookingRoom.setkEndColor(new java.awt.Color(255, 255, 0));
        markBedBookingRoom.setkGradientFocus(120);
        markBedBookingRoom.setkStartColor(new java.awt.Color(255, 153, 0));
        markBedBookingRoom.setOpaque(false);

        javax.swing.GroupLayout markBedBookingRoomLayout = new javax.swing.GroupLayout(markBedBookingRoom);
        markBedBookingRoom.setLayout(markBedBookingRoomLayout);
        markBedBookingRoomLayout.setHorizontalGroup(
            markBedBookingRoomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markBedBookingRoomLayout.setVerticalGroup(
            markBedBookingRoomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel1.add(markBedBookingRoom, new org.netbeans.lib.awtextra.AbsoluteConstraints(302, 50, 180, 10));

        markBedBookingWard.setkBorderRadius(20);
        markBedBookingWard.setkEndColor(new java.awt.Color(255, 255, 0));
        markBedBookingWard.setkGradientFocus(120);
        markBedBookingWard.setkStartColor(new java.awt.Color(255, 153, 0));
        markBedBookingWard.setOpaque(false);

        javax.swing.GroupLayout markBedBookingWardLayout = new javax.swing.GroupLayout(markBedBookingWard);
        markBedBookingWard.setLayout(markBedBookingWardLayout);
        markBedBookingWardLayout.setHorizontalGroup(
            markBedBookingWardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markBedBookingWardLayout.setVerticalGroup(
            markBedBookingWardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel1.add(markBedBookingWard, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 50, 180, 10));

        pnlBedCard.add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 60));

        pnlBedContainer.setBackground(new java.awt.Color(255, 255, 255));
        pnlBedContainer.setLayout(new java.awt.CardLayout());

        pnlBedWard.setBackground(new java.awt.Color(255, 255, 255));
        pnlBedWard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btngrpBedWardAC_NAC.add(rbtnBedWardAC);
        rbtnBedWardAC.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnBedWardAC.setText("A.C.");
        rbtnBedWardAC.setOpaque(false);
        rbtnBedWardAC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnBedWardACActionPerformed(evt);
            }
        });
        pnlBedWard.add(rbtnBedWardAC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        btngrpBedWardAC_NAC.add(rbtnBedWardNAC);
        rbtnBedWardNAC.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnBedWardNAC.setText("Non-A.C");
        rbtnBedWardNAC.setOpaque(false);
        rbtnBedWardNAC.setVerifyInputWhenFocusTarget(false);
        rbtnBedWardNAC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnBedWardNACActionPerformed(evt);
            }
        });
        pnlBedWard.add(rbtnBedWardNAC, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, -1, -1));

        lblBedWard1.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblBedWard1.setText("Ward");
        pnlBedWard.add(lblBedWard1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 66, 30));

        cbBedWard.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        cbBedWard.setBorder(null);
        cbBedWard.setOpaque(false);
        pnlBedWard.add(cbBedWard, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 200, 30));

        pnlBedWardBooking.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblBedWardBookingPatientID.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblBedWardBookingPatientID.setText("Patient ID");
        pnlBedWardBooking.add(lblBedWardBookingPatientID, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 38, 130, 30));

        txtBedWardBookingPatientID.setBackground(new java.awt.Color(240, 240, 240));
        txtBedWardBookingPatientID.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtBedWardBookingPatientID.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        pnlBedWardBooking.add(txtBedWardBookingPatientID, new org.netbeans.lib.awtextra.AbsoluteConstraints(228, 38, 260, 30));

        lblBedWardBookingWardTypeTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblBedWardBookingWardTypeTag.setText("Ward Type");
        pnlBedWardBooking.add(lblBedWardBookingWardTypeTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 86, 140, 30));

        lblBedWardBookingBedNTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblBedWardBookingBedNTag.setText("Bed No.");
        pnlBedWardBooking.add(lblBedWardBookingBedNTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 168, 130, 30));

        lblBedWardBookingWardType.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        pnlBedWardBooking.add(lblBedWardBookingWardType, new org.netbeans.lib.awtextra.AbsoluteConstraints(228, 86, 270, 30));

        lblBedWardBookingBedN.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        pnlBedWardBooking.add(lblBedWardBookingBedN, new org.netbeans.lib.awtextra.AbsoluteConstraints(228, 168, 150, 30));

        btnBedWardBookingCancel.setText("Cancel");
        btnBedWardBookingCancel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBedWardBookingCancel.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBedWardBookingCancel.setkBorderRadius(15);
        btnBedWardBookingCancel.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBedWardBookingCancel.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBedWardBookingCancel.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBedWardBookingCancel.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBedWardBookingCancel.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBedWardBookingCancel.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBedWardBookingCancel.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBedWardBookingCancel.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBedWardBookingCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBedWardBookingCancelActionPerformed(evt);
            }
        });
        pnlBedWardBooking.add(btnBedWardBookingCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 260, -1, 50));

        btnBedWardBookingBook.setText("Book");
        btnBedWardBookingBook.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBedWardBookingBook.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBedWardBookingBook.setkBorderRadius(15);
        btnBedWardBookingBook.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBedWardBookingBook.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBedWardBookingBook.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBedWardBookingBook.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBedWardBookingBook.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBedWardBookingBook.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBedWardBookingBook.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBedWardBookingBook.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBedWardBookingBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBedWardBookingBookActionPerformed(evt);
            }
        });
        pnlBedWardBooking.add(btnBedWardBookingBook, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, -1, 50));

        lblBedWardBookingWardNoTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblBedWardBookingWardNoTag.setText("Ward No.");
        pnlBedWardBooking.add(lblBedWardBookingWardNoTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 127, 130, 30));

        lblBedWardBookingWardN.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        pnlBedWardBooking.add(lblBedWardBookingWardN, new org.netbeans.lib.awtextra.AbsoluteConstraints(228, 127, 150, 30));

        lblBedWardBookingWarning.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblBedWardBookingWarning.setForeground(new java.awt.Color(255, 0, 0));
        lblBedWardBookingWarning.setText("**Enter Patient ID**");
        pnlBedWardBooking.add(lblBedWardBookingWarning, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 90, -1, -1));

        pnlBedWard.add(pnlBedWardBooking, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 370, 770, 340));

        btnBedWardProceed2Book.setText("Proceed To Book");
        btnBedWardProceed2Book.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBedWardProceed2Book.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBedWardProceed2Book.setkBorderRadius(15);
        btnBedWardProceed2Book.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBedWardProceed2Book.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBedWardProceed2Book.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBedWardProceed2Book.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBedWardProceed2Book.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBedWardProceed2Book.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBedWardProceed2Book.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBedWardProceed2Book.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBedWardProceed2Book.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBedWardProceed2BookActionPerformed(evt);
            }
        });
        pnlBedWard.add(btnBedWardProceed2Book, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 300, 200, 50));

        btnBedWardCheckAvail.setText("Check Availibility");
        btnBedWardCheckAvail.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBedWardCheckAvail.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBedWardCheckAvail.setkBorderRadius(15);
        btnBedWardCheckAvail.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBedWardCheckAvail.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBedWardCheckAvail.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBedWardCheckAvail.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBedWardCheckAvail.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBedWardCheckAvail.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBedWardCheckAvail.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBedWardCheckAvail.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBedWardCheckAvail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBedWardCheckAvailActionPerformed(evt);
            }
        });
        pnlBedWard.add(btnBedWardCheckAvail, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 220, 50));

        tblBedWard.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        spBedWard.setViewportView(tblBedWard);

        pnlBedWard.add(spBedWard, new org.netbeans.lib.awtextra.AbsoluteConstraints(312, 10, 450, 280));

        pnlBedContainer.add(pnlBedWard, "BedWardCard");

        pnlBedRoom.setBackground(new java.awt.Color(255, 255, 255));
        pnlBedRoom.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btngrpBedRoomAC_NAC.add(rbtnBedRoomAC);
        rbtnBedRoomAC.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnBedRoomAC.setText("A.C.");
        rbtnBedRoomAC.setOpaque(false);
        rbtnBedRoomAC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnBedRoomACActionPerformed(evt);
            }
        });
        pnlBedRoom.add(rbtnBedRoomAC, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, -1, -1));

        btngrpBedRoomAC_NAC.add(rbtnBedRoomNAC);
        rbtnBedRoomNAC.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnBedRoomNAC.setText("Non-A.C");
        rbtnBedRoomNAC.setOpaque(false);
        rbtnBedRoomNAC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnBedRoomNACActionPerformed(evt);
            }
        });
        pnlBedRoom.add(rbtnBedRoomNAC, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, -1, -1));

        lblBedRoom1.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblBedRoom1.setText("Room");
        pnlBedRoom.add(lblBedRoom1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 80, 30));

        cbBedRoom.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        pnlBedRoom.add(cbBedRoom, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, 190, 30));

        tblBedRoom.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tblBedRoom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBedRoomMouseClicked(evt);
            }
        });
        spBedRoom.setViewportView(tblBedRoom);

        pnlBedRoom.add(spBedRoom, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 20, -1, 260));

        btnBedRoomProceed2Book.setText("Proceed To Book");
        btnBedRoomProceed2Book.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBedRoomProceed2Book.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBedRoomProceed2Book.setkBorderRadius(15);
        btnBedRoomProceed2Book.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBedRoomProceed2Book.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBedRoomProceed2Book.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBedRoomProceed2Book.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBedRoomProceed2Book.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBedRoomProceed2Book.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBedRoomProceed2Book.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBedRoomProceed2Book.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBedRoomProceed2Book.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBedRoomProceed2BookActionPerformed(evt);
            }
        });
        pnlBedRoom.add(btnBedRoomProceed2Book, new org.netbeans.lib.awtextra.AbsoluteConstraints(425, 300, 210, 50));

        btnBedRoomCheckAvail.setText("Check Availibility");
        btnBedRoomCheckAvail.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBedRoomCheckAvail.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBedRoomCheckAvail.setkBorderRadius(15);
        btnBedRoomCheckAvail.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBedRoomCheckAvail.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBedRoomCheckAvail.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBedRoomCheckAvail.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBedRoomCheckAvail.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBedRoomCheckAvail.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBedRoomCheckAvail.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBedRoomCheckAvail.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBedRoomCheckAvail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBedRoomCheckAvailActionPerformed(evt);
            }
        });
        pnlBedRoom.add(btnBedRoomCheckAvail, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 210, 50));

        pnlBedRoomBooking.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblBedRoomBookingPatientID.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblBedRoomBookingPatientID.setText("Patient ID");
        pnlBedRoomBooking.add(lblBedRoomBookingPatientID, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 38, 130, 30));

        txtBedRoomBookingPatientID.setBackground(new java.awt.Color(240, 240, 240));
        txtBedRoomBookingPatientID.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtBedRoomBookingPatientID.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        pnlBedRoomBooking.add(txtBedRoomBookingPatientID, new org.netbeans.lib.awtextra.AbsoluteConstraints(228, 38, 250, 30));

        lblBedRoomBookingRoomTypeTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblBedRoomBookingRoomTypeTag.setText("Room Type");
        pnlBedRoomBooking.add(lblBedRoomBookingRoomTypeTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 86, 150, 30));

        lblBedRoomBookingBedNTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblBedRoomBookingBedNTag.setText("Bed No.");
        pnlBedRoomBooking.add(lblBedRoomBookingBedNTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 168, 130, 30));

        lblBedRoomBookingRoomType.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        pnlBedRoomBooking.add(lblBedRoomBookingRoomType, new org.netbeans.lib.awtextra.AbsoluteConstraints(228, 86, 270, 30));

        lblBedRoomBookingBedN.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        pnlBedRoomBooking.add(lblBedRoomBookingBedN, new org.netbeans.lib.awtextra.AbsoluteConstraints(228, 168, 150, 30));

        btnBedRoomBookingCancel.setText("Cancel");
        btnBedRoomBookingCancel.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBedRoomBookingCancel.setkBorderRadius(15);
        btnBedRoomBookingCancel.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBedRoomBookingCancel.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBedRoomBookingCancel.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBedRoomBookingCancel.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBedRoomBookingCancel.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBedRoomBookingCancel.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBedRoomBookingCancel.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBedRoomBookingCancel.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBedRoomBookingCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBedRoomBookingCancelActionPerformed(evt);
            }
        });
        pnlBedRoomBooking.add(btnBedRoomBookingCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 260, -1, 50));

        btnBedRoomBookingBook.setText("Book");
        btnBedRoomBookingBook.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBedRoomBookingBook.setkBorderRadius(15);
        btnBedRoomBookingBook.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBedRoomBookingBook.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBedRoomBookingBook.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBedRoomBookingBook.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBedRoomBookingBook.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBedRoomBookingBook.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBedRoomBookingBook.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBedRoomBookingBook.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBedRoomBookingBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBedRoomBookingBookActionPerformed(evt);
            }
        });
        pnlBedRoomBooking.add(btnBedRoomBookingBook, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, -1, 50));

        lblBedRoomBookingRoomNoTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblBedRoomBookingRoomNoTag.setText("Room No.");
        pnlBedRoomBooking.add(lblBedRoomBookingRoomNoTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 127, 130, 30));

        lblBedRoomBookingRoomN.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        pnlBedRoomBooking.add(lblBedRoomBookingRoomN, new org.netbeans.lib.awtextra.AbsoluteConstraints(228, 127, 150, 30));

        lblBedRoomBookingWarning.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblBedRoomBookingWarning.setForeground(new java.awt.Color(255, 0, 0));
        lblBedRoomBookingWarning.setText("**Enter Patient ID**");
        pnlBedRoomBooking.add(lblBedRoomBookingWarning, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 90, -1, -1));

        pnlBedRoom.add(pnlBedRoomBooking, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 370, 770, 340));

        pnlBedContainer.add(pnlBedRoom, "BedRoomCard");

        pnlBedCard.add(pnlBedContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 770, 710));

        pnlRecepContentContainer.add(pnlBedCard, "BedCard");

        pnlAddPatientCard.setPreferredSize(new java.awt.Dimension(770, 768));
        pnlAddPatientCard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel2.setkBorderRadius(0);
        kGradientPanel2.setkEndColor(new java.awt.Color(153, 153, 255));
        kGradientPanel2.setkGradientFocus(800);
        kGradientPanel2.setkStartColor(new java.awt.Color(0, 0, 51));
        kGradientPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblAddPatientBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/uturn_icon_50.png"))); // NOI18N
        lblAddPatientBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblAddPatientBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAddPatientBackMouseClicked(evt);
            }
        });
        kGradientPanel2.add(lblAddPatientBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 5, -1, -1));

        btnAddPatientViewList.setText("View List");
        btnAddPatientViewList.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnAddPatientViewList.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnAddPatientViewList.setkBorderRadius(15);
        btnAddPatientViewList.setkEndColor(new java.awt.Color(102, 255, 102));
        btnAddPatientViewList.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnAddPatientViewList.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnAddPatientViewList.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnAddPatientViewList.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnAddPatientViewList.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnAddPatientViewList.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnAddPatientViewList.setkStartColor(new java.awt.Color(0, 153, 0));
        btnAddPatientViewList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddPatientViewListActionPerformed(evt);
            }
        });
        kGradientPanel2.add(btnAddPatientViewList, new org.netbeans.lib.awtextra.AbsoluteConstraints(223, 5, -1, 50));

        btnAddPatientDischarge.setText("Discharge");
        btnAddPatientDischarge.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnAddPatientDischarge.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnAddPatientDischarge.setkBorderRadius(15);
        btnAddPatientDischarge.setkEndColor(new java.awt.Color(102, 255, 102));
        btnAddPatientDischarge.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnAddPatientDischarge.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnAddPatientDischarge.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnAddPatientDischarge.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnAddPatientDischarge.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnAddPatientDischarge.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnAddPatientDischarge.setkStartColor(new java.awt.Color(0, 153, 0));
        btnAddPatientDischarge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddPatientDischargeActionPerformed(evt);
            }
        });
        kGradientPanel2.add(btnAddPatientDischarge, new org.netbeans.lib.awtextra.AbsoluteConstraints(426, 5, -1, 50));

        btnAddPatientAdmit.setText("Admit");
        btnAddPatientAdmit.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnAddPatientAdmit.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnAddPatientAdmit.setkBorderRadius(15);
        btnAddPatientAdmit.setkEndColor(new java.awt.Color(102, 255, 102));
        btnAddPatientAdmit.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnAddPatientAdmit.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnAddPatientAdmit.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnAddPatientAdmit.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnAddPatientAdmit.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnAddPatientAdmit.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnAddPatientAdmit.setkStartColor(new java.awt.Color(0, 153, 0));
        btnAddPatientAdmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddPatientAdmitActionPerformed(evt);
            }
        });
        kGradientPanel2.add(btnAddPatientAdmit, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 5, -1, 50));

        markAdmitPatient.setkBorderRadius(20);
        markAdmitPatient.setkEndColor(new java.awt.Color(255, 255, 0));
        markAdmitPatient.setkGradientFocus(120);
        markAdmitPatient.setkStartColor(new java.awt.Color(255, 153, 0));
        markAdmitPatient.setOpaque(false);

        javax.swing.GroupLayout markAdmitPatientLayout = new javax.swing.GroupLayout(markAdmitPatient);
        markAdmitPatient.setLayout(markAdmitPatientLayout);
        markAdmitPatientLayout.setHorizontalGroup(
            markAdmitPatientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markAdmitPatientLayout.setVerticalGroup(
            markAdmitPatientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel2.add(markAdmitPatient, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 50, 180, 10));

        markDischargePatient.setkBorderRadius(20);
        markDischargePatient.setkEndColor(new java.awt.Color(255, 255, 0));
        markDischargePatient.setkGradientFocus(120);
        markDischargePatient.setkStartColor(new java.awt.Color(255, 153, 0));
        markDischargePatient.setOpaque(false);

        javax.swing.GroupLayout markDischargePatientLayout = new javax.swing.GroupLayout(markDischargePatient);
        markDischargePatient.setLayout(markDischargePatientLayout);
        markDischargePatientLayout.setHorizontalGroup(
            markDischargePatientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markDischargePatientLayout.setVerticalGroup(
            markDischargePatientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel2.add(markDischargePatient, new org.netbeans.lib.awtextra.AbsoluteConstraints(429, 50, 180, 10));

        markIndoorList.setkBorderRadius(20);
        markIndoorList.setkEndColor(new java.awt.Color(255, 255, 0));
        markIndoorList.setkGradientFocus(120);
        markIndoorList.setkStartColor(new java.awt.Color(255, 153, 0));
        markIndoorList.setOpaque(false);

        javax.swing.GroupLayout markIndoorListLayout = new javax.swing.GroupLayout(markIndoorList);
        markIndoorList.setLayout(markIndoorListLayout);
        markIndoorListLayout.setHorizontalGroup(
            markIndoorListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markIndoorListLayout.setVerticalGroup(
            markIndoorListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel2.add(markIndoorList, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 50, 180, 10));

        pnlAddPatientCard.add(kGradientPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 60));

        pnlIndoorPatientContainer.setLayout(new java.awt.CardLayout());

        pnlIndoorPatientViewList.setBackground(new java.awt.Color(255, 255, 255));
        pnlIndoorPatientViewList.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btngrpIndoorPatientViewListSort.add(rbtnIndoorViewListID);
        rbtnIndoorViewListID.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnIndoorViewListID.setText("Patient ID");
        rbtnIndoorViewListID.setOpaque(false);
        rbtnIndoorViewListID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnIndoorViewListIDActionPerformed(evt);
            }
        });
        pnlIndoorPatientViewList.add(rbtnIndoorViewListID, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 80, 133, -1));

        rbtnIndoorViewListName.setBackground(new java.awt.Color(255, 255, 255));
        btngrpIndoorPatientViewListSort.add(rbtnIndoorViewListName);
        rbtnIndoorViewListName.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnIndoorViewListName.setText("Patient Name");
        rbtnIndoorViewListName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnIndoorViewListNameActionPerformed(evt);
            }
        });
        pnlIndoorPatientViewList.add(rbtnIndoorViewListName, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 50, 133, -1));

        btngrpIndoorPatientViewListSort.add(rbtnIndoorViewListDocRef);
        rbtnIndoorViewListDocRef.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnIndoorViewListDocRef.setText("Doctor Reference");
        rbtnIndoorViewListDocRef.setOpaque(false);
        rbtnIndoorViewListDocRef.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnIndoorViewListDocRefActionPerformed(evt);
            }
        });
        pnlIndoorPatientViewList.add(rbtnIndoorViewListDocRef, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 110, -1, 30));

        btngrpIndoorPatientViewListSort.add(rbtnIndoorViewListR_W);
        rbtnIndoorViewListR_W.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnIndoorViewListR_W.setText("Room/Ward");
        rbtnIndoorViewListR_W.setOpaque(false);
        rbtnIndoorViewListR_W.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnIndoorViewListR_WActionPerformed(evt);
            }
        });
        pnlIndoorPatientViewList.add(rbtnIndoorViewListR_W, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 140, 133, -1));

        txtIndoorViewListSearch.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtIndoorViewListSearch.setText("Patient Name");
        txtIndoorViewListSearch.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtIndoorViewListSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtIndoorViewListSearchMouseClicked(evt);
            }
        });
        txtIndoorViewListSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIndoorViewListSearchActionPerformed(evt);
            }
        });
        txtIndoorViewListSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtIndoorViewListSearchKeyReleased(evt);
            }
        });
        pnlIndoorPatientViewList.add(txtIndoorViewListSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(187, 66, 300, 30));

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        pnlIndoorPatientViewList.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 750, 500));

        lblIndoorViewListExpand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_expand_40px.png"))); // NOI18N
        lblIndoorViewListExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblIndoorViewListExpandMouseClicked(evt);
            }
        });
        pnlIndoorPatientViewList.add(lblIndoorViewListExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        pnlIndoorPatientContainer.add(pnlIndoorPatientViewList, "IndoorPatientViewListCard");

        pnlIndoorPatientDischarge.setBackground(new java.awt.Color(255, 255, 255));

        btnIndoorPatientDischargeGenerateBill.setText("Generate Bill");
        btnIndoorPatientDischargeGenerateBill.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnIndoorPatientDischargeGenerateBill.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnIndoorPatientDischargeGenerateBill.setkBorderRadius(15);
        btnIndoorPatientDischargeGenerateBill.setkEndColor(new java.awt.Color(102, 255, 102));
        btnIndoorPatientDischargeGenerateBill.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnIndoorPatientDischargeGenerateBill.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnIndoorPatientDischargeGenerateBill.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnIndoorPatientDischargeGenerateBill.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnIndoorPatientDischargeGenerateBill.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnIndoorPatientDischargeGenerateBill.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnIndoorPatientDischargeGenerateBill.setkStartColor(new java.awt.Color(0, 153, 0));
        btnIndoorPatientDischargeGenerateBill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIndoorPatientDischargeGenerateBillActionPerformed(evt);
            }
        });

        txtIndoorPatientDischargePatientID.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtIndoorPatientDischargePatientID.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtIndoorPatientDischargePatientID.setText("Patient ID");
        txtIndoorPatientDischargePatientID.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        lblDischargeWarning.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblDischargeWarning.setForeground(new java.awt.Color(255, 0, 0));
        lblDischargeWarning.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDischargeWarning.setText("**All fields are Mandatory**");

        javax.swing.GroupLayout pnlIndoorPatientDischargeLayout = new javax.swing.GroupLayout(pnlIndoorPatientDischarge);
        pnlIndoorPatientDischarge.setLayout(pnlIndoorPatientDischargeLayout);
        pnlIndoorPatientDischargeLayout.setHorizontalGroup(
            pnlIndoorPatientDischargeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlIndoorPatientDischargeLayout.createSequentialGroup()
                .addGroup(pnlIndoorPatientDischargeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlIndoorPatientDischargeLayout.createSequentialGroup()
                        .addGap(220, 220, 220)
                        .addGroup(pnlIndoorPatientDischargeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblDischargeWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIndoorPatientDischargePatientID, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlIndoorPatientDischargeLayout.createSequentialGroup()
                        .addGap(256, 256, 256)
                        .addComponent(btnIndoorPatientDischargeGenerateBill, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(291, Short.MAX_VALUE))
        );
        pnlIndoorPatientDischargeLayout.setVerticalGroup(
            pnlIndoorPatientDischargeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlIndoorPatientDischargeLayout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(txtIndoorPatientDischargePatientID, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(76, 76, 76)
                .addComponent(btnIndoorPatientDischargeGenerateBill, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(lblDischargeWarning, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(417, Short.MAX_VALUE))
        );

        pnlIndoorPatientContainer.add(pnlIndoorPatientDischarge, "IndoorPatientDischargeCard");

        pnlIndoorPatientBillContainer.setBackground(new java.awt.Color(255, 255, 255));

        pnlIndoorBill.setBackground(new java.awt.Color(255, 255, 255));
        pnlIndoorBill.setBorder(new javax.swing.border.MatteBorder(null));
        pnlIndoorBill.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblIndoorBilBillNoTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblIndoorBilBillNoTag.setText("Bill No.        :");
        pnlIndoorBill.add(lblIndoorBilBillNoTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 141, 99, -1));

        lblIndoorBilLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/logo.png"))); // NOI18N
        pnlIndoorBill.add(lblIndoorBilLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 12, -1, -1));

        lblIndoorBilBillNo.setBackground(new java.awt.Color(255, 255, 255));
        lblIndoorBilBillNo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblIndoorBilBillNo.setOpaque(true);
        pnlIndoorBill.add(lblIndoorBilBillNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 141, 150, 20));

        lblIndoorBilNameTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblIndoorBilNameTag.setText("Name          :");
        pnlIndoorBill.add(lblIndoorBilNameTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 167, 99, -1));

        lblIndoorBilName.setBackground(new java.awt.Color(255, 255, 255));
        lblIndoorBilName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblIndoorBilName.setOpaque(true);
        pnlIndoorBill.add(lblIndoorBilName, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 167, 150, 20));

        lblIndoorBilKin.setBackground(new java.awt.Color(255, 255, 255));
        lblIndoorBilKin.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblIndoorBilKin.setOpaque(true);
        pnlIndoorBill.add(lblIndoorBilKin, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 193, 150, 20));

        lblIndoorBilKinTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblIndoorBilKinTag.setText("Kin              :");
        pnlIndoorBill.add(lblIndoorBilKinTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 193, 99, -1));

        lblIndoorBilAgeTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblIndoorBilAgeTag.setText("Age                :");
        pnlIndoorBill.add(lblIndoorBilAgeTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 141, 117, -1));

        lblIndoorBilAge.setBackground(new java.awt.Color(255, 255, 255));
        lblIndoorBilAge.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblIndoorBilAge.setOpaque(true);
        pnlIndoorBill.add(lblIndoorBilAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(589, 141, 150, 20));

        lblIndoorBilDateTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblIndoorBilDateTag.setText("Date               :");
        pnlIndoorBill.add(lblIndoorBilDateTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 167, 117, -1));

        lblIndoorBilSex.setBackground(new java.awt.Color(255, 255, 255));
        lblIndoorBilSex.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblIndoorBilSex.setOpaque(true);
        pnlIndoorBill.add(lblIndoorBilSex, new org.netbeans.lib.awtextra.AbsoluteConstraints(589, 193, 150, 20));

        lblIndoorBilSexTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblIndoorBilSexTag.setText("Sex                 :");
        pnlIndoorBill.add(lblIndoorBilSexTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 193, 117, -1));

        lblIndoorBilDate.setBackground(new java.awt.Color(255, 255, 255));
        lblIndoorBilDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblIndoorBilDate.setOpaque(true);
        pnlIndoorBill.add(lblIndoorBilDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(589, 167, 150, 20));

        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
        pnlIndoorBill.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 271, 748, -1));

        lblIndoorBilDocName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblIndoorBilDocName.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblIndoorBilDocName.setToolTipText("");
        pnlIndoorBill.add(lblIndoorBilDocName, new org.netbeans.lib.awtextra.AbsoluteConstraints(464, 279, 275, 20));

        lblIndoorBilConChrg.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pnlIndoorBill.add(lblIndoorBilConChrg, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 339, 120, 25));

        lblIndoorBilRoomChrgTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblIndoorBilRoomChrgTag.setText("Room Charges");
        pnlIndoorBill.add(lblIndoorBilRoomChrgTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 370, 175, 25));

        lblIndoorBilCTaxTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblIndoorBilCTaxTag.setText("Central GST 9%");
        pnlIndoorBill.add(lblIndoorBilCTaxTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 463, 175, 25));

        lblIndoorBilAmountPaidTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblIndoorBilAmountPaidTag.setText("Total Amount Paid");
        pnlIndoorBill.add(lblIndoorBilAmountPaidTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 500, 175, 25));

        lblIndoorBilRecepTag.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblIndoorBilRecepTag.setText("Receptionist");
        pnlIndoorBill.add(lblIndoorBilRecepTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(619, 571, 120, 23));

        lblIndoorBilConChrgTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblIndoorBilConChrgTag.setText("Consultation Charges");
        pnlIndoorBill.add(lblIndoorBilConChrgTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 339, 175, 25));

        lblIndoorBilDocSpec.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblIndoorBilDocSpec.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        pnlIndoorBill.add(lblIndoorBilDocSpec, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 305, 180, 16));

        lblIndoorBillAdmitDateTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblIndoorBillAdmitDateTag.setText("Admit Date  :");
        pnlIndoorBill.add(lblIndoorBillAdmitDateTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 219, 99, -1));

        lblIndoorBilAdmitDate.setBackground(new java.awt.Color(255, 255, 255));
        lblIndoorBilAdmitDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblIndoorBilAdmitDate.setOpaque(true);
        pnlIndoorBill.add(lblIndoorBilAdmitDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 219, 150, 20));

        lblIndoorBilDischargeDateTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblIndoorBilDischargeDateTag.setText("Discharge Date :");
        pnlIndoorBill.add(lblIndoorBilDischargeDateTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 219, -1, -1));

        lblIndoorBilDischargeDate.setBackground(new java.awt.Color(255, 255, 255));
        lblIndoorBilDischargeDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblIndoorBilDischargeDate.setOpaque(true);
        pnlIndoorBill.add(lblIndoorBilDischargeDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(589, 219, 150, 20));

        lblIndoorBilDiseaseTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblIndoorBilDiseaseTag.setText("Disease       :");
        pnlIndoorBill.add(lblIndoorBilDiseaseTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 245, 99, -1));

        lblIndoorBilDisease.setBackground(new java.awt.Color(255, 255, 255));
        lblIndoorBilDisease.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblIndoorBilDisease.setOpaque(true);
        pnlIndoorBill.add(lblIndoorBilDisease, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 245, 150, 20));

        lblIndoorBilTDays.setBackground(new java.awt.Color(255, 255, 255));
        lblIndoorBilTDays.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblIndoorBilTDays.setOpaque(true);
        pnlIndoorBill.add(lblIndoorBilTDays, new org.netbeans.lib.awtextra.AbsoluteConstraints(589, 245, 150, 20));

        lblIndoorBilTDaysTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblIndoorBilTDaysTag.setText("Total Days       :");
        pnlIndoorBill.add(lblIndoorBilTDaysTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 245, 117, -1));

        lblIndoorBilSTaxTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblIndoorBilSTaxTag.setText("State GST 9%");
        pnlIndoorBill.add(lblIndoorBilSTaxTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 432, 175, 25));

        lblIndoorBilSCTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblIndoorBilSCTag.setText("Services Charges");
        pnlIndoorBill.add(lblIndoorBilSCTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 401, 175, 25));

        lblIndoorBilRoomChrg.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pnlIndoorBill.add(lblIndoorBilRoomChrg, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 370, 120, 25));

        lblIndoorBilSC.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pnlIndoorBill.add(lblIndoorBilSC, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 401, 120, 25));

        lblIndoorBilSTax.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pnlIndoorBill.add(lblIndoorBilSTax, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 432, 120, 25));

        lblIndoorBilCTax.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pnlIndoorBill.add(lblIndoorBilCTax, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 463, 120, 25));

        lblIndoorBilAmountPaid.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pnlIndoorBill.add(lblIndoorBilAmountPaid, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 500, 120, 26));

        jLabel17.setFont(new java.awt.Font("MS UI Gothic", 1, 36)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 0, 102));
        jLabel17.setText("UPSN HOSPITALS");
        pnlIndoorBill.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 12, 394, 30));

        jLabel18.setFont(new java.awt.Font("MS UI Gothic", 1, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 102));
        jLabel18.setText("(A unit of UPSN Medical & Research Centre Pvt. Ltd.)");
        pnlIndoorBill.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 53, -1, -1));

        jLabel20.setFont(new java.awt.Font("MS UI Gothic", 1, 12)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 0, 102));
        jLabel20.setText("Sector - 10, Near Mahindra SEZ, Ajmer Road, ,Mahapura, Rajasthan, 302026");
        pnlIndoorBill.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 83, 402, -1));

        jLabel21.setFont(new java.awt.Font("MS UI Gothic", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 0, 102));
        jLabel21.setText("Tel. : 1234567 * Fax : 0011-1234567 * Email : support@upsnhospitals.in");
        pnlIndoorBill.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 102, 402, -1));

        jLabel22.setFont(new java.awt.Font("MS UI Gothic", 1, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 0, 102));
        jLabel22.setText("CIN No. X00000YZ1111JKL333333");
        pnlIndoorBill.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 122, 402, -1));

        lblIndoorBilPrintIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_print_64_64.png"))); // NOI18N
        lblIndoorBilPrintIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblIndoorBilPrintIconMouseClicked(evt);
            }
        });

        lblIndoorBilBackIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_undo_black_64.png"))); // NOI18N
        lblIndoorBilBackIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblIndoorBilBackIconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlIndoorPatientBillContainerLayout = new javax.swing.GroupLayout(pnlIndoorPatientBillContainer);
        pnlIndoorPatientBillContainer.setLayout(pnlIndoorPatientBillContainerLayout);
        pnlIndoorPatientBillContainerLayout.setHorizontalGroup(
            pnlIndoorPatientBillContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlIndoorPatientBillContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlIndoorPatientBillContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlIndoorBill, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlIndoorPatientBillContainerLayout.createSequentialGroup()
                        .addComponent(lblIndoorBilPrintIcon)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblIndoorBilBackIcon)))
                .addContainerGap())
        );
        pnlIndoorPatientBillContainerLayout.setVerticalGroup(
            pnlIndoorPatientBillContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlIndoorPatientBillContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlIndoorPatientBillContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblIndoorBilPrintIcon)
                    .addComponent(lblIndoorBilBackIcon))
                .addGap(18, 18, 18)
                .addComponent(pnlIndoorBill, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlIndoorPatientContainer.add(pnlIndoorPatientBillContainer, "IndoorPatientBillCard");

        pnlIndoorPatientAdmit.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        jLabel1.setText("Patient ID");

        jTextField1.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N

        jLabel11.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        jLabel11.setText("Emergency Contact");

        jLabel12.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        jLabel12.setText("Disease");

        jLabel13.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        jLabel13.setText("Doctor Reference");

        jTextField2.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N

        jTextField3.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N

        btnIndoorPatientAdmitAdmit.setText("Admit");
        btnIndoorPatientAdmitAdmit.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnIndoorPatientAdmitAdmit.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnIndoorPatientAdmitAdmit.setkBorderRadius(15);
        btnIndoorPatientAdmitAdmit.setkEndColor(new java.awt.Color(102, 255, 102));
        btnIndoorPatientAdmitAdmit.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnIndoorPatientAdmitAdmit.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnIndoorPatientAdmitAdmit.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnIndoorPatientAdmitAdmit.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnIndoorPatientAdmitAdmit.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnIndoorPatientAdmitAdmit.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnIndoorPatientAdmitAdmit.setkStartColor(new java.awt.Color(0, 153, 0));
        btnIndoorPatientAdmitAdmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIndoorPatientAdmitAdmitActionPerformed(evt);
            }
        });

        lblBAppointmentMandatory1.setBackground(new java.awt.Color(255, 255, 255));
        lblBAppointmentMandatory1.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblBAppointmentMandatory1.setForeground(new java.awt.Color(255, 0, 0));
        lblBAppointmentMandatory1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBAppointmentMandatory1.setText("**All fields are mandatory**");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/bed.png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jComboBox2.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlIndoorPatientAdmitLayout = new javax.swing.GroupLayout(pnlIndoorPatientAdmit);
        pnlIndoorPatientAdmit.setLayout(pnlIndoorPatientAdmitLayout);
        pnlIndoorPatientAdmitLayout.setHorizontalGroup(
            pnlIndoorPatientAdmitLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlIndoorPatientAdmitLayout.createSequentialGroup()
                .addGap(95, 95, 95)
                .addGroup(pnlIndoorPatientAdmitLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 255, Short.MAX_VALUE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(67, 67, 67)
                .addGroup(pnlIndoorPatientAdmitLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField1)
                    .addComponent(jTextField2)
                    .addComponent(jTextField3)
                    .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(78, 78, 78))
            .addGroup(pnlIndoorPatientAdmitLayout.createSequentialGroup()
                .addGroup(pnlIndoorPatientAdmitLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlIndoorPatientAdmitLayout.createSequentialGroup()
                        .addGap(280, 280, 280)
                        .addComponent(btnIndoorPatientAdmitAdmit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlIndoorPatientAdmitLayout.createSequentialGroup()
                        .addGap(260, 260, 260)
                        .addComponent(lblBAppointmentMandatory1, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlIndoorPatientAdmitLayout.createSequentialGroup()
                        .addGap(311, 311, 311)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(291, Short.MAX_VALUE))
        );
        pnlIndoorPatientAdmitLayout.setVerticalGroup(
            pnlIndoorPatientAdmitLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlIndoorPatientAdmitLayout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(pnlIndoorPatientAdmitLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(pnlIndoorPatientAdmitLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(pnlIndoorPatientAdmitLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(pnlIndoorPatientAdmitLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(91, 91, 91)
                .addComponent(lblBAppointmentMandatory1)
                .addGap(18, 18, 18)
                .addComponent(btnIndoorPatientAdmitAdmit, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(85, Short.MAX_VALUE))
        );

        pnlIndoorPatientContainer.add(pnlIndoorPatientAdmit, "IndoorPatientAdmitCard");

        pnlAddPatientCard.add(pnlIndoorPatientContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 770, 710));

        pnlRecepContentContainer.add(pnlAddPatientCard, "AddPatientCard");

        pnlPDCard.setBackground(new java.awt.Color(255, 255, 255));
        pnlPDCard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kpnlPDMenuBar.setkBorderRadius(0);
        kpnlPDMenuBar.setkEndColor(new java.awt.Color(153, 153, 255));
        kpnlPDMenuBar.setkGradientFocus(800);
        kpnlPDMenuBar.setkStartColor(new java.awt.Color(0, 0, 51));
        kpnlPDMenuBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnPDAddPatient.setText("Add Patient");
        btnPDAddPatient.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnPDAddPatient.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnPDAddPatient.setkBorderRadius(15);
        btnPDAddPatient.setkEndColor(new java.awt.Color(102, 255, 102));
        btnPDAddPatient.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnPDAddPatient.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnPDAddPatient.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnPDAddPatient.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnPDAddPatient.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnPDAddPatient.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnPDAddPatient.setkStartColor(new java.awt.Color(0, 153, 0));
        btnPDAddPatient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDAddPatientActionPerformed(evt);
            }
        });
        kpnlPDMenuBar.add(btnPDAddPatient, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 5, -1, 50));

        btnPDConfirm.setText("Confirm Patients");
        btnPDConfirm.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnPDConfirm.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnPDConfirm.setkBorderRadius(15);
        btnPDConfirm.setkEndColor(new java.awt.Color(102, 255, 102));
        btnPDConfirm.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnPDConfirm.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnPDConfirm.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnPDConfirm.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnPDConfirm.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnPDConfirm.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnPDConfirm.setkStartColor(new java.awt.Color(0, 153, 0));
        btnPDConfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDConfirmActionPerformed(evt);
            }
        });
        kpnlPDMenuBar.add(btnPDConfirm, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 5, 210, 50));

        lblPDBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/uturn_icon_50.png"))); // NOI18N
        lblPDBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblPDBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPDBackMouseClicked(evt);
            }
        });
        kpnlPDMenuBar.add(lblPDBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 5, -1, -1));

        btnPDSearchDb1.setText("Search Database");
        btnPDSearchDb1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnPDSearchDb1.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnPDSearchDb1.setkBorderRadius(15);
        btnPDSearchDb1.setkEndColor(new java.awt.Color(102, 255, 102));
        btnPDSearchDb1.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnPDSearchDb1.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnPDSearchDb1.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnPDSearchDb1.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnPDSearchDb1.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnPDSearchDb1.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnPDSearchDb1.setkStartColor(new java.awt.Color(0, 153, 0));
        btnPDSearchDb1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDSearchDb1ActionPerformed(evt);
            }
        });
        kpnlPDMenuBar.add(btnPDSearchDb1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 5, 193, 50));

        markPDConfirm.setkBorderRadius(20);
        markPDConfirm.setkEndColor(new java.awt.Color(255, 255, 0));
        markPDConfirm.setkGradientFocus(120);
        markPDConfirm.setkStartColor(new java.awt.Color(255, 153, 0));
        markPDConfirm.setOpaque(false);

        javax.swing.GroupLayout markPDConfirmLayout = new javax.swing.GroupLayout(markPDConfirm);
        markPDConfirm.setLayout(markPDConfirmLayout);
        markPDConfirmLayout.setHorizontalGroup(
            markPDConfirmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 206, Short.MAX_VALUE)
        );
        markPDConfirmLayout.setVerticalGroup(
            markPDConfirmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kpnlPDMenuBar.add(markPDConfirm, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 50, 206, 10));

        markPdSearch.setkBorderRadius(20);
        markPdSearch.setkEndColor(new java.awt.Color(255, 255, 0));
        markPdSearch.setkGradientFocus(120);
        markPdSearch.setkStartColor(new java.awt.Color(255, 153, 0));
        markPdSearch.setOpaque(false);

        javax.swing.GroupLayout markPdSearchLayout = new javax.swing.GroupLayout(markPdSearch);
        markPdSearch.setLayout(markPdSearchLayout);
        markPdSearchLayout.setHorizontalGroup(
            markPdSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 188, Short.MAX_VALUE)
        );
        markPdSearchLayout.setVerticalGroup(
            markPdSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kpnlPDMenuBar.add(markPdSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(243, 50, 188, 10));

        markAddPatient.setkBorderRadius(20);
        markAddPatient.setkEndColor(new java.awt.Color(255, 255, 0));
        markAddPatient.setkGradientFocus(120);
        markAddPatient.setkStartColor(new java.awt.Color(255, 153, 0));
        markAddPatient.setOpaque(false);

        javax.swing.GroupLayout markAddPatientLayout = new javax.swing.GroupLayout(markAddPatient);
        markAddPatient.setLayout(markAddPatientLayout);
        markAddPatientLayout.setHorizontalGroup(
            markAddPatientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markAddPatientLayout.setVerticalGroup(
            markAddPatientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kpnlPDMenuBar.add(markAddPatient, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 50, 180, 10));

        pnlPDCard.add(kpnlPDMenuBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 60));

        pnlPDContainer.setLayout(new java.awt.CardLayout());

        pnlPDAdd.setBackground(new java.awt.Color(255, 255, 255));

        lblPDAddPatientNameTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPDAddPatientNameTag.setText("Patient Name");

        txtPDAddPatientName.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtPDAddPatientName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtPDAddPatientName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPDAddPatientNameActionPerformed(evt);
            }
        });

        lblPDAddKinTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPDAddKinTag.setText("S/o-D/o-W/o");

        txtPDAddKin.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtPDAddKin.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtPDAddKin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPDAddKinActionPerformed(evt);
            }
        });

        cbPDAddGender.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        cbPDAddGender.setMaximumRowCount(4);
        cbPDAddGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Gender", "Male", "Female", "Other" }));
        cbPDAddGender.setAutoscrolls(true);
        cbPDAddGender.setBorder(new javax.swing.border.MatteBorder(null));
        cbPDAddGender.setDoubleBuffered(true);
        cbPDAddGender.setOpaque(false);

        lblPDAddGenderTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPDAddGenderTag.setText("Gender");

        lblPDAddDOBTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPDAddDOBTag.setText("DOB");

        jcalPDAddDOB.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        jcalPDAddDOB.setOpaque(false);

        lblPDAddContactTag.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        lblPDAddContactTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblPDAddContactTag.setText("Contact");

        txtPDAddContact.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtPDAddContact.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtPDAddContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPDAddContactActionPerformed(evt);
            }
        });

        lblPDAddBloodGrpTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPDAddBloodGrpTag.setText("Blood Group");

        cbPDAddBloodGrp.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        cbPDAddBloodGrp.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Blood Group", "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-" }));

        lblPDAddStreetTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPDAddStreetTag.setText("Street");
        lblPDAddStreetTag.setVerticalTextPosition(javax.swing.SwingConstants.TOP);

        txtPDAddStreet.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtPDAddStreet.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtPDAddStreet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPDAddStreetActionPerformed(evt);
            }
        });

        lblPDAddStateTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPDAddStateTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblPDAddStateTag.setText("State");
        lblPDAddStateTag.setVerticalTextPosition(javax.swing.SwingConstants.TOP);

        cbPDAddState.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbPDAddState.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbPDAddStateItemStateChanged(evt);
            }
        });
        cbPDAddState.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPDAddStateActionPerformed(evt);
            }
        });

        cbPDAddCity.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbPDAddCity.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbPDAddCityItemStateChanged(evt);
            }
        });
        cbPDAddCity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPDAddCityActionPerformed(evt);
            }
        });

        lblPDAddCityTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPDAddCityTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblPDAddCityTag.setText("City");
        lblPDAddCityTag.setVerticalTextPosition(javax.swing.SwingConstants.TOP);

        btnPDAddAddPatient.setText("Add Patient");
        btnPDAddAddPatient.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnPDAddAddPatient.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnPDAddAddPatient.setkBorderRadius(15);
        btnPDAddAddPatient.setkEndColor(new java.awt.Color(102, 255, 102));
        btnPDAddAddPatient.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnPDAddAddPatient.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnPDAddAddPatient.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnPDAddAddPatient.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnPDAddAddPatient.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnPDAddAddPatient.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnPDAddAddPatient.setkStartColor(new java.awt.Color(0, 153, 0));
        btnPDAddAddPatient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDAddAddPatientActionPerformed(evt);
            }
        });

        lblPDAddMandatory.setBackground(new java.awt.Color(255, 255, 255));
        lblPDAddMandatory.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblPDAddMandatory.setForeground(new java.awt.Color(255, 0, 0));
        lblPDAddMandatory.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPDAddMandatory.setText("**All fields are mandatory**");

        cbPDAddContact.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        cbPDAddContact.setForeground(new java.awt.Color(255, 255, 255));
        cbPDAddContact.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "+91", "+43", "+32", "+359", "+385", "+357", "+420", "+33", "+49", "+39", "+47", "+34", "+44" }));
        cbPDAddContact.setBorder(null);
        cbPDAddContact.setDoubleBuffered(true);
        cbPDAddContact.setOpaque(false);
        cbPDAddContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPDAddContactActionPerformed(evt);
            }
        });

        lblPDAddInvalidDate.setBackground(new java.awt.Color(255, 255, 255));
        lblPDAddInvalidDate.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblPDAddInvalidDate.setForeground(new java.awt.Color(255, 0, 0));
        lblPDAddInvalidDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPDAddInvalidDate.setText("**All fields are mandatory**");

        javax.swing.GroupLayout pnlPDAddLayout = new javax.swing.GroupLayout(pnlPDAdd);
        pnlPDAdd.setLayout(pnlPDAddLayout);
        pnlPDAddLayout.setHorizontalGroup(
            pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPDAddLayout.createSequentialGroup()
                .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlPDAddLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlPDAddLayout.createSequentialGroup()
                                .addGap(54, 54, 54)
                                .addComponent(lblPDAddStreetTag)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtPDAddStreet, javax.swing.GroupLayout.PREFERRED_SIZE, 641, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlPDAddLayout.createSequentialGroup()
                                .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnlPDAddLayout.createSequentialGroup()
                                        .addComponent(lblPDAddContactTag, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(cbPDAddContact, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtPDAddContact, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(lblPDAddBloodGrpTag))
                                    .addGroup(pnlPDAddLayout.createSequentialGroup()
                                        .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(pnlPDAddLayout.createSequentialGroup()
                                                .addComponent(lblPDAddPatientNameTag, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtPDAddPatientName, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlPDAddLayout.createSequentialGroup()
                                                .addComponent(lblPDAddGenderTag)
                                                .addGap(18, 18, 18)
                                                .addComponent(cbPDAddGender, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(pnlPDAddLayout.createSequentialGroup()
                                                .addGap(117, 117, 117)
                                                .addComponent(lblPDAddDOBTag))
                                            .addGroup(pnlPDAddLayout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(lblPDAddKinTag)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txtPDAddKin, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                            .addComponent(cbPDAddBloodGrp, 0, 200, Short.MAX_VALUE)
                                            .addComponent(jcalPDAddDOB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                    .addGroup(pnlPDAddLayout.createSequentialGroup()
                                        .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(pnlPDAddLayout.createSequentialGroup()
                                                .addGap(140, 140, 140)
                                                .addComponent(cbPDAddState, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(lblPDAddStateTag, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addComponent(lblPDAddCityTag, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(29, 29, 29)
                                        .addComponent(cbPDAddCity, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(pnlPDAddLayout.createSequentialGroup()
                        .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlPDAddLayout.createSequentialGroup()
                                .addGap(288, 288, 288)
                                .addComponent(btnPDAddAddPatient, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlPDAddLayout.createSequentialGroup()
                                .addGap(276, 276, 276)
                                .addComponent(lblPDAddMandatory, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(pnlPDAddLayout.createSequentialGroup()
                .addGap(252, 252, 252)
                .addComponent(lblPDAddInvalidDate, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlPDAddLayout.setVerticalGroup(
            pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPDAddLayout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtPDAddKin, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPDAddKinTag, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPDAddPatientName, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPDAddPatientNameTag, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblPDAddGenderTag, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                        .addComponent(cbPDAddGender, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jcalPDAddDOB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(lblPDAddDOBTag, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlPDAddLayout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cbPDAddBloodGrp, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtPDAddContact, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cbPDAddContact, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblPDAddBloodGrpTag, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(50, 50, 50))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlPDAddLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblPDAddContactTag, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)))
                .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPDAddStreetTag, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPDAddStreet, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addGroup(pnlPDAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblPDAddStateTag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cbPDAddState)
                    .addComponent(lblPDAddCityTag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cbPDAddCity, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(77, 77, 77)
                .addComponent(btnPDAddAddPatient, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(lblPDAddMandatory)
                .addGap(18, 18, 18)
                .addComponent(lblPDAddInvalidDate)
                .addContainerGap(63, Short.MAX_VALUE))
        );

        pnlPDContainer.add(pnlPDAdd, "PDAddCard");

        pnlPDSearch.setBackground(new java.awt.Color(255, 255, 255));
        pnlPDSearch.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtPDSearch.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtPDSearch.setText("Patient Name");
        txtPDSearch.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtPDSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPDSearchMouseClicked(evt);
            }
        });
        txtPDSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPDSearchKeyReleased(evt);
            }
        });
        pnlPDSearch.add(txtPDSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(196, 58, 340, 30));

        spPDSearch.setBackground(new java.awt.Color(255, 255, 255));
        spPDSearch.setForeground(new java.awt.Color(255, 255, 255));

        tblPDSearch.setAutoCreateRowSorter(true);
        tblPDSearch.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(51, 51, 255)));
        tblPDSearch.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tblPDSearch.setForeground(new java.awt.Color(0, 51, 255));
        tblPDSearch.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblPDSearch.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tblPDSearch.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tblPDSearch.setGridColor(new java.awt.Color(51, 51, 255));
        tblPDSearch.setMaximumSize(new java.awt.Dimension(750, 500));
        tblPDSearch.setMinimumSize(new java.awt.Dimension(750, 500));
        tblPDSearch.setPreferredSize(new java.awt.Dimension(750, 500));
        tblPDSearch.setRequestFocusEnabled(false);
        tblPDSearch.setRowHeight(20);
        tblPDSearch.setSelectionForeground(new java.awt.Color(255, 51, 0));
        tblPDSearch.setShowGrid(true);
        tblPDSearch.getTableHeader().setReorderingAllowed(false);
        spPDSearch.setViewportView(tblPDSearch);

        pnlPDSearch.add(spPDSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 199, 750, 500));

        lblPDSearchExpand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_expand_40px.png"))); // NOI18N
        lblPDSearchExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPDSearchExpandMouseClicked(evt);
            }
        });
        pnlPDSearch.add(lblPDSearchExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 30, -1, -1));

        pnlPDContainer.add(pnlPDSearch, "PDSearchCard");

        pnlPDConfirm.setBackground(new java.awt.Color(255, 255, 255));
        pnlPDConfirm.setPreferredSize(new java.awt.Dimension(770, 771));
        pnlPDConfirm.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        spPDSearch1.setBackground(new java.awt.Color(255, 255, 255));
        spPDSearch1.setForeground(new java.awt.Color(255, 255, 255));

        tblPDConfirm.setAutoCreateRowSorter(true);
        tblPDConfirm.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(51, 51, 255)));
        tblPDConfirm.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tblPDConfirm.setForeground(new java.awt.Color(0, 51, 255));
        tblPDConfirm.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Kin", "Gender", "Date of Birth", "Email", "Contact", "Blood Group", "Address", "Username"
            }
        ));
        tblPDConfirm.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tblPDConfirm.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tblPDConfirm.setGridColor(new java.awt.Color(51, 51, 255));
        tblPDConfirm.setMaximumSize(new java.awt.Dimension(750, 500));
        tblPDConfirm.setMinimumSize(new java.awt.Dimension(750, 500));
        tblPDConfirm.setPreferredSize(new java.awt.Dimension(750, 500));
        tblPDConfirm.setRequestFocusEnabled(false);
        tblPDConfirm.setRowHeight(20);
        tblPDConfirm.setSelectionForeground(new java.awt.Color(255, 51, 0));
        tblPDConfirm.setShowGrid(true);
        tblPDConfirm.getTableHeader().setReorderingAllowed(false);
        tblPDConfirm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPDConfirmMouseClicked(evt);
            }
        });
        spPDSearch1.setViewportView(tblPDConfirm);

        pnlPDConfirm.add(spPDSearch1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 105, 750, 500));

        btnPDConfirmPatient.setText("Confirm Patient ");
        btnPDConfirmPatient.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnPDConfirmPatient.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnPDConfirmPatient.setkBorderRadius(15);
        btnPDConfirmPatient.setkEndColor(new java.awt.Color(102, 255, 102));
        btnPDConfirmPatient.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnPDConfirmPatient.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnPDConfirmPatient.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnPDConfirmPatient.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnPDConfirmPatient.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnPDConfirmPatient.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnPDConfirmPatient.setkStartColor(new java.awt.Color(0, 153, 0));
        btnPDConfirmPatient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDConfirmPatientActionPerformed(evt);
            }
        });
        pnlPDConfirm.add(btnPDConfirmPatient, new org.netbeans.lib.awtextra.AbsoluteConstraints(263, 623, 200, 50));

        lblPDConfirmExpand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_expand_40px.png"))); // NOI18N
        lblPDConfirmExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPDConfirmExpandMouseClicked(evt);
            }
        });
        pnlPDConfirm.add(lblPDConfirmExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 30, -1, -1));

        pnlPDContainer.add(pnlPDConfirm, "PDConfirmCard");

        pnlPDCard.add(pnlPDContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 770, 710));

        pnlRecepContentContainer.add(pnlPDCard, "PDCard");

        pnlDDCard.setBackground(new java.awt.Color(255, 255, 255));
        pnlDDCard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtDDSearch.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtDDSearch.setText("Doctor Name");
        txtDDSearch.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtDDSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtDDSearchMouseClicked(evt);
            }
        });
        txtDDSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDDSearchKeyReleased(evt);
            }
        });
        pnlDDCard.add(txtDDSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, 210, 30));

        tblDDSearch.setBorder(new javax.swing.border.MatteBorder(null));
        tblDDSearch.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tblDDSearch.setForeground(new java.awt.Color(51, 51, 255));
        tblDDSearch.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblDDSearch.setGridColor(new java.awt.Color(0, 51, 255));
        tblDDSearch.setPreferredSize(new java.awt.Dimension(730, 510));
        tblDDSearch.setRowHeight(20);
        tblDDSearch.setSelectionForeground(new java.awt.Color(255, 0, 0));
        tblDDSearch.setShowGrid(true);
        spDDSearch.setViewportView(tblDDSearch);

        pnlDDCard.add(spDDSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 237, 730, 510));

        kpnlDDtMenuBar.setkBorderRadius(0);
        kpnlDDtMenuBar.setkEndColor(new java.awt.Color(153, 153, 255));
        kpnlDDtMenuBar.setkGradientFocus(800);
        kpnlDDtMenuBar.setkStartColor(new java.awt.Color(0, 0, 51));

        lblDDBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/uturn_icon_50.png"))); // NOI18N
        lblDDBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblDDBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblDDBackMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout kpnlDDtMenuBarLayout = new javax.swing.GroupLayout(kpnlDDtMenuBar);
        kpnlDDtMenuBar.setLayout(kpnlDDtMenuBarLayout);
        kpnlDDtMenuBarLayout.setHorizontalGroup(
            kpnlDDtMenuBarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kpnlDDtMenuBarLayout.createSequentialGroup()
                .addContainerGap(710, Short.MAX_VALUE)
                .addComponent(lblDDBack, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        kpnlDDtMenuBarLayout.setVerticalGroup(
            kpnlDDtMenuBarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kpnlDDtMenuBarLayout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(lblDDBack, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pnlDDCard.add(kpnlDDtMenuBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 60));

        rbtnDDSearchName.setBackground(new java.awt.Color(255, 255, 255));
        btngrpDDSearchFilter.add(rbtnDDSearchName);
        rbtnDDSearchName.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnDDSearchName.setText("NAME");
        rbtnDDSearchName.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbtnDDSearchNameMouseClicked(evt);
            }
        });
        rbtnDDSearchName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnDDSearchNameActionPerformed(evt);
            }
        });
        pnlDDCard.add(rbtnDDSearchName, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 110, 110, -1));

        rbtnDDSearchSpecialisation.setBackground(new java.awt.Color(255, 255, 255));
        btngrpDDSearchFilter.add(rbtnDDSearchSpecialisation);
        rbtnDDSearchSpecialisation.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnDDSearchSpecialisation.setText("SPECIALISATION");
        rbtnDDSearchSpecialisation.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbtnDDSearchSpecialisationMouseClicked(evt);
            }
        });
        rbtnDDSearchSpecialisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnDDSearchSpecialisationActionPerformed(evt);
            }
        });
        pnlDDCard.add(rbtnDDSearchSpecialisation, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 140, -1, -1));

        pnlRecepContentContainer.add(pnlDDCard, "DDCard");

        pnlViewBedCard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kpnlViewBedMenuBar.setkBorderRadius(0);
        kpnlViewBedMenuBar.setkEndColor(new java.awt.Color(153, 153, 255));
        kpnlViewBedMenuBar.setkGradientFocus(800);
        kpnlViewBedMenuBar.setkStartColor(new java.awt.Color(0, 0, 51));
        kpnlViewBedMenuBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnViewBedWard.setText("Ward");
        btnViewBedWard.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnViewBedWard.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnViewBedWard.setkBorderRadius(15);
        btnViewBedWard.setkEndColor(new java.awt.Color(102, 255, 102));
        btnViewBedWard.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnViewBedWard.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnViewBedWard.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnViewBedWard.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnViewBedWard.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnViewBedWard.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnViewBedWard.setkStartColor(new java.awt.Color(0, 153, 0));
        btnViewBedWard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewBedWardActionPerformed(evt);
            }
        });
        kpnlViewBedMenuBar.add(btnViewBedWard, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 5, -1, 50));

        btnViewBedRoom.setText("Room");
        btnViewBedRoom.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnViewBedRoom.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnViewBedRoom.setkBorderRadius(15);
        btnViewBedRoom.setkEndColor(new java.awt.Color(102, 255, 102));
        btnViewBedRoom.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnViewBedRoom.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnViewBedRoom.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnViewBedRoom.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnViewBedRoom.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnViewBedRoom.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnViewBedRoom.setkStartColor(new java.awt.Color(0, 153, 0));
        btnViewBedRoom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewBedRoomActionPerformed(evt);
            }
        });
        kpnlViewBedMenuBar.add(btnViewBedRoom, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 5, -1, 50));

        lblViewBedBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/uturn_icon_50.png"))); // NOI18N
        lblViewBedBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblViewBedBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblViewBedBackMouseClicked(evt);
            }
        });
        kpnlViewBedMenuBar.add(lblViewBedBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 5, -1, -1));

        markBedListRoom.setkBorderRadius(20);
        markBedListRoom.setkEndColor(new java.awt.Color(255, 255, 0));
        markBedListRoom.setkGradientFocus(120);
        markBedListRoom.setkStartColor(new java.awt.Color(255, 153, 0));
        markBedListRoom.setOpaque(false);

        javax.swing.GroupLayout markBedListRoomLayout = new javax.swing.GroupLayout(markBedListRoom);
        markBedListRoom.setLayout(markBedListRoomLayout);
        markBedListRoomLayout.setHorizontalGroup(
            markBedListRoomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markBedListRoomLayout.setVerticalGroup(
            markBedListRoomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kpnlViewBedMenuBar.add(markBedListRoom, new org.netbeans.lib.awtextra.AbsoluteConstraints(253, 50, 180, 10));

        markBedListWard.setkBorderRadius(20);
        markBedListWard.setkEndColor(new java.awt.Color(255, 255, 0));
        markBedListWard.setkGradientFocus(120);
        markBedListWard.setkStartColor(new java.awt.Color(255, 153, 0));
        markBedListWard.setOpaque(false);

        javax.swing.GroupLayout markBedListWardLayout = new javax.swing.GroupLayout(markBedListWard);
        markBedListWard.setLayout(markBedListWardLayout);
        markBedListWardLayout.setHorizontalGroup(
            markBedListWardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markBedListWardLayout.setVerticalGroup(
            markBedListWardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kpnlViewBedMenuBar.add(markBedListWard, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 50, 180, 10));

        pnlViewBedCard.add(kpnlViewBedMenuBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 60));

        pnlViewBedContainer.setBackground(new java.awt.Color(255, 255, 255));
        pnlViewBedContainer.setLayout(new java.awt.CardLayout());

        pnlViewBedRoom.setBackground(new java.awt.Color(255, 255, 255));
        pnlViewBedRoom.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rbtnViewBedRoomAvbl.setBackground(new java.awt.Color(255, 255, 255));
        btngrpViewBedRoomrev_avlb.add(rbtnViewBedRoomAvbl);
        rbtnViewBedRoomAvbl.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnViewBedRoomAvbl.setText("Available");
        rbtnViewBedRoomAvbl.setBorder(null);
        rbtnViewBedRoomAvbl.setPreferredSize(new java.awt.Dimension(90, 30));
        rbtnViewBedRoomAvbl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnViewBedRoomAvblActionPerformed(evt);
            }
        });
        pnlViewBedRoom.add(rbtnViewBedRoomAvbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 70, 102, -1));

        rbtnViewBedRoomRev.setBackground(new java.awt.Color(255, 255, 255));
        btngrpViewBedRoomrev_avlb.add(rbtnViewBedRoomRev);
        rbtnViewBedRoomRev.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnViewBedRoomRev.setText("Reserved");
        rbtnViewBedRoomRev.setBorder(null);
        rbtnViewBedRoomRev.setPreferredSize(new java.awt.Dimension(90, 30));
        rbtnViewBedRoomRev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnViewBedRoomRevActionPerformed(evt);
            }
        });
        pnlViewBedRoom.add(rbtnViewBedRoomRev, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 42, 102, -1));

        txtViewBedRoomSearch.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtViewBedRoomSearch.setText("Room Type or Room No");
        txtViewBedRoomSearch.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtViewBedRoomSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtViewBedRoomSearchMouseClicked(evt);
            }
        });
        txtViewBedRoomSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtViewBedRoomSearchActionPerformed(evt);
            }
        });
        txtViewBedRoomSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtViewBedRoomSearchKeyReleased(evt);
            }
        });
        pnlViewBedRoom.add(txtViewBedRoomSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(196, 60, 300, 30));

        rbtnViewBedRoomAll.setBackground(new java.awt.Color(255, 255, 255));
        btngrpViewBedRoomrev_avlb.add(rbtnViewBedRoomAll);
        rbtnViewBedRoomAll.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnViewBedRoomAll.setText("All");
        rbtnViewBedRoomAll.setBorder(null);
        rbtnViewBedRoomAll.setPreferredSize(new java.awt.Dimension(90, 30));
        rbtnViewBedRoomAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnViewBedRoomAllActionPerformed(evt);
            }
        });
        pnlViewBedRoom.add(rbtnViewBedRoomAll, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 16, 102, -1));

        tblViewBedRoom.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tblViewBedRoom);

        pnlViewBedRoom.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 145, 760, 554));

        lblViewBedRoomExpand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_expand_40px.png"))); // NOI18N
        lblViewBedRoomExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblViewBedRoomExpandMouseClicked(evt);
            }
        });
        pnlViewBedRoom.add(lblViewBedRoomExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        pnlViewBedContainer.add(pnlViewBedRoom, "ViewRoomCard");

        pnlViewBedWard.setBackground(new java.awt.Color(255, 255, 255));
        pnlViewBedWard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtViewBedWardSearch.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtViewBedWardSearch.setText("Ward Type or Ward No");
        txtViewBedWardSearch.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtViewBedWardSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtViewBedWardSearchMouseClicked(evt);
            }
        });
        txtViewBedWardSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtViewBedWardSearchActionPerformed(evt);
            }
        });
        txtViewBedWardSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtViewBedWardSearchKeyReleased(evt);
            }
        });
        pnlViewBedWard.add(txtViewBedWardSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, 300, 30));

        rbtnViewBedWardAvbl.setBackground(new java.awt.Color(255, 255, 255));
        btngrpViewBedWardrev_avlb.add(rbtnViewBedWardAvbl);
        rbtnViewBedWardAvbl.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnViewBedWardAvbl.setText("Available");
        rbtnViewBedWardAvbl.setPreferredSize(new java.awt.Dimension(90, 30));
        rbtnViewBedWardAvbl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnViewBedWardAvblActionPerformed(evt);
            }
        });
        pnlViewBedWard.add(rbtnViewBedWardAvbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 67, 102, -1));

        rbtnViewBedWardRev.setBackground(new java.awt.Color(255, 255, 255));
        btngrpViewBedWardrev_avlb.add(rbtnViewBedWardRev);
        rbtnViewBedWardRev.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnViewBedWardRev.setText("Reserved");
        rbtnViewBedWardRev.setPreferredSize(new java.awt.Dimension(90, 30));
        rbtnViewBedWardRev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnViewBedWardRevActionPerformed(evt);
            }
        });
        pnlViewBedWard.add(rbtnViewBedWardRev, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 37, 102, -1));

        rbtnViewBedWardAll.setBackground(new java.awt.Color(255, 255, 255));
        btngrpViewBedWardrev_avlb.add(rbtnViewBedWardAll);
        rbtnViewBedWardAll.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnViewBedWardAll.setText("All");
        rbtnViewBedWardAll.setPreferredSize(new java.awt.Dimension(90, 30));
        rbtnViewBedWardAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnViewBedWardAllActionPerformed(evt);
            }
        });
        pnlViewBedWard.add(rbtnViewBedWardAll, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 7, 102, -1));

        tblViewBedWard.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tblViewBedWard);

        pnlViewBedWard.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 145, 750, 554));

        lblViewBedWardExpand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_expand_40px.png"))); // NOI18N
        lblViewBedWardExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblViewBedWardExpandMouseClicked(evt);
            }
        });
        pnlViewBedWard.add(lblViewBedWardExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        pnlViewBedContainer.add(pnlViewBedWard, "ViewWardCard");

        pnlViewBedCard.add(pnlViewBedContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 770, 710));

        pnlRecepContentContainer.add(pnlViewBedCard, "ViewBedCard");

        pnlRecords.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel3.setkBorderRadius(0);
        kGradientPanel3.setkEndColor(new java.awt.Color(153, 153, 255));
        kGradientPanel3.setkGradientFocus(800);
        kGradientPanel3.setkStartColor(new java.awt.Color(0, 0, 51));
        kGradientPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblRecordsBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/uturn_icon_50.png"))); // NOI18N
        lblRecordsBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRecordsBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecordsBackMouseClicked(evt);
            }
        });
        kGradientPanel3.add(lblRecordsBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 5, -1, -1));

        btnRecordsConsultancy.setText("Consultancy");
        btnRecordsConsultancy.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnRecordsConsultancy.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnRecordsConsultancy.setkBorderRadius(15);
        btnRecordsConsultancy.setkEndColor(new java.awt.Color(102, 255, 102));
        btnRecordsConsultancy.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnRecordsConsultancy.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnRecordsConsultancy.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnRecordsConsultancy.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnRecordsConsultancy.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnRecordsConsultancy.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnRecordsConsultancy.setkStartColor(new java.awt.Color(0, 153, 0));
        btnRecordsConsultancy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecordsConsultancyActionPerformed(evt);
            }
        });
        kGradientPanel3.add(btnRecordsConsultancy, new org.netbeans.lib.awtextra.AbsoluteConstraints(223, 5, -1, 50));

        btnRecordsIndoor.setText("Indoor");
        btnRecordsIndoor.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnRecordsIndoor.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnRecordsIndoor.setkBorderRadius(15);
        btnRecordsIndoor.setkEndColor(new java.awt.Color(102, 255, 102));
        btnRecordsIndoor.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnRecordsIndoor.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnRecordsIndoor.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnRecordsIndoor.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnRecordsIndoor.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnRecordsIndoor.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnRecordsIndoor.setkStartColor(new java.awt.Color(0, 153, 0));
        btnRecordsIndoor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecordsIndoorActionPerformed(evt);
            }
        });
        kGradientPanel3.add(btnRecordsIndoor, new org.netbeans.lib.awtextra.AbsoluteConstraints(426, 5, -1, 50));

        btnRecordsLab.setText("Lab");
        btnRecordsLab.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnRecordsLab.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnRecordsLab.setkBorderRadius(15);
        btnRecordsLab.setkEndColor(new java.awt.Color(102, 255, 102));
        btnRecordsLab.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnRecordsLab.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnRecordsLab.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnRecordsLab.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnRecordsLab.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnRecordsLab.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnRecordsLab.setkStartColor(new java.awt.Color(0, 153, 0));
        btnRecordsLab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecordsLabActionPerformed(evt);
            }
        });
        kGradientPanel3.add(btnRecordsLab, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 5, -1, 50));

        markRecordsLab.setkBorderRadius(20);
        markRecordsLab.setkEndColor(new java.awt.Color(255, 255, 0));
        markRecordsLab.setkGradientFocus(120);
        markRecordsLab.setkStartColor(new java.awt.Color(255, 153, 0));
        markRecordsLab.setOpaque(false);

        javax.swing.GroupLayout markRecordsLabLayout = new javax.swing.GroupLayout(markRecordsLab);
        markRecordsLab.setLayout(markRecordsLabLayout);
        markRecordsLabLayout.setHorizontalGroup(
            markRecordsLabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markRecordsLabLayout.setVerticalGroup(
            markRecordsLabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel3.add(markRecordsLab, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 50, 180, 10));

        markRecordsIndoor.setkBorderRadius(20);
        markRecordsIndoor.setkEndColor(new java.awt.Color(255, 255, 0));
        markRecordsIndoor.setkGradientFocus(120);
        markRecordsIndoor.setkStartColor(new java.awt.Color(255, 153, 0));
        markRecordsIndoor.setOpaque(false);

        javax.swing.GroupLayout markRecordsIndoorLayout = new javax.swing.GroupLayout(markRecordsIndoor);
        markRecordsIndoor.setLayout(markRecordsIndoorLayout);
        markRecordsIndoorLayout.setHorizontalGroup(
            markRecordsIndoorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markRecordsIndoorLayout.setVerticalGroup(
            markRecordsIndoorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel3.add(markRecordsIndoor, new org.netbeans.lib.awtextra.AbsoluteConstraints(429, 50, 180, 10));

        markRecordsConsultancy.setkBorderRadius(20);
        markRecordsConsultancy.setkEndColor(new java.awt.Color(255, 255, 0));
        markRecordsConsultancy.setkGradientFocus(120);
        markRecordsConsultancy.setkStartColor(new java.awt.Color(255, 153, 0));
        markRecordsConsultancy.setOpaque(false);

        javax.swing.GroupLayout markRecordsConsultancyLayout = new javax.swing.GroupLayout(markRecordsConsultancy);
        markRecordsConsultancy.setLayout(markRecordsConsultancyLayout);
        markRecordsConsultancyLayout.setHorizontalGroup(
            markRecordsConsultancyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markRecordsConsultancyLayout.setVerticalGroup(
            markRecordsConsultancyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel3.add(markRecordsConsultancy, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 50, 180, 10));

        pnlRecords.add(kGradientPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 60));

        pnlRecordsContainer.setLayout(new java.awt.CardLayout());

        pnlRecordsLab.setBackground(new java.awt.Color(255, 255, 255));

        tblRecordsLab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(tblRecordsLab);

        lblRecordsLabExpand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_expand_40px.png"))); // NOI18N
        lblRecordsLabExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecordsLabExpandMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlRecordsLabLayout = new javax.swing.GroupLayout(pnlRecordsLab);
        pnlRecordsLab.setLayout(pnlRecordsLabLayout);
        pnlRecordsLabLayout.setHorizontalGroup(
            pnlRecordsLabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRecordsLabLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 685, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlRecordsLabLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblRecordsLabExpand, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );
        pnlRecordsLabLayout.setVerticalGroup(
            pnlRecordsLabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlRecordsLabLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(lblRecordsLabExpand, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 589, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlRecordsContainer.add(pnlRecordsLab, "RecordsLabCard");

        pnlRecordsConsultancy.setBackground(new java.awt.Color(255, 255, 255));

        tblRecordsConsultancy.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane7.setViewportView(tblRecordsConsultancy);

        lblRecordsConsultancyExpand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_expand_40px.png"))); // NOI18N
        lblRecordsConsultancyExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecordsConsultancyExpandMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlRecordsConsultancyLayout = new javax.swing.GroupLayout(pnlRecordsConsultancy);
        pnlRecordsConsultancy.setLayout(pnlRecordsConsultancyLayout);
        pnlRecordsConsultancyLayout.setHorizontalGroup(
            pnlRecordsConsultancyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRecordsConsultancyLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 685, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlRecordsConsultancyLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblRecordsConsultancyExpand, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );
        pnlRecordsConsultancyLayout.setVerticalGroup(
            pnlRecordsConsultancyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlRecordsConsultancyLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(lblRecordsConsultancyExpand, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 589, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlRecordsContainer.add(pnlRecordsConsultancy, "RecordsConcCard");

        pnlRecordsIndoor.setBackground(new java.awt.Color(255, 255, 255));

        tblRecordsIndoor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane8.setViewportView(tblRecordsIndoor);

        lblRecordsIndoorExpand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_expand_40px.png"))); // NOI18N
        lblRecordsIndoorExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecordsIndoorExpandMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlRecordsIndoorLayout = new javax.swing.GroupLayout(pnlRecordsIndoor);
        pnlRecordsIndoor.setLayout(pnlRecordsIndoorLayout);
        pnlRecordsIndoorLayout.setHorizontalGroup(
            pnlRecordsIndoorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRecordsIndoorLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 685, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlRecordsIndoorLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblRecordsIndoorExpand, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );
        pnlRecordsIndoorLayout.setVerticalGroup(
            pnlRecordsIndoorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlRecordsIndoorLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(lblRecordsIndoorExpand, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 589, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlRecordsContainer.add(pnlRecordsIndoor, "RecordIndoorCard");

        pnlRecords.add(pnlRecordsContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 770, 710));

        pnlRecepContentContainer.add(pnlRecords, "RecordsCard");

        javax.swing.GroupLayout pnlMainDashContainerLayout = new javax.swing.GroupLayout(pnlMainDashContainer);
        pnlMainDashContainer.setLayout(pnlMainDashContainerLayout);
        pnlMainDashContainerLayout.setHorizontalGroup(
            pnlMainDashContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1080, Short.MAX_VALUE)
            .addGroup(pnlMainDashContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlMainDashContainerLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(kpnlRecepDash, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, 0)
                    .addComponent(pnlRecepContentContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        pnlMainDashContainerLayout.setVerticalGroup(
            pnlMainDashContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 768, Short.MAX_VALUE)
            .addGroup(pnlMainDashContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlMainDashContainerLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(pnlMainDashContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(kpnlRecepDash, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(pnlRecepContentContainer, javax.swing.GroupLayout.PREFERRED_SIZE, 768, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pnlMainContainer.add(pnlMainDashContainer, "MainDashCard");

        pnlRecordsLabExpand.setBackground(new java.awt.Color(255, 255, 255));

        tblRecordsLabExpand.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane9.setViewportView(tblRecordsLabExpand);

        lblRecordsLabCollasp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_collapse_40px.png"))); // NOI18N
        lblRecordsLabCollasp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecordsLabCollaspMouseClicked(evt);
            }
        });

        txtRecordsLabExpandSearch.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtRecordsLabExpandSearch.setText("Bill No or Name");
        txtRecordsLabExpandSearch.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtRecordsLabExpandSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtRecordsLabExpandSearchMouseClicked(evt);
            }
        });
        txtRecordsLabExpandSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtRecordsLabExpandSearchKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout pnlRecordsLabExpandLayout = new javax.swing.GroupLayout(pnlRecordsLabExpand);
        pnlRecordsLabExpand.setLayout(pnlRecordsLabExpandLayout);
        pnlRecordsLabExpandLayout.setHorizontalGroup(
            pnlRecordsLabExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRecordsLabExpandLayout.createSequentialGroup()
                .addGroup(pnlRecordsLabExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlRecordsLabExpandLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 1060, Short.MAX_VALUE))
                    .addGroup(pnlRecordsLabExpandLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtRecordsLabExpandSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(289, 289, 289)
                        .addComponent(lblRecordsLabCollasp)
                        .addGap(22, 22, 22)))
                .addContainerGap())
        );
        pnlRecordsLabExpandLayout.setVerticalGroup(
            pnlRecordsLabExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlRecordsLabExpandLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(pnlRecordsLabExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblRecordsLabCollasp)
                    .addComponent(txtRecordsLabExpandSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlMainContainer.add(pnlRecordsLabExpand, "RecLabCard");

        pnlRecordsConsultancyExpand.setBackground(new java.awt.Color(255, 255, 255));

        tblRecordsConsultancyExpand.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane10.setViewportView(tblRecordsConsultancyExpand);

        lblRecordsConsultancyCollasp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_collapse_40px.png"))); // NOI18N
        lblRecordsConsultancyCollasp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecordsConsultancyCollaspMouseClicked(evt);
            }
        });

        txtRecordsConsultancyExpandSearch.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtRecordsConsultancyExpandSearch.setText("Bill No or Name");
        txtRecordsConsultancyExpandSearch.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtRecordsConsultancyExpandSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtRecordsConsultancyExpandSearchMouseClicked(evt);
            }
        });
        txtRecordsConsultancyExpandSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtRecordsConsultancyExpandSearchKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout pnlRecordsConsultancyExpandLayout = new javax.swing.GroupLayout(pnlRecordsConsultancyExpand);
        pnlRecordsConsultancyExpand.setLayout(pnlRecordsConsultancyExpandLayout);
        pnlRecordsConsultancyExpandLayout.setHorizontalGroup(
            pnlRecordsConsultancyExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRecordsConsultancyExpandLayout.createSequentialGroup()
                .addGroup(pnlRecordsConsultancyExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlRecordsConsultancyExpandLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 1060, Short.MAX_VALUE))
                    .addGroup(pnlRecordsConsultancyExpandLayout.createSequentialGroup()
                        .addGap(329, 329, 329)
                        .addComponent(txtRecordsConsultancyExpandSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblRecordsConsultancyCollasp)
                        .addGap(22, 22, 22)))
                .addContainerGap())
        );
        pnlRecordsConsultancyExpandLayout.setVerticalGroup(
            pnlRecordsConsultancyExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlRecordsConsultancyExpandLayout.createSequentialGroup()
                .addGroup(pnlRecordsConsultancyExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlRecordsConsultancyExpandLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(lblRecordsConsultancyCollasp)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlRecordsConsultancyExpandLayout.createSequentialGroup()
                        .addContainerGap(34, Short.MAX_VALUE)
                        .addComponent(txtRecordsConsultancyExpandSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)))
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlMainContainer.add(pnlRecordsConsultancyExpand, "RecConcCard");

        pnlRecordsIndoorExpand.setBackground(new java.awt.Color(255, 255, 255));

        tblRecordsIndoorExpand.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane11.setViewportView(tblRecordsIndoorExpand);

        lblRecordsIndoorCollasp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_collapse_40px.png"))); // NOI18N
        lblRecordsIndoorCollasp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRecordsIndoorCollaspMouseClicked(evt);
            }
        });

        txtRecordsIndoorExpandSearch.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtRecordsIndoorExpandSearch.setText("Bill No or Name");
        txtRecordsIndoorExpandSearch.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtRecordsIndoorExpandSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtRecordsIndoorExpandSearchMouseClicked(evt);
            }
        });
        txtRecordsIndoorExpandSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtRecordsIndoorExpandSearchKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtRecordsIndoorExpandSearchKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout pnlRecordsIndoorExpandLayout = new javax.swing.GroupLayout(pnlRecordsIndoorExpand);
        pnlRecordsIndoorExpand.setLayout(pnlRecordsIndoorExpandLayout);
        pnlRecordsIndoorExpandLayout.setHorizontalGroup(
            pnlRecordsIndoorExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRecordsIndoorExpandLayout.createSequentialGroup()
                .addGroup(pnlRecordsIndoorExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlRecordsIndoorExpandLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 1060, Short.MAX_VALUE))
                    .addGroup(pnlRecordsIndoorExpandLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtRecordsIndoorExpandSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(321, 321, 321)
                        .addComponent(lblRecordsIndoorCollasp)
                        .addGap(22, 22, 22)))
                .addContainerGap())
        );
        pnlRecordsIndoorExpandLayout.setVerticalGroup(
            pnlRecordsIndoorExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlRecordsIndoorExpandLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(pnlRecordsIndoorExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblRecordsIndoorCollasp)
                    .addComponent(txtRecordsIndoorExpandSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlMainContainer.add(pnlRecordsIndoorExpand, "RecIndoorCard");

        pnlAppointmentViewExpand.setBackground(new java.awt.Color(255, 255, 255));

        txtViewAppointmentExpandSearch.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtViewAppointmentExpandSearch.setText("Patient ID or Doctor Name");
        txtViewAppointmentExpandSearch.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtViewAppointmentExpandSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtViewAppointmentExpandSearchMouseClicked(evt);
            }
        });
        txtViewAppointmentExpandSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtViewAppointmentExpandSearchActionPerformed(evt);
            }
        });
        txtViewAppointmentExpandSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtViewAppointmentExpandSearchKeyReleased(evt);
            }
        });

        tblAppointmentSearchExpand.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane12.setViewportView(tblAppointmentSearchExpand);

        lblViewAppointmentCollasp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_collapse_40px.png"))); // NOI18N
        lblViewAppointmentCollasp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblViewAppointmentCollaspMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlAppointmentViewExpandLayout = new javax.swing.GroupLayout(pnlAppointmentViewExpand);
        pnlAppointmentViewExpand.setLayout(pnlAppointmentViewExpandLayout);
        pnlAppointmentViewExpandLayout.setHorizontalGroup(
            pnlAppointmentViewExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAppointmentViewExpandLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtViewAppointmentExpandSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(322, 322, 322)
                .addComponent(lblViewAppointmentCollasp)
                .addGap(32, 32, 32))
            .addGroup(pnlAppointmentViewExpandLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 1060, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlAppointmentViewExpandLayout.setVerticalGroup(
            pnlAppointmentViewExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAppointmentViewExpandLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(pnlAppointmentViewExpandLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblViewAppointmentCollasp)
                    .addComponent(txtViewAppointmentExpandSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlMainContainer.add(pnlAppointmentViewExpand, "AppointmentViewCard");

        pnlIndoorPatientViewExpand.setBackground(new java.awt.Color(255, 255, 255));
        pnlIndoorPatientViewExpand.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btngrpIndoorPatientViewListSort.add(rbtnIndoorViewListIDExpand);
        rbtnIndoorViewListIDExpand.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnIndoorViewListIDExpand.setText("Patient ID");
        rbtnIndoorViewListIDExpand.setOpaque(false);
        rbtnIndoorViewListIDExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnIndoorViewListIDExpandActionPerformed(evt);
            }
        });
        pnlIndoorPatientViewExpand.add(rbtnIndoorViewListIDExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 70, 140, -1));

        rbtnIndoorViewListNameExpand.setBackground(new java.awt.Color(255, 255, 255));
        btngrpIndoorPatientViewListSort.add(rbtnIndoorViewListNameExpand);
        rbtnIndoorViewListNameExpand.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnIndoorViewListNameExpand.setText("Patient Name");
        rbtnIndoorViewListNameExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnIndoorViewListNameExpandActionPerformed(evt);
            }
        });
        pnlIndoorPatientViewExpand.add(rbtnIndoorViewListNameExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 40, 133, -1));

        btngrpIndoorPatientViewListSort.add(rbtnIndoorViewListDocRefExpand);
        rbtnIndoorViewListDocRefExpand.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnIndoorViewListDocRefExpand.setText("Doctor Reference");
        rbtnIndoorViewListDocRefExpand.setOpaque(false);
        rbtnIndoorViewListDocRefExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnIndoorViewListDocRefExpandActionPerformed(evt);
            }
        });
        pnlIndoorPatientViewExpand.add(rbtnIndoorViewListDocRefExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 100, -1, 30));

        btngrpIndoorPatientViewListSort.add(rbtnIndoorViewListR_WExpand);
        rbtnIndoorViewListR_WExpand.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnIndoorViewListR_WExpand.setText("Room/Ward");
        rbtnIndoorViewListR_WExpand.setOpaque(false);
        rbtnIndoorViewListR_WExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnIndoorViewListR_WExpandActionPerformed(evt);
            }
        });
        pnlIndoorPatientViewExpand.add(rbtnIndoorViewListR_WExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 130, 133, -1));

        txtIndoorViewListSearchExpand.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtIndoorViewListSearchExpand.setText("Patient Name");
        txtIndoorViewListSearchExpand.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtIndoorViewListSearchExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtIndoorViewListSearchExpandMouseClicked(evt);
            }
        });
        txtIndoorViewListSearchExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIndoorViewListSearchExpandActionPerformed(evt);
            }
        });
        txtIndoorViewListSearchExpand.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtIndoorViewListSearchExpandKeyReleased(evt);
            }
        });
        pnlIndoorPatientViewExpand.add(txtIndoorViewListSearchExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 70, 300, 30));

        jScrollPane15.setPreferredSize(new java.awt.Dimension(1060, 600));

        jTable1Expand.setAutoCreateRowSorter(true);
        jTable1Expand.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTable1Expand.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane15.setViewportView(jTable1Expand);

        pnlIndoorPatientViewExpand.add(jScrollPane15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 1060, 580));

        lblIndoorPatientViewCollasp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_collapse_40px.png"))); // NOI18N
        lblIndoorPatientViewCollasp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblIndoorPatientViewCollaspMouseClicked(evt);
            }
        });
        pnlIndoorPatientViewExpand.add(lblIndoorPatientViewCollasp, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 20, -1, -1));

        pnlMainContainer.add(pnlIndoorPatientViewExpand, "IndoorViewCard");

        pnlBedWardViewExpand.setBackground(new java.awt.Color(255, 255, 255));
        pnlBedWardViewExpand.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtViewBedWardSearchExpand.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtViewBedWardSearchExpand.setText("Ward Type or Ward No");
        txtViewBedWardSearchExpand.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtViewBedWardSearchExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtViewBedWardSearchExpandMouseClicked(evt);
            }
        });
        txtViewBedWardSearchExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtViewBedWardSearchExpandActionPerformed(evt);
            }
        });
        txtViewBedWardSearchExpand.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtViewBedWardSearchExpandKeyReleased(evt);
            }
        });
        pnlBedWardViewExpand.add(txtViewBedWardSearchExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(344, 64, 300, 30));

        rbtnViewBedWardAvblExpand.setBackground(new java.awt.Color(255, 255, 255));
        btngrpViewBedWardrev_avlb.add(rbtnViewBedWardAvblExpand);
        rbtnViewBedWardAvblExpand.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnViewBedWardAvblExpand.setText("Available");
        rbtnViewBedWardAvblExpand.setPreferredSize(new java.awt.Dimension(90, 30));
        rbtnViewBedWardAvblExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnViewBedWardAvblExpandActionPerformed(evt);
            }
        });
        pnlBedWardViewExpand.add(rbtnViewBedWardAvblExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 100, 102, -1));

        rbtnViewBedWardRevExpand.setBackground(new java.awt.Color(255, 255, 255));
        btngrpViewBedWardrev_avlb.add(rbtnViewBedWardRevExpand);
        rbtnViewBedWardRevExpand.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnViewBedWardRevExpand.setText("Reserved");
        rbtnViewBedWardRevExpand.setPreferredSize(new java.awt.Dimension(90, 30));
        rbtnViewBedWardRevExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnViewBedWardRevExpandActionPerformed(evt);
            }
        });
        pnlBedWardViewExpand.add(rbtnViewBedWardRevExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 70, 102, -1));

        rbtnViewBedWardAllExpand.setBackground(new java.awt.Color(255, 255, 255));
        btngrpViewBedWardrev_avlb.add(rbtnViewBedWardAllExpand);
        rbtnViewBedWardAllExpand.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnViewBedWardAllExpand.setText("All");
        rbtnViewBedWardAllExpand.setPreferredSize(new java.awt.Dimension(90, 30));
        rbtnViewBedWardAllExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnViewBedWardAllExpandActionPerformed(evt);
            }
        });
        pnlBedWardViewExpand.add(rbtnViewBedWardAllExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 40, 102, -1));

        tblViewBedWardExpand.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane13.setViewportView(tblViewBedWardExpand);

        pnlBedWardViewExpand.add(jScrollPane13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 203, 1060, 554));

        lblBedWardViewCollasp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_collapse_40px.png"))); // NOI18N
        lblBedWardViewCollasp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblBedWardViewCollaspMouseClicked(evt);
            }
        });
        pnlBedWardViewExpand.add(lblBedWardViewCollasp, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 20, -1, -1));

        pnlMainContainer.add(pnlBedWardViewExpand, "BedWardViewCard");

        pnlBedRoomViewExpand.setBackground(new java.awt.Color(255, 255, 255));
        pnlBedRoomViewExpand.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rbtnViewBedRoomAvblExpand.setBackground(new java.awt.Color(255, 255, 255));
        btngrpViewBedRoomrev_avlb.add(rbtnViewBedRoomAvblExpand);
        rbtnViewBedRoomAvblExpand.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnViewBedRoomAvblExpand.setText("Available");
        rbtnViewBedRoomAvblExpand.setBorder(null);
        rbtnViewBedRoomAvblExpand.setPreferredSize(new java.awt.Dimension(90, 30));
        rbtnViewBedRoomAvblExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnViewBedRoomAvblExpandActionPerformed(evt);
            }
        });
        pnlBedRoomViewExpand.add(rbtnViewBedRoomAvblExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 90, 102, 30));

        rbtnViewBedRoomRevExpand.setBackground(new java.awt.Color(255, 255, 255));
        btngrpViewBedRoomrev_avlb.add(rbtnViewBedRoomRevExpand);
        rbtnViewBedRoomRevExpand.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnViewBedRoomRevExpand.setText("Reserved");
        rbtnViewBedRoomRevExpand.setBorder(null);
        rbtnViewBedRoomRevExpand.setPreferredSize(new java.awt.Dimension(90, 30));
        rbtnViewBedRoomRevExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnViewBedRoomRevExpandActionPerformed(evt);
            }
        });
        pnlBedRoomViewExpand.add(rbtnViewBedRoomRevExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 60, 102, 30));

        txtViewBedRoomSearchExpand.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtViewBedRoomSearchExpand.setText("Room Type or Room No");
        txtViewBedRoomSearchExpand.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtViewBedRoomSearchExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtViewBedRoomSearchExpandMouseClicked(evt);
            }
        });
        txtViewBedRoomSearchExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtViewBedRoomSearchExpandActionPerformed(evt);
            }
        });
        txtViewBedRoomSearchExpand.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtViewBedRoomSearchExpandKeyReleased(evt);
            }
        });
        pnlBedRoomViewExpand.add(txtViewBedRoomSearchExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 60, 300, 30));

        rbtnViewBedRoomAllExpand.setBackground(new java.awt.Color(255, 255, 255));
        btngrpViewBedRoomrev_avlb.add(rbtnViewBedRoomAllExpand);
        rbtnViewBedRoomAllExpand.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        rbtnViewBedRoomAllExpand.setText("All");
        rbtnViewBedRoomAllExpand.setBorder(null);
        rbtnViewBedRoomAllExpand.setPreferredSize(new java.awt.Dimension(90, 30));
        rbtnViewBedRoomAllExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnViewBedRoomAllExpandActionPerformed(evt);
            }
        });
        pnlBedRoomViewExpand.add(rbtnViewBedRoomAllExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 30, 102, 30));

        tblViewBedRoomExpand.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane14.setViewportView(tblViewBedRoomExpand);

        pnlBedRoomViewExpand.add(jScrollPane14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 174, 1060, 580));

        lblBedRoomViewCollasp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_collapse_40px.png"))); // NOI18N
        lblBedRoomViewCollasp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblBedRoomViewCollaspMouseClicked(evt);
            }
        });
        pnlBedRoomViewExpand.add(lblBedRoomViewCollasp, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 20, -1, -1));

        pnlMainContainer.add(pnlBedRoomViewExpand, "BedRoomViewCard");

        pnlPDSearchExpand.setBackground(new java.awt.Color(255, 255, 255));
        pnlPDSearchExpand.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        spPDSearch2.setBackground(new java.awt.Color(255, 255, 255));
        spPDSearch2.setForeground(new java.awt.Color(255, 255, 255));

        tblPDSearchExpand.setAutoCreateRowSorter(true);
        tblPDSearchExpand.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(51, 51, 255)));
        tblPDSearchExpand.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tblPDSearchExpand.setForeground(new java.awt.Color(0, 51, 255));
        tblPDSearchExpand.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblPDSearchExpand.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tblPDSearchExpand.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tblPDSearchExpand.setGridColor(new java.awt.Color(51, 51, 255));
        tblPDSearchExpand.setMaximumSize(new java.awt.Dimension(1060, 650));
        tblPDSearchExpand.setMinimumSize(new java.awt.Dimension(1060, 650));
        tblPDSearchExpand.setPreferredSize(new java.awt.Dimension(1060, 650));
        tblPDSearchExpand.setRequestFocusEnabled(false);
        tblPDSearchExpand.setRowHeight(20);
        tblPDSearchExpand.setSelectionForeground(new java.awt.Color(255, 51, 0));
        tblPDSearchExpand.setShowGrid(true);
        tblPDSearchExpand.getTableHeader().setReorderingAllowed(false);
        spPDSearch2.setViewportView(tblPDSearchExpand);

        pnlPDSearchExpand.add(spPDSearch2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 107, 1060, 650));

        txtPDExpandSearch.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        txtPDExpandSearch.setText("Patient Name");
        txtPDExpandSearch.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtPDExpandSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPDExpandSearchMouseClicked(evt);
            }
        });
        txtPDExpandSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPDExpandSearchKeyReleased(evt);
            }
        });
        pnlPDSearchExpand.add(txtPDExpandSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(399, 32, 340, 30));

        lblPDSearchCollasp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_collapse_40px.png"))); // NOI18N
        lblPDSearchCollasp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPDSearchCollaspMouseClicked(evt);
            }
        });
        pnlPDSearchExpand.add(lblPDSearchCollasp, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 20, -1, -1));

        pnlMainContainer.add(pnlPDSearchExpand, "PDSearchCard");

        pnlPDConfirmExpand.setBackground(new java.awt.Color(255, 255, 255));
        pnlPDConfirmExpand.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        spPDSearch3.setBackground(new java.awt.Color(255, 255, 255));
        spPDSearch3.setForeground(new java.awt.Color(255, 255, 255));

        tblPDConfirmExpand.setAutoCreateRowSorter(true);
        tblPDConfirmExpand.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(51, 51, 255)));
        tblPDConfirmExpand.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tblPDConfirmExpand.setForeground(new java.awt.Color(0, 51, 255));
        tblPDConfirmExpand.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Kin", "Gender", "Date of Birth", "Email", "Contact", "Blood Group", "Address", "Username"
            }
        ));
        tblPDConfirmExpand.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tblPDConfirmExpand.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tblPDConfirmExpand.setGridColor(new java.awt.Color(51, 51, 255));
        tblPDConfirmExpand.setMaximumSize(new java.awt.Dimension(750, 500));
        tblPDConfirmExpand.setMinimumSize(new java.awt.Dimension(750, 500));
        tblPDConfirmExpand.setPreferredSize(new java.awt.Dimension(1060, 560));
        tblPDConfirmExpand.setRequestFocusEnabled(false);
        tblPDConfirmExpand.setRowHeight(20);
        tblPDConfirmExpand.setSelectionForeground(new java.awt.Color(255, 51, 0));
        tblPDConfirmExpand.setShowGrid(true);
        tblPDConfirmExpand.getTableHeader().setReorderingAllowed(false);
        tblPDConfirmExpand.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPDConfirmExpandMouseClicked(evt);
            }
        });
        spPDSearch3.setViewportView(tblPDConfirmExpand);

        pnlPDConfirmExpand.add(spPDSearch3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 102, 1060, 560));

        btnPDConfirmPatientExpand.setText("Confirm Patient ");
        btnPDConfirmPatientExpand.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnPDConfirmPatientExpand.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnPDConfirmPatientExpand.setkBorderRadius(15);
        btnPDConfirmPatientExpand.setkEndColor(new java.awt.Color(102, 255, 102));
        btnPDConfirmPatientExpand.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnPDConfirmPatientExpand.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnPDConfirmPatientExpand.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnPDConfirmPatientExpand.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnPDConfirmPatientExpand.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnPDConfirmPatientExpand.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnPDConfirmPatientExpand.setkStartColor(new java.awt.Color(0, 153, 0));
        btnPDConfirmPatientExpand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDConfirmPatientExpandActionPerformed(evt);
            }
        });
        pnlPDConfirmExpand.add(btnPDConfirmPatientExpand, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 690, 200, 50));

        lblPDConfirmCollasp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_collapse_40px.png"))); // NOI18N
        lblPDConfirmCollasp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPDConfirmCollaspMouseClicked(evt);
            }
        });
        pnlPDConfirmExpand.add(lblPDConfirmCollasp, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 20, -1, -1));

        pnlMainContainer.add(pnlPDConfirmExpand, "PDConfirmCard");

        getContentPane().add(pnlMainContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1080, 768));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnRecepFrontLabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecepFrontLabActionPerformed
        
        cardlayout.show(pnlRecepContentContainer,"LabCard");
    }//GEN-LAST:event_btnRecepFrontLabActionPerformed

    private void btnRecepFrontBedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecepFrontBedActionPerformed
        // TODO add your handling code here:
        cardlayout.show(pnlRecepContentContainer,"ViewBedCard");
    }//GEN-LAST:event_btnRecepFrontBedActionPerformed

    private void btnRecepFrontAppointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecepFrontAppointmentActionPerformed
        // TODO add your handling code here:
        cardlayout.show(pnlRecepContentContainer,"AppointmentCard");
        
    }//GEN-LAST:event_btnRecepFrontAppointmentActionPerformed

    private void btnRecepFrontAdmitPatientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecepFrontAdmitPatientActionPerformed
        // TODO add your handling code here:
        cardlayout.show(pnlRecepContentContainer,"AddPatientCard");
    }//GEN-LAST:event_btnRecepFrontAdmitPatientActionPerformed

    private void lblPhnNumComponentMoved(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_lblPhnNumComponentMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_lblPhnNumComponentMoved

    private void txtPatientIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPatientIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPatientIDActionPerformed

    private void txtPhnNumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPhnNumActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhnNumActionPerformed

    private void cbATimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbATimeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbATimeActionPerformed

    private void btnBAppointmentSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBAppointmentSubmitActionPerformed

        
        try {
            Statement stmt =con.createStatement();
                    String select = "select * from appointments_record";
                    ResultSet rsst = stmt.executeQuery(select);

                     SimpleDateFormat sdf= new SimpleDateFormat("dd-MM-yyyy");
                String date_today= LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
                String date_a=sdf.format(jcalADate.getDate());
                int a;
                a=date_a.compareToIgnoreCase(date_today);
                    int fl=0;

                    while(rsst.next())
                    {

                        if(rsst.getString("time").equals(String.valueOf(cbATime.getSelectedItem()))){
                            if (rsst.getString("date").equals(date_a)){
                                if (rsst.getString("Patient_id").equals(String.valueOf(txtPatientID.getText()))){

                                fl=fl+1;
                                break;
                            }

                               
                            }
                        }

                    }

                    if(fl!=0){
                        JOptionPane.showMessageDialog(null, "Appointment is already booked");

                        Reset();
                    }else
                    {
          
            pstmt=con.prepareStatement("insert into APPOINTMENTS_RECORD (PATIENT_ID,NAME,DOC_NAME,SPECIALISATION,CONTACT,DATE,TIME,DATE_BILL,DOC_CHARGES,AMOUNT) values (?,?,?,?,?,?,?,?,?,?)");
            PreparedStatement pstmt1=con.prepareStatement("insert into APPOINTMENTS_RECORD_TEMPORARY (PATIENT_ID,NAME,DOC_NAME,SPECIALISATION,CONTACT,DATE,TIME,DATE_BILL) values (?,?,?,?,?,?,?,?)");
            
            ResultSet rs=stmt.executeQuery("select * from PATIENT_INFO where PATIENT_ID="+Integer.parseInt(txtPatientID.getText())+"");
            
            int flag=0;
            if (txtPatientID.getText().trim().isEmpty())
            {
                lblBAppointmentMandatory.setVisible(true);
            }
            else
            {
                
                pstmt.setInt(1,Integer.parseInt(txtPatientID.getText()));
                 pstmt1.setInt(1,Integer.parseInt(txtPatientID.getText()));
                flag++;
                
            }
            
            if (cbATime.getSelectedIndex()==0)
            {
                lblBAppointmentMandatory.setVisible(true);
                
            }
            else
            {
                pstmt.setString(7,String.valueOf(cbATime.getSelectedItem()));
                pstmt1.setString(7,String.valueOf(cbATime.getSelectedItem()));
                flag++;
                
            }
            if(txtPhnNum.getText().trim().isEmpty())
            {
                lblBAppointmentMandatory.setVisible(true);
                
            }
            else
            {
                pstmt.setString(5,String.valueOf(cbPhnNum.getSelectedItem())+txtPhnNum.getText());
                  pstmt1.setString(5,String.valueOf(cbPhnNum.getSelectedItem())+txtPhnNum.getText());
                
                flag++;
                
            }
            if(cbDepartment.getSelectedIndex()==0)
            {
                lblBAppointmentMandatory.setVisible(true);
                
            }
            else
            {
                pstmt.setString(4,String.valueOf(cbDepartment.getSelectedItem()));
                 pstmt1.setString(4,String.valueOf(cbDepartment.getSelectedItem()));
                
                flag++;
                
            }
            if(cbDocName.getSelectedIndex()==0)
            {
                lblBAppointmentMandatory.setVisible(true);
                
            }
            else
            {
                pstmt.setString(3,String.valueOf(cbDocName.getSelectedItem()));
                 pstmt1.setString(3,String.valueOf(cbDocName.getSelectedItem()));
                
                flag++;
                
            }
            if (a<0)
                 {
                 
                 lblBAppointmentInvalidDate.setVisible(true);
                         }
                 else
                 {
                 flag++;
                     pstmt.setString(6,date_a );
                pstmt.setString(8,date_today );
                 pstmt1.setString(6,date_a );
                pstmt1.setString(8,date_today );
                 }
            
            
            if(flag==6)
            {
                rs.next();
                pstmt.setString(2,rs.getString("NAME"));
                 pstmt1.setString(2,rs.getString("NAME"));
                
                 
                 lblAppointmentRecieptSex.setText(rs.getString("GENDER"));
                lblAppointmentRecieptName.setText(rs.getString("NAME"));
                lblAppointmentRecieptKin.setText(rs.getString("KIN"));
                lblAppointmentRecieptAge.setText(Age_calc(rs.getString("DOB"),date_today));
                String[] doc_n=String.valueOf(cbDocName.getSelectedItem()).split("[.]+");
                String doc_name=doc_n[1];
                ResultSet docinfo=stmt.executeQuery("select * from DOCTOR_INFO where NAME='"+doc_name+"'");
                docinfo.next();
                double fee=docinfo.getDouble("DOC_CHARGES");
                 double state_gst= fee*0.09;
                double central_gst=fee*0.09;
                double total=fee+state_gst+central_gst;
                pstmt.setDouble(9, fee);
                pstmt.setDouble(10, total);
                pstmt.executeUpdate();
                pstmt1.executeUpdate();
                
               Statement stat=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
               ResultSet rst=stat.executeQuery("select * from APPOINTMENTS_RECORD ");
               rst.last();
               lblAppointmentRecieptBillNo.setText(String.valueOf(rst.getInt(1)));
               lblAppointmentRecieptDate.setText(String.valueOf(date_today));
                lblAppointmentRecieptDocName.setText(String.valueOf(cbDocName.getSelectedItem()));
               lblAppointmentRecieptDocSpec.setText(String.valueOf(cbDepartment.getSelectedItem()));
               
               lblAppointmentRecieptAppointmentDate.setText("Date of Appointment : "+date_a);
               
                
                
                
                lblAppointmentRecieptConChrg.setText(String.valueOf(fee));
               
                lblAppointmentRecieptSTax.setText(String.valueOf(state_gst));
                lblAppointmentRecieptCTax.setText(String.valueOf(central_gst));
                lblAppointmentRecieptAmountPaid.setText(String.valueOf(total));
               appointmentcardlayout.show(pnlAppointmentContainer,"AppointmentRecieptCard");
                            }
            else{
                
                JOptionPane.showMessageDialog(Reception_Front.this,"Error");
                Reset();
            }}
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
            

    }//GEN-LAST:event_btnBAppointmentSubmitActionPerformed

    private void Reset()
    {
        txtPatientID.setText("");
        cbATime.setSelectedIndex(0);
        txtPhnNum.setText("");
        cbDepartment.setSelectedIndex(0);
        cbDocName.setSelectedIndex(0);
        jcalADate.setDate(null);
    }
    
    private void cbDocNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbDocNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbDocNameActionPerformed

    private void btnViewAppointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAppointmentActionPerformed
        // TODO add your handling code here:
        markAppointmentBook.setVisible(false);
        markAppointmentView.setVisible(true);
        appointmentcardlayout.show(pnlAppointmentContainer,"ViewAppointmentCard");
    }//GEN-LAST:event_btnViewAppointmentActionPerformed

    private void tblBedRoomMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBedRoomMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tblBedRoomMouseClicked

    private void rbtnIndoorViewListIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnIndoorViewListIDActionPerformed
        try {
            // TODO add your handling code here:
            txtIndoorViewListSearch.setText("Patient ID");
            ResultSet rstmt =stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR");
            jTable1.setModel(DbUtils.resultSetToTableModel(rstmt));
            customtable(jTable1);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnIndoorViewListIDActionPerformed

    private void rbtnIndoorViewListNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnIndoorViewListNameActionPerformed
        try {
            // TODO add your handling code here:
            txtIndoorViewListSearch.setText("Patient Name");
            ResultSet rstmt =stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR");
            jTable1.setModel(DbUtils.resultSetToTableModel(rstmt));
            customtable(jTable1);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnIndoorViewListNameActionPerformed

    private void rbtnIndoorViewListDocRefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnIndoorViewListDocRefActionPerformed
        try {
            // TODO add your handling code here:
            txtIndoorViewListSearch.setText("Doctor Name");
            ResultSet rstmt =stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR");
            jTable1.setModel(DbUtils.resultSetToTableModel(rstmt));
            customtable(jTable1);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnIndoorViewListDocRefActionPerformed

    private void rbtnIndoorViewListR_WActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnIndoorViewListR_WActionPerformed
        try {
            // TODO add your handling code here:
            txtIndoorViewListSearch.setText("Room/Ward");
            ResultSet rstmt =stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR");
            jTable1.setModel(DbUtils.resultSetToTableModel(rstmt));
            customtable(jTable1);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnIndoorViewListR_WActionPerformed

    private void txtIndoorViewListSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIndoorViewListSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIndoorViewListSearchActionPerformed

    private void txtPDAddPatientNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPDAddPatientNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPDAddPatientNameActionPerformed

    private void txtPDAddKinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPDAddKinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPDAddKinActionPerformed

    private void txtPDAddContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPDAddContactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPDAddContactActionPerformed

    private void txtPDAddStreetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPDAddStreetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPDAddStreetActionPerformed

    private void btnBedWardProceed2BookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBedWardProceed2BookActionPerformed
        // TODO add your handling code here:
        pnlBedWardBooking.setVisible(true);
        int row=tblBedWard.getSelectedRow();
        String ward_type=tblBedWard.getModel().getValueAt(row,1).toString();
        String ward_no=tblBedWard.getModel().getValueAt(row,0).toString();
        String bed_no=tblBedWard.getModel().getValueAt(row,2).toString();
        lblBedWardBookingWardType.setText(ward_type);
        lblBedWardBookingBedN.setText(bed_no);
        lblBedWardBookingWardN.setText(ward_no);
    }//GEN-LAST:event_btnBedWardProceed2BookActionPerformed

    private void btnBedRoomProceed2BookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBedRoomProceed2BookActionPerformed
        // TODO add your handling code here:
        pnlBedRoomBooking.setVisible(true);
        int row=tblBedRoom.getSelectedRow();
        String room_type=tblBedRoom.getModel().getValueAt(row,1).toString();
        String room_no=tblBedRoom.getModel().getValueAt(row,0).toString();
        String bed_no=tblBedRoom.getModel().getValueAt(row,2).toString();
        lblBedRoomBookingRoomType.setText(room_type);
        lblBedRoomBookingBedN.setText(bed_no);
        lblBedRoomBookingRoomN.setText(room_no);
    }//GEN-LAST:event_btnBedRoomProceed2BookActionPerformed

    private void lblRecepFrontDashMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecepFrontDashMouseClicked
        // TODO add your handling code here:
        markRecords.setVisible(false);
        markPD.setVisible(false);
        markSettings.setVisible(false);
        markHelp.setVisible(false);
        markDash.setVisible(true);
        markRecords.setVisible(false);
        markDD.setVisible(false);
       
        cardlayout.show(pnlRecepContentContainer,"DashMainCard");
    }//GEN-LAST:event_lblRecepFrontDashMouseClicked

    private void lblRecepFrontPDBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecepFrontPDBMouseClicked
        // TODO add your handling code here:
         markRecords.setVisible(false);
        markPD.setVisible(true);
        markSettings.setVisible(false);
        markHelp.setVisible(false);
        markDash.setVisible(false);
        markRecords.setVisible(false);
        markDD.setVisible(false);
        cardlayout.show(pnlRecepContentContainer,"PDCard");
    }//GEN-LAST:event_lblRecepFrontPDBMouseClicked

    private void lblRecepFrontRecordsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecepFrontRecordsMouseClicked

        markRecords.setVisible(true);
        markPD.setVisible(false);
        markSettings.setVisible(false);
        markHelp.setVisible(false);
        markDash.setVisible(false);
        markDD.setVisible(false);
        cardlayout.show(pnlRecepContentContainer,"RecordsCard");
    }//GEN-LAST:event_lblRecepFrontRecordsMouseClicked

    private void lblRecepFrontSettingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecepFrontSettingMouseClicked
        // TODO add your handling code here:
         markRecords.setVisible(false);
        markPD.setVisible(false);
        markSettings.setVisible(true);
        markHelp.setVisible(false);
        markDash.setVisible(false);
        markDD.setVisible(false);
    }//GEN-LAST:event_lblRecepFrontSettingMouseClicked

    private void lblRecepFrontHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecepFrontHelpMouseClicked
        // TODO add your handling code here:
         markRecords.setVisible(false);
        markPD.setVisible(false);
        markSettings.setVisible(false);
        markHelp.setVisible(true);
        markDash.setVisible(false);
        markDD.setVisible(false);
    }//GEN-LAST:event_lblRecepFrontHelpMouseClicked

    private void lblRecepFrontLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecepFrontLogoutMouseClicked
        // TODO add your handling code here:
        dispose();
        new admin_login().setVisible(true);
        
    }//GEN-LAST:event_lblRecepFrontLogoutMouseClicked

    private void lblLabBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLabBackMouseClicked
        // TODO add your handling code here:
        cardlayout.show(pnlRecepContentContainer,"DashMainCard");
    }//GEN-LAST:event_lblLabBackMouseClicked

    private void lblAppointmentBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAppointmentBackMouseClicked
        // TODO add your handling code here:
        cardlayout.show(pnlRecepContentContainer,"DashMainCard");
    }//GEN-LAST:event_lblAppointmentBackMouseClicked

    private void lblBedBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBedBackMouseClicked
        // TODO add your handling code here:
        cardlayout.show(pnlRecepContentContainer,"AddPatientCard");
        indoorpatientcardlayout.show(pnlIndoorPatientContainer,"IndoorPatientAdmitCard");
    }//GEN-LAST:event_lblBedBackMouseClicked

    private void lblAddPatientBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAddPatientBackMouseClicked
        // TODO add your handling code here:
        cardlayout.show(pnlRecepContentContainer,"DashMainCard");
    }//GEN-LAST:event_lblAddPatientBackMouseClicked

    private void lblPDBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPDBackMouseClicked
        // TODO add your handling code here:
        cardlayout.show(pnlRecepContentContainer,"DashMainCard");
    }//GEN-LAST:event_lblPDBackMouseClicked

    private void lblDDBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDDBackMouseClicked
        // TODO add your handling code here:
        cardlayout.show(pnlRecepContentContainer,"DashMainCard");
    }//GEN-LAST:event_lblDDBackMouseClicked

    private void btnNewLabTestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewLabTestActionPerformed
        // TODO add your handling code here:
        
        markLabNewTest.setVisible(true);
        labcardlayout.show(pnlLabContainer,"NewTestCard");
    }//GEN-LAST:event_btnNewLabTestActionPerformed

    private void lblLabRecieptBackIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLabRecieptBackIconMouseClicked
        // TODO add your handling code here:
        labcardlayout.show(pnlLabContainer,"NewTestCard");
    }//GEN-LAST:event_lblLabRecieptBackIconMouseClicked

    private void btnAddPatientAdmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddPatientAdmitActionPerformed
        // TODO add your handling code here:
        markAdmitPatient.setVisible(true);
        markIndoorList.setVisible(false);
        markDischargePatient.setVisible(false);
        indoorpatientcardlayout.show(pnlIndoorPatientContainer,"IndoorPatientAdmitCard");
    }//GEN-LAST:event_btnAddPatientAdmitActionPerformed

    private void btnAddPatientViewListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddPatientViewListActionPerformed
        // TODO add your handling code here:
        markAdmitPatient.setVisible(false);
        markIndoorList.setVisible(true);
        markDischargePatient.setVisible(false);
        indoorpatientcardlayout.show(pnlIndoorPatientContainer,"IndoorPatientViewListCard");
    }//GEN-LAST:event_btnAddPatientViewListActionPerformed

    private void btnAddPatientDischargeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddPatientDischargeActionPerformed
        // TODO add your handling code here:
        markAdmitPatient.setVisible(false);
        markIndoorList.setVisible(false);
        markDischargePatient.setVisible(true);
        indoorpatientcardlayout.show(pnlIndoorPatientContainer,"IndoorPatientDischargeCard");
    }//GEN-LAST:event_btnAddPatientDischargeActionPerformed

    private void btnIndoorPatientDischargeGenerateBillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIndoorPatientDischargeGenerateBillActionPerformed
        try {
            // TODO add your handling code here:
            
            if(txtIndoorPatientDischargePatientID.getText().isEmpty())
            {
            
            lblDischargeWarning.setVisible(true);
            }
            else
            {
         
             ResultSet patient_indoor=stmt.executeQuery("select * from INDOOR where DISCHARGE_DATE is null and PATIENT_ID="+Integer.parseInt(txtIndoorPatientDischargePatientID.getText()));
                patient_indoor.next();
            SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
                String date=String.valueOf(LocalDate.now());
                int daysss=days(patient_indoor.getString("ADMIT_DATE"),date);
                double consultation_Charges= patient_indoor.getDouble("DOC_CHARGES")*daysss;
                double utility_Charges= patient_indoor.getDouble("BED_CHARGES")*daysss;
                double service_Charges= 200*daysss;
                double total1=consultation_Charges+ utility_Charges + service_Charges;
                double total2=total1+(0.18*total1);
                System.out.println("done");
                
                
            pstmt=con.prepareStatement("Update INDOOR set DISCHARGE_DATE='"+date+"',DAYS="+daysss+",CONSULTATION_CHARGES="+consultation_Charges+",SERVICE_CHARGES="+service_Charges+",UTILITY_CHARGES="+utility_Charges+",TOTAL_AMT="+total2+" where DISCHARGE_DATE is null and PATIENT_ID="+Integer.parseInt(txtIndoorPatientDischargePatientID.getText()));
                
            pstmt.executeUpdate();
                ResultSet patient_info=stmt.executeQuery("select * from PATIENT_INFO where PATIENT_ID="+Integer.parseInt(txtIndoorPatientDischargePatientID.getText()));
                patient_info.next();
                String agggeee=Age_calc(patient_info.getString("DOB"),date);
             ResultSet dis=stmt.executeQuery("select * from INDOOR where PATIENT_ID="+Integer.parseInt(txtIndoorPatientDischargePatientID.getText())+" and DISCHARGE_DATE='"+date+"'");
             dis.next();
             String[] temp=dis.getString("DOC_NAME_SPECIALISATION").split("-");
             
             lblIndoorBilBillNo.setText(String.valueOf(dis.getInt("BILL_NO")));
             lblIndoorBilName.setText(dis.getString("NAME"));
             lblIndoorBilKin.setText(dis.getString("KIN"));
             lblIndoorBilAdmitDate.setText(dis.getString("ADMIT_DATE"));
             lblIndoorBilDisease.setText(dis.getString("DISEASE"));
             lblIndoorBilAge.setText(agggeee);
             lblIndoorBilDate.setText(date);
             lblIndoorBilSex.setText(dis.getString("GENDER"));
             lblIndoorBilDischargeDate.setText(date);
             lblIndoorBilTDays.setText(String.valueOf(daysss));
             lblIndoorBilDocName.setText(temp[0]);
             lblIndoorBilDocSpec.setText(temp[1]);
             lblIndoorBilConChrg.setText(String.valueOf(dis.getDouble("CONSULTATION_CHARGES")));
             lblIndoorBilRoomChrg.setText(String.valueOf(dis.getDouble("UTILITY_CHARGES")));
             lblIndoorBilSC.setText(String.valueOf(dis.getDouble("SERVICE_CHARGES")));
             lblIndoorBilSTax.setText(String.valueOf(0.09*total1));
             lblIndoorBilCTax.setText(String.valueOf(0.09*total1));
             lblIndoorBilAmountPaid.setText(String.valueOf(total2));
             
            indoorpatientcardlayout.show(pnlIndoorPatientContainer,"IndoorPatientBillCard");
        }
           
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnIndoorPatientDischargeGenerateBillActionPerformed

    private void lblIndoorBilBackIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblIndoorBilBackIconMouseClicked
        // TODO add your handling code here:
        indoorpatientcardlayout.show(pnlIndoorPatientContainer,"IndoorPatientDischargeCard");
    }//GEN-LAST:event_lblIndoorBilBackIconMouseClicked

    private void btnPDConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDConfirmActionPerformed
        // TODO add your handling code here:
        markAddPatient.setVisible(false);
        markPDConfirm.setVisible(true);
        markPdSearch.setVisible(false);
        PDcardlayout.show(pnlPDContainer,"PDConfirmCard");
    }//GEN-LAST:event_btnPDConfirmActionPerformed

    private void btnBedWardBookingCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBedWardBookingCancelActionPerformed
        // TODO add your handling code here:
        pnlBedWardBooking.setVisible(false);
    }//GEN-LAST:event_btnBedWardBookingCancelActionPerformed

    private void btnBedWardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBedWardActionPerformed
        // TODO add your handling code here:
        markBedBookingWard.setVisible(true);
        markBedBookingRoom.setVisible(false);
        bedcardlayout.show(pnlBedContainer,"BedWardCard");
    }//GEN-LAST:event_btnBedWardActionPerformed

    private void btnBedRoomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBedRoomActionPerformed
        // TODO add your handling code here:
        markBedBookingWard.setVisible(false);
        markBedBookingRoom.setVisible(true);
        bedcardlayout.show(pnlBedContainer,"BedRoomCard");
    }//GEN-LAST:event_btnBedRoomActionPerformed

    private void lblAppointmentRecieptBackIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAppointmentRecieptBackIconMouseClicked
        // TODO add your handling code here:
        appointmentcardlayout.show(pnlAppointmentContainer,"AppointmentBookingCard");
    }//GEN-LAST:event_lblAppointmentRecieptBackIconMouseClicked

    private void btnPDAddAddPatientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDAddAddPatientActionPerformed
        try{
            SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
                String date=sdf.format(jcalPDAddDOB.getDate());
                String date_today= LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
                int a;
                a=date_today.compareToIgnoreCase(date);
                
            
            pstmt=con.prepareStatement("insert into PATIENT_INFO (NAME,GENDER,DOB,BG,CONTACT,ADDRESS,KIN) values(?,?,?,?,?,?,?)");
                int flag=0;
                if(txtPDAddPatientName.getText().trim().isEmpty())
                {
                    lblPDAddMandatory.setVisible(true);
                }
                else
                {
                pstmt.setString(1, txtPDAddPatientName.getText());
                flag++;
                
                }
                if(txtPDAddKin.getText().trim().isEmpty())
                {
                    lblPDAddMandatory.setVisible(true);
                }
                else
                {
                pstmt.setString(7, txtPDAddKin.getText());
                flag++;
                
                }
                if(txtPDAddContact.getText().trim().isEmpty())
                {
                    lblPDAddMandatory.setVisible(true);
                }
                else
                {
                String phn= String.valueOf(cbPDAddContact.getSelectedItem())+txtPDAddContact.getText();
                pstmt.setString(5,phn);
                flag++;
                
                }
                if(cbPDAddBloodGrp.getSelectedIndex()==0)
                {
                lblPDAddMandatory.setVisible(true);
                }
                else
                {
                pstmt.setString(4,String.valueOf(cbPDAddBloodGrp.getSelectedItem()));
                flag++;
                }
                if (cbPDAddGender.getSelectedIndex()==0)
                {
                lblPDAddMandatory.setVisible(true);
                }
                else{
                pstmt.setString(2,String.valueOf(cbPDAddGender.getSelectedItem()));
                flag++;
                
                }
                if(jcalPDAddDOB.getDate()==null)
                {
                lblPDAddMandatory.setVisible(true);
                }
                else if(a<0)
                {
                lblPDAddInvalidDate.setVisible(true);
                }
                
                else
                {
                
                pstmt.setString(3,date);
                flag++;
                
                }
                if(txtPDAddStreet.getText().trim().isEmpty())
                {
                
                lblPDAddMandatory.setVisible(true);
                }
                else
                {
                if(cbPDAddState.getSelectedIndex()==0)
                {
                lblPDAddMandatory.setVisible(true);
                }
                else
                {
                if(cbPDAddCity.getSelectedIndex()==0)
                {
                lblPDAddMandatory.setVisible(true);
                }
                else
                {
                String Address= (txtPDAddStreet.getText())+", "+String.valueOf(cbPDAddCity.getSelectedItem())+", "+String.valueOf(cbPDAddState.getSelectedItem());
                pstmt.setString(6, Address);
                flag++;
                
                }
                }
                }
                
                if(flag==7){ 
                    
                    pstmt.executeUpdate();
                    txtPDAddContact.setText("");
                    txtPDAddKin.setText("");
                    txtPDAddPatientName.setText("");
                    txtPDAddStreet.setText("");
                    cbPDAddBloodGrp.setSelectedIndex(0);
                    cbPDAddCity.setSelectedIndex(1);
                    cbPDAddGender.setSelectedIndex(0);
                    cbPDAddState.setSelectedIndex(0);
                    jcalPDAddDOB.setDate(null);
                    
                    JOptionPane.showMessageDialog(null,"Data Successfully Added");}
        
        }
        catch(SQLException e){
        
        e.getMessage();
        
        }
        
        
    }//GEN-LAST:event_btnPDAddAddPatientActionPerformed

    private void cbPDAddContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPDAddContactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbPDAddContactActionPerformed

    private void cbPDAddCityItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbPDAddCityItemStateChanged
        // TODO add your handling code here:
      
        
    }//GEN-LAST:event_cbPDAddCityItemStateChanged

    private void cbPDAddCityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPDAddCityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbPDAddCityActionPerformed

    private void cbPDAddStateItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbPDAddStateItemStateChanged
        // TODO add your handling code here:
        
                try{
        stmt=con.createStatement();
        ResultSet rs=stmt.executeQuery("select CITIES from statewise_cities where STATES='"+String.valueOf(cbPDAddState.getSelectedItem())+"'");
        cbPDAddCity.removeAllItems();
        cbPDAddCity.addItem("Select City");
        while(rs.next())
        {
        cbPDAddCity.addItem(rs.getString("CITIES"));
        
        }
        
        }
        catch(SQLException e){
            e.getMessage();
        }
    
         
    }//GEN-LAST:event_cbPDAddStateItemStateChanged

    private void btnPDAddPatientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDAddPatientActionPerformed
        // TODO add your handling code here:
        markAddPatient.setVisible(true);
        markPDConfirm.setVisible(false);
        markPdSearch.setVisible(false);
        PDcardlayout.show(pnlPDContainer,"PDAddCard");
    }//GEN-LAST:event_btnPDAddPatientActionPerformed

    private void cbDepartmentItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbDepartmentItemStateChanged
        // TODO add your handling code here:
           try{
        stmt=con.createStatement();
        ResultSet rst=stmt.executeQuery("select NAME from DOCTOR_INFO where SPECIALISATION='"+String.valueOf(cbDepartment.getSelectedItem())+"'");
        cbDocName.removeAllItems();
        cbDocName.addItem("Select Doctor");
        while(rst.next())
        {
        cbDocName.addItem("Dr."+rst.getString("Name"));
        
        }
        
        }
        catch(SQLException e){
            e.getMessage();
        }
    }//GEN-LAST:event_cbDepartmentItemStateChanged

    private void cbPhnNumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPhnNumActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbPhnNumActionPerformed

    private void btnIndoorPatientAdmitAdmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIndoorPatientAdmitAdmitActionPerformed
        try {
            // TODO add your handling code here:
             String abc=String.valueOf(jComboBox2.getSelectedItem());
             String[] tempe=abc.split("[.]+");
            String[] temp=tempe[1].split("-");
            
            pstmt=con.prepareStatement("insert into INDOOR (PATIENT_ID,NAME,GENDER,BG,CONTACT,DISEASE,DOC_NAME_SPECIALISATION,ADMIT_DATE,DOC_CHARGES,KIN) values(?,?,?,?,?,?,?,?,?,?)");
            ResultSet rs=stmt.executeQuery("select * from PATIENT_INFO where PATIENT_ID="+Integer.parseInt(jTextField1.getText())+"");
            
            
            int flag=0;
            if(jTextField1.getText().trim().isEmpty())
            {
            lblBAppointmentMandatory1.setVisible(true);
            }
            else
            {
            flag++;
                pstmt.setInt(1,Integer.parseInt(jTextField1.getText()));
            }
          
            if(jTextField2.getText().trim().isEmpty())
            {
            lblBAppointmentMandatory1.setVisible(true);
            }
            else
            {
            pstmt.setString(5,jTextField2.getText());
            flag++;
            }
            if(jTextField3.getText().trim().isEmpty())
            {
            lblBAppointmentMandatory1.setVisible(true);
            }
            else
            {
            pstmt.setString(6,jTextField3.getText());
            flag++;
            }
            if(jComboBox2.getSelectedIndex()==0)
            {
            lblBAppointmentMandatory1.setVisible(true);
            }
            else
            {
            
           
            
            
            pstmt.setString(7,tempe[1]);
            flag++;
            }
            if(flag==4)
            {
                System.out.println(tempe[0]);
                System.out.println(tempe[1]);
            rs.next();
            pstmt.setString(2,rs.getString("NAME"));
            pstmt.setString(3,rs.getString("GENDER"));
            pstmt.setString(4,rs.getString("BG"));
            pstmt.setString(10,rs.getString("KIN"));
            pstmt.setString(8,String.valueOf(LocalDate.now()));
            
            ResultSet doc=stmt.executeQuery("select * from DOCTOR_INFO where NAME='"+temp[0]+"' and SPECIALISATION='"+temp[1]+"'");
            doc.next();
            pstmt.setDouble(9,doc.getDouble("DOC_CHARGES"));
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(Reception_Front.this,"Patient Successfully Admitted");
            
            }
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnIndoorPatientAdmitAdmitActionPerformed

    private void txtPDSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtPDSearchMouseClicked
        // TODO add your handling code here:
        txtPDSearch.setText("");
        txtPDSearch.grabFocus();
    }//GEN-LAST:event_txtPDSearchMouseClicked

    private void txtDDSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDDSearchMouseClicked
        // TODO add your handling code here:
        txtDDSearch.setText("");
        txtDDSearch.grabFocus();

    }//GEN-LAST:event_txtDDSearchMouseClicked

    private void rbtnDDSearchNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbtnDDSearchNameMouseClicked
        // TODO add your handling code here:
        
                
    }//GEN-LAST:event_rbtnDDSearchNameMouseClicked

    private void rbtnDDSearchSpecialisationMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbtnDDSearchSpecialisationMouseClicked
        // TODO add your handling code here:
       
    }//GEN-LAST:event_rbtnDDSearchSpecialisationMouseClicked

    private void txtIndoorViewListSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtIndoorViewListSearchMouseClicked
        // TODO add your handling code here:
        txtIndoorViewListSearch.setText("");
        txtIndoorViewListSearch.grabFocus();
       
    }//GEN-LAST:event_txtIndoorViewListSearchMouseClicked

    private void rbtnBedWardNACActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnBedWardNACActionPerformed
        try {
            ResultSet rs=stmt.executeQuery("select distinct WARD_TYPE from WARD where AC_NONAC='Non A.C.'");
            cbBedWard.removeAllItems();
            cbBedWard.addItem("Select Ward Type");
            while(rs.next())
            {
                cbBedWard.addItem(rs.getString("WARD_TYPE"));
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnBedWardNACActionPerformed

    private void rbtnBedWardACActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnBedWardACActionPerformed
        // TODO add your handling code here:
        try {
            ResultSet rs=stmt.executeQuery("select distinct WARD_TYPE,WARD_CHARGES from WARD where AC_NONAC='A.C.'");
            cbBedWard.removeAllItems();
            cbBedWard.addItem("Select Ward Type");
            while(rs.next())
            {
                cbBedWard.addItem(rs.getString("WARD_TYPE"));
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_rbtnBedWardACActionPerformed

    private void btnBedWardCheckAvailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBedWardCheckAvailActionPerformed
        try {
            // TODO add your handling code here:
           if (rbtnBedWardAC.isSelected())
           {spBedWard.setVisible(true);
            tblBedWard.setVisible(true);
            ResultSet rs=stmt.executeQuery("select * from WARD where WARD_TYPE='"+String.valueOf(cbBedWard.getSelectedItem())+"' and AC_NONAC='A.C.'");
            tblBedWard.setModel(DbUtils.resultSetToTableModel(rs));
               customtable(tblBedWard);
            btnBedWardProceed2Book.setVisible(true);}
           else
           {
           spBedWard.setVisible(true);
            tblBedWard.setVisible(true);
            ResultSet rs=stmt.executeQuery("select * from WARD where WARD_TYPE='"+String.valueOf(cbBedWard.getSelectedItem())+"' and AC_NONAC='Non A.C.'");
            tblBedWard.setModel(DbUtils.resultSetToTableModel(rs));
               customtable(tblBedWard);
            btnBedWardProceed2Book.setVisible(true);
           }
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_btnBedWardCheckAvailActionPerformed

    private void btnBedWardBookingBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBedWardBookingBookActionPerformed
        try {
            // TODO add your handling code here:
            
            if(txtBedWardBookingPatientID.getText().trim().isEmpty())
            {
            lblBedWardBookingWarning.setVisible(true);
            }
            else
            {
            
            String ac_nonac=tblBedWard.getModel().getValueAt(tblBedWard.getSelectedRow(),3).toString();
            double price=Double.parseDouble(tblBedWard.getModel().getValueAt(tblBedWard.getSelectedRow(),5).toString());
            String ward_type=lblBedWardBookingWardType.getText();
            int bed_no=Integer.parseInt(lblBedWardBookingBedN.getText());
            int ward_no=(Integer.parseInt(lblBedWardBookingWardN.getText()));    
            pstmt=con.prepareStatement("Update INDOOR set WARD_ROOM_TYPE='"+ward_type+"',BED_NO="+bed_no+",AC_NON_AC='"+ac_nonac+"',WARD_ROOM_NO="+ward_no+",BED_CHARGES="+price+" where PATIENT_ID="+Integer.parseInt(txtBedWardBookingPatientID.getText())+"and DISCHARGE_DATE is null");
            PreparedStatement pstmt2 =con.prepareStatement("Update WARD set STATUS='Reserved' where BED_NO="+bed_no+" and WARD_NO="+ward_no);
            pstmt.executeUpdate();
            pstmt2.executeUpdate();
            JOptionPane.showMessageDialog(null,"Bed Succesfully booked");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnBedWardBookingBookActionPerformed

    private void btnBedRoomBookingCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBedRoomBookingCancelActionPerformed
        // TODO add your handling code here:
        pnlBedRoomBooking.setVisible(false);
    }//GEN-LAST:event_btnBedRoomBookingCancelActionPerformed

    private void btnBedRoomBookingBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBedRoomBookingBookActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            
            if(txtBedRoomBookingPatientID.getText().trim().isEmpty())
            {
            lblBedRoomBookingWarning.setVisible(true);
            }
            else
            {
            
            String ac_nonac=tblBedRoom.getModel().getValueAt(tblBedRoom.getSelectedRow(),3).toString();
            double price=Double.parseDouble(tblBedRoom.getModel().getValueAt(tblBedRoom.getSelectedRow(),5).toString());
            String room_type=lblBedRoomBookingRoomType.getText();
            int bed_no=Integer.parseInt(lblBedRoomBookingBedN.getText());
            int room_no=(Integer.parseInt(lblBedRoomBookingRoomN.getText()));    
            pstmt=con.prepareStatement("Update INDOOR set WARD_ROOM_TYPE='"+room_type+"',BED_NO="+bed_no+",AC_NON_AC='"+ac_nonac+"',WARD_ROOM_NO="+room_no+",BED_CHARGES="+price+" where PATIENT_ID="+Integer.parseInt(txtBedRoomBookingPatientID.getText())+"and DISCHARGE_DATE is null");
            PreparedStatement pstmt2 =con.prepareStatement("Update ROOM set STATUS='Reserved' where BED_NO="+bed_no+" and ROOM_NO="+room_no);
            pstmt.executeUpdate();
            pstmt2.executeUpdate();
            JOptionPane.showMessageDialog(null,"Bed Succesfully booked");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnBedRoomBookingBookActionPerformed

    private void rbtnBedRoomNACActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnBedRoomNACActionPerformed
        // TODO add your handling code here:
        try {
            ResultSet rs=stmt.executeQuery("select distinct ROOM_TYPE from ROOM where AC_NONAC='Non A.C.'");
            cbBedRoom.removeAllItems();
            cbBedRoom.addItem("Select Room Type");
            while(rs.next())
            {
                cbBedRoom.addItem(rs.getString("ROOM_TYPE"));
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnBedRoomNACActionPerformed

    private void rbtnBedRoomACActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnBedRoomACActionPerformed
        // TODO add your handling code here:
        try {
            ResultSet rs=stmt.executeQuery("select distinct ROOM_TYPE,ROOM_CHARGES from ROOM where AC_NONAC='A.C.'");
            cbBedRoom.removeAllItems();
            cbBedRoom.addItem("Select Room Type");
            while(rs.next())
            {
                cbBedRoom.addItem(rs.getString("ROOM_TYPE"));
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnBedRoomACActionPerformed

    private void btnBedRoomCheckAvailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBedRoomCheckAvailActionPerformed
        // TODO add your handling code here:
         try {
            // TODO add your handling code here:
            if (rbtnBedRoomAC.isSelected())
            {spBedRoom.setVisible(true);
            tblBedRoom.setVisible(true);
            ResultSet rs=stmt.executeQuery("select * from ROOM where ROOM_TYPE='"+String.valueOf(cbBedRoom.getSelectedItem())+"' and AC_NONAC='A.C.'");
            tblBedRoom.setModel(DbUtils.resultSetToTableModel(rs));
            btnBedRoomProceed2Book.setVisible(true);}
            else
            {
            spBedRoom.setVisible(true);
            tblBedRoom.setVisible(true);
            ResultSet rs=stmt.executeQuery("select * from ROOM where ROOM_TYPE='"+String.valueOf(cbBedRoom.getSelectedItem())+"' and AC_NONAC='Non A.C.'");
            tblBedRoom.setModel(DbUtils.resultSetToTableModel(rs));
            btnBedRoomProceed2Book.setVisible(true);
            
            }
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnBedRoomCheckAvailActionPerformed

    private void btnNTestGenerateRecieptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNTestGenerateRecieptActionPerformed
        try {
            // TODO add your handling code here:
            
            pstmt=con.prepareStatement("insert into LAB_BILL (PATIENT_ID,NAME,TEST_NAME,TEST_CHARGES,DATE) values (?,?,?,?,?)");

            
            ResultSet rs=stmt.executeQuery("select * from PATIENT_INFO where PATIENT_ID="+Integer.parseInt(txtNTestPatientID.getText())+"");

            if(txtNTestPatientID.getText().trim().isEmpty())
            {
                String test_n=tblLabNewTest.getModel().getValueAt(tblLabNewTest.getSelectedRow(),0).toString();
                txtLabNewTest.setText(test_n);
                lblLabNewTestWarning.setVisible(true);
            }
            else
            {
                SimpleDateFormat sdf= new SimpleDateFormat("dd-MM-yyyy");
                String date_today= LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
                rs.next();
                pstmt.setInt(1,Integer.parseInt(txtNTestPatientID.getText()));
                pstmt.setString(5, String.valueOf(date_today));
                pstmt.setString(2,rs.getString("NAME"));
                String test_n=tblLabNewTest.getModel().getValueAt(tblLabNewTest.getSelectedRow(),0).toString();
                Double test_c=Double.parseDouble(tblLabNewTest.getModel().getValueAt(tblLabNewTest.getSelectedRow(),1).toString());
                pstmt.setString(3, test_n);
                pstmt.setDouble(4,test_c);
                pstmt.executeUpdate();

                 
                 Statement stat=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                ResultSet rst=stat.executeQuery("select * from LAB_BILL ");
                rst.last();
                
                lblLabRecieptBillNo.setText(String.valueOf(rst.getInt(1)));
                lblLabRecieptAge.setText(String.valueOf(Age_calc(rs.getString("DOB"),date_today)));
                lblLabRecieptDate.setText(String.valueOf(date_today));
                lblLabRecieptName.setText(rs.getString("NAME"));
                lblLabRecieptKin.setText(rs.getString("KIN"));
                lblLabRecieptSex.setText(rs.getString("GENDER"));
                double s_gst=0.09*test_c;
                double c_gst=0.09*test_c;
                double total=Math.round(test_c+s_gst+c_gst);
                lblLabRecieptCTax.setText(String.valueOf(c_gst));
                lblLabRecieptSTax.setText(String.valueOf(s_gst));
                lblLabRecieptAmountPaid.setText(String.valueOf(total));
                lblLabRecieptTestName.setText(test_n);
                lblLabRecieptTestRate.setText(String.valueOf(test_c));
                labcardlayout.show(pnlLabContainer,"LabRecieptCard");
                        
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btnNTestGenerateRecieptActionPerformed

    private void cbPDAddStateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPDAddStateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbPDAddStateActionPerformed

    private void btnPDSearchDb1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDSearchDb1ActionPerformed
        // TODO add your handling code here:
        markAddPatient.setVisible(false);
        markPDConfirm.setVisible(false);
        markPdSearch.setVisible(true);
        PDcardlayout.show(pnlPDContainer,"PDSearchCard");
    }//GEN-LAST:event_btnPDSearchDb1ActionPerformed

    private void tblPDConfirmMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPDConfirmMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)tblPDConfirm.getModel();
        int selectedRowIndex = tblPDConfirm.getSelectedRow();
        
        try{
            int P = JOptionPane.showConfirmDialog(null," Are you sure want to confirm this User information ?","Confirmation",JOptionPane.YES_NO_OPTION);
            if (P==0)
            {
            PreparedStatement pstmt=con.prepareStatement("insert into PATIENT_INFO (NAME,KIN,GENDER,DOB,CONTACT,BG,ADDRESS,USERNAME) values(?,?,?,?,?,?,?,?)");
            pstmt.setString(1, model.getValueAt(selectedRowIndex, 0).toString());
            pstmt.setString(2, model.getValueAt(selectedRowIndex, 1).toString());
            pstmt.setString(3, model.getValueAt(selectedRowIndex, 2).toString());
            pstmt.setString(4, model.getValueAt(selectedRowIndex, 3).toString());
            pstmt.setString(5, model.getValueAt(selectedRowIndex, 5).toString());
            pstmt.setString(6, model.getValueAt(selectedRowIndex, 6).toString());
            pstmt.setString(7, model.getValueAt(selectedRowIndex, 7).toString());
            pstmt.setString(8, model.getValueAt(selectedRowIndex, 8).toString());
            
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data Successfully Added to database");
        }
        }
        catch(SQLException e)
        {
            e.getMessage();
        }
       
    }//GEN-LAST:event_tblPDConfirmMouseClicked

    private void lblViewBedBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblViewBedBackMouseClicked
        // TODO add your handling code here:
        cardlayout.show(pnlRecepContentContainer,"DashMainCard");
    }//GEN-LAST:event_lblViewBedBackMouseClicked

    private void btnViewBedWardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewBedWardActionPerformed
        // TODO add your handling code here:
        markBedListWard.setVisible(true);
        markBedListRoom.setVisible(false);
        txtViewBedWardSearch.setText("Ward Type or Ward No");
        viewbedcardlayout.show(pnlViewBedContainer,"ViewWardCard");
    }//GEN-LAST:event_btnViewBedWardActionPerformed

    private void btnViewBedRoomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewBedRoomActionPerformed
        // TODO add your handling code here:
        markBedListWard.setVisible(false);
        markBedListRoom.setVisible(true);
        txtViewBedRoomSearch.setText("Room Type or Room No");
        viewbedcardlayout.show(pnlViewBedContainer,"ViewRoomCard");
    }//GEN-LAST:event_btnViewBedRoomActionPerformed

    private void txtViewBedRoomSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtViewBedRoomSearchMouseClicked
        // TODO add your handling code here:
        txtViewBedRoomSearch.setText("");
        txtViewBedRoomSearch.grabFocus();
    }//GEN-LAST:event_txtViewBedRoomSearchMouseClicked

    private void txtViewBedRoomSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtViewBedRoomSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtViewBedRoomSearchActionPerformed

    private void txtViewBedWardSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtViewBedWardSearchMouseClicked
        // TODO add your handling code here:
        txtViewBedWardSearch.setText("");
        txtViewBedWardSearch.grabFocus();
    }//GEN-LAST:event_txtViewBedWardSearchMouseClicked

    private void rbtnViewBedWardRevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnViewBedWardRevActionPerformed
        try {
            // TODO add your handling code here:
            ResultSet view_ward_rev=stmt.executeQuery("select WARD_NO,WARD_TYPE,BED_NO,AC_NONAC,WARD_CHARGES from WARD where STATUS='Reserved'");
            tblViewBedWard.setModel(DbUtils.resultSetToTableModel(view_ward_rev));
            customtable(tblViewBedWard);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnViewBedWardRevActionPerformed

    private void rbtnViewBedWardAvblActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnViewBedWardAvblActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            ResultSet view_ward_avbl=stmt.executeQuery("select WARD_NO,WARD_TYPE,BED_NO,AC_NONAC,WARD_CHARGES from WARD where STATUS='Not Reserved'");
            tblViewBedWard.setModel(DbUtils.resultSetToTableModel(view_ward_avbl));
            customtable(tblViewBedWard);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnViewBedWardAvblActionPerformed

    private void rbtnViewBedWardAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnViewBedWardAllActionPerformed
        try {
            // TODO add your handling code here:
            ResultSet view_ward=stmt.executeQuery("select * from WARD");
            tblViewBedWard.setModel(DbUtils.resultSetToTableModel(view_ward));
            customtable(tblViewBedWard);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnViewBedWardAllActionPerformed

    private void txtViewBedWardSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtViewBedWardSearchKeyReleased
        // TODO add your handling code here:
        try {
        String search=txtViewBedWardSearch.getText();
        
        if (rbtnViewBedWardAll.isSelected())
        {
        if(search.matches("^[0-9]+$"))
        {
           
                ResultSet ward_search= stmt.executeQuery("select * from WARD where WARD_NO ="+Integer.parseInt(search));
                tblViewBedWard.setModel(DbUtils.resultSetToTableModel(ward_search));
                customtable(tblViewBedWard);
        }
        else
        {
        ResultSet ward_search= stmt.executeQuery("select * from WARD where WARD_TYPE like '%"+search+"%'");
                tblViewBedWard.setModel(DbUtils.resultSetToTableModel(ward_search));
                customtable(tblViewBedWard);
        }
        }
        
        else if (rbtnViewBedWardAvbl.isSelected())
        {
        if(search.matches("^[0-9]+$"))
        {
           
                ResultSet ward_search= stmt.executeQuery("select  WARD_NO,WARD_TYPE,BED_NO,AC_NONAC,WARD_CHARGES  from WARD where STATUS='Not Reserved' and WARD_NO ="+Integer.parseInt(search));
                tblViewBedWard.setModel(DbUtils.resultSetToTableModel(ward_search));
                customtable(tblViewBedWard);
        }
        else
        {
        ResultSet ward_search= stmt.executeQuery("select WARD_NO,WARD_TYPE,BED_NO,AC_NONAC,WARD_CHARGES  from WARD where STATUS='Not Reserved' and WARD_TYPE like '%"+search+"%'");
                tblViewBedWard.setModel(DbUtils.resultSetToTableModel(ward_search));
                customtable(tblViewBedWard);
        }
        
        }
        
        else{
         if(search.matches("^[0-9]+$"))
        {
           
                ResultSet ward_search= stmt.executeQuery("select  WARD_NO,WARD_TYPE,BED_NO,AC_NONAC,WARD_CHARGES  from WARD where STATUS='Reserved' and WARD_NO ="+Integer.parseInt(search));
                tblViewBedWard.setModel(DbUtils.resultSetToTableModel(ward_search));
                customtable(tblViewBedWard);
        }
        else
        {
        ResultSet ward_search= stmt.executeQuery("select WARD_NO,WARD_TYPE,BED_NO,AC_NONAC,WARD_CHARGES  from WARD where STATUS='Reserved' and WARD_TYPE like '%"+search+"%'");
                tblViewBedWard.setModel(DbUtils.resultSetToTableModel(ward_search));
                customtable(tblViewBedWard);
        }
        
        }
        
        
         } catch (SQLException ex) {
                Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_txtViewBedWardSearchKeyReleased

    private void rbtnViewBedRoomAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnViewBedRoomAllActionPerformed
        // TODO add your handling code here:
         try {
            // TODO add your handling code here:
            ResultSet view_room=stmt.executeQuery("select * from ROOM");
            tblViewBedRoom.setModel(DbUtils.resultSetToTableModel(view_room));
             System.out.println(tblViewBedRoom.getRowCount());
             customtable(tblViewBedRoom);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnViewBedRoomAllActionPerformed

    private void rbtnViewBedRoomRevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnViewBedRoomRevActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            ResultSet view_room_rev=stmt.executeQuery("select ROOM_NO,ROOM_TYPE,BED_NO,AC_NONAC,ROOM_CHARGES from ROOM where STATUS='Reserved'");
            tblViewBedRoom.setModel(DbUtils.resultSetToTableModel(view_room_rev));
             customtable(tblViewBedRoom);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnViewBedRoomRevActionPerformed

    private void rbtnViewBedRoomAvblActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnViewBedRoomAvblActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            ResultSet view_room_avbl=stmt.executeQuery("select ROOM_NO,ROOM_TYPE,BED_NO,AC_NONAC,ROOM_CHARGES from ROOM where STATUS='Not Reserved'");
            tblViewBedRoom.setModel(DbUtils.resultSetToTableModel(view_room_avbl));
             customtable(tblViewBedRoom);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnViewBedRoomAvblActionPerformed

    private void txtViewBedRoomSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtViewBedRoomSearchKeyReleased
        // TODO add your handling code here:
         try {
        String search=txtViewBedRoomSearch.getText();
        
        if (rbtnViewBedRoomAll.isSelected())
        {
        if(search.matches("^[0-9]+$"))
        {
           
                ResultSet room_search= stmt.executeQuery("select * from ROOM where ROOM_NO ="+Integer.parseInt(search));
                tblViewBedRoom.setModel(DbUtils.resultSetToTableModel(room_search));
                customtable(tblViewBedRoom);
                
        }
        else
        {
        ResultSet room_search= stmt.executeQuery("select * from ROOM where ROOM_TYPE like '%"+search+"%'");
                tblViewBedRoom.setModel(DbUtils.resultSetToTableModel(room_search));
                customtable(tblViewBedRoom);
        }
        }
        
        else if (rbtnViewBedRoomAvbl.isSelected())
        {
        if(search.matches("^[0-9]+$"))
        {
           
                ResultSet room_search= stmt.executeQuery("select  ROOM_NO,ROOM_TYPE,BED_NO,AC_NONAC,ROOM_CHARGES  from ROOM where STATUS='Not Reserved' and ROOM_NO ="+Integer.parseInt(search));
                tblViewBedRoom.setModel(DbUtils.resultSetToTableModel(room_search));
                customtable(tblViewBedRoom);
        }
        else
        {
        ResultSet room_search= stmt.executeQuery("select ROOM_NO,ROOM_TYPE,BED_NO,AC_NONAC,ROOM_CHARGES  from ROOM where STATUS='Not Reserved' and ROOM_TYPE like '%"+search+"%'");
                tblViewBedRoom.setModel(DbUtils.resultSetToTableModel(room_search));
                customtable(tblViewBedRoom);
        }
        
        }
        
        else{
         if(search.matches("^[0-9]+$"))
        {
           
                ResultSet room_search= stmt.executeQuery("select  ROOM_NO,ROOM_TYPE,BED_NO,AC_NONAC,ROOM_CHARGES  from ROOM where STATUS='Reserved' and ROOM_NO ="+Integer.parseInt(search));
                tblViewBedRoom.setModel(DbUtils.resultSetToTableModel(room_search));
                customtable(tblViewBedRoom);
        }
        else
        {
        ResultSet room_search= stmt.executeQuery("select ROOM_NO,ROOM_TYPE,BED_NO,AC_NONAC,ROOM_CHARGES  from ROOM where STATUS='Reserved' and ROOM_TYPE like '%"+search+"%'");
                tblViewBedRoom.setModel(DbUtils.resultSetToTableModel(room_search));
                customtable(tblViewBedRoom);
        }
        
        }
        
        
         } catch (SQLException ex) {
                Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_txtViewBedRoomSearchKeyReleased

    private void txtViewBedWardSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtViewBedWardSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtViewBedWardSearchActionPerformed

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
        cardlayout.show(pnlRecepContentContainer,"BedCard");
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void lblIndoorBilPrintIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblIndoorBilPrintIconMouseClicked
        // TODO add your handling code here:
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName("Print Data");
        job.setPrintable(new Printable(){
        public int print(Graphics pg,PageFormat pf,int pageNum){
            if(pageNum>0)
              {return Printable.NO_SUCH_PAGE;}
            Graphics2D g2 = (Graphics2D)pg;
            g2.translate(pf.getImageableX(), pf.getImageableY());
            g2.scale(0.75,0.75);
            pnlIndoorBill.paint(g2);// panel which you want to print
            return Printable.PAGE_EXISTS;
        }
        });
        boolean ok = job.printDialog();
        if(ok){
            try{
                job.print();
            }
            catch(PrinterException ex){
                
                
            }}
    }//GEN-LAST:event_lblIndoorBilPrintIconMouseClicked

    private void lblLabRecieptPrintIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLabRecieptPrintIconMouseClicked
        // TODO add your handling code here:
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName("Print Data");
        job.setPrintable(new Printable(){
        public int print(Graphics pg,PageFormat pf,int pageNum){
            if(pageNum>0)
              {return Printable.NO_SUCH_PAGE;}
            Graphics2D g2 = (Graphics2D)pg;
            g2.translate(pf.getImageableX(), pf.getImageableY());
            g2.scale(0.75,0.75);
            pnlLabReciept.paint(g2);// panel which you want to print
            return Printable.PAGE_EXISTS;
        }
        });
        boolean ok = job.printDialog();
        if(ok){
            try{
                job.print();
            }
            catch(PrinterException ex){
                
                
            }}
    }//GEN-LAST:event_lblLabRecieptPrintIconMouseClicked

    private void lblAppointmentRecieptPrintIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAppointmentRecieptPrintIconMouseClicked
        // TODO add your handling code here:
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName("Print Data");
        job.setPrintable(new Printable(){
        public int print(Graphics pg,PageFormat pf,int pageNum){
            if(pageNum>0)
              {return Printable.NO_SUCH_PAGE;}
            Graphics2D g2 = (Graphics2D)pg;
            g2.translate(pf.getImageableX(), pf.getImageableY());
            g2.scale(0.75,0.75);
            pnlApointmentReciept.paint(g2);// panel which you want to print
            return Printable.PAGE_EXISTS;
        }
        });
        boolean ok = job.printDialog();
        if(ok){
            try{
                job.print();
            }
            catch(PrinterException ex){
                
                
            }}
    }//GEN-LAST:event_lblAppointmentRecieptPrintIconMouseClicked

    private void btnPDConfirmPatientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDConfirmPatientActionPerformed
        // TODO add your handling code here:
        
        DefaultTableModel model = (DefaultTableModel)tblPDConfirm.getModel();
        int selectedRowIndex = tblPDConfirm.getSelectedRow();
        try{
            Email email = new Email("somu178p@gmail.com","somuupsn178"); // sender email address and password
            email.setFrom   ("somu178p@gmail.com", "Saumya Patel"); // sender email address and name
            email.setSubject("Registration Validation Confirm"); // subject of your email
            email.setText("Welcome to UPSN Hospitals,\n" +
"Thank You for validation of your information provided earlier for registration with us\n" +
"You have been registered and will be a member of UPNS Hospital family forever.\n" +
"Thank you ! We wish youu will be happy with our service!"); // any text you want to send in email
            
            email.addRecipient(model.getValueAt(selectedRowIndex, 4).toString()); // recipient email address
            email.send(); // send email
             
        }catch(UnsupportedEncodingException | MessagingException err){
            System.out.println(err);
        }
         try{
            int P = JOptionPane.showConfirmDialog(null," Are you sure want to confirm ?","Confirmation",JOptionPane.YES_NO_OPTION);
            if (P==0)
            {

                String sql= "delete from PATIENT_INFO_TEMPORARY where NAME = " + model.getValueAt(selectedRowIndex, 0).toString() + "";
                PreparedStatement pst11=con.prepareStatement(sql);
                pst11.execute();
                
                JOptionPane.showMessageDialog(this,"Confirmation successful","Record",JOptionPane.INFORMATION_MESSAGE);

            }
           
        }catch(HeadlessException | SQLException ex){
            JOptionPane.showMessageDialog(this,ex);
        }
    }//GEN-LAST:event_btnPDConfirmPatientActionPerformed

    private void btnBAppointmentResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBAppointmentResetActionPerformed
        // TODO add your handling code here:
        Reset();
    }//GEN-LAST:event_btnBAppointmentResetActionPerformed

    private void txtLabNewTestKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtLabNewTestKeyReleased
        try {
            // TODO add your handling code here:
            String test=txtLabNewTest.getText();
            ResultSet test_search=stmt.executeQuery("select * from LAB where LAB_TEST like '%"+test+"%'");
            tblLabNewTest.setModel(DbUtils.resultSetToTableModel(test_search));
            customtable(tblLabNewTest);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_txtLabNewTestKeyReleased

    private void txtViewAppointmentSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtViewAppointmentSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtViewAppointmentSearchActionPerformed

    private void txtViewAppointmentSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtViewAppointmentSearchKeyReleased
        // TODO add your handling code here:
        try{
        String search=txtViewAppointmentSearch.getText();
        if(search.matches("^[0-9]+$"))
        {
           
            
                ResultSet pat_search=stmt.executeQuery("select PATIENT_ID,NAME,CONTACT,SPECIALISATION,DOC_NAME,DATE,TIME from APPOINTMENTS_RECORD_TEMPORARY where PATIENT_ID ="+Integer.parseInt(search));
                tblAppointmentSearch.setModel(DbUtils.resultSetToTableModel(pat_search));
                tblAppointmentSearch.setEnabled(false);
                customtable(tblAppointmentSearch);
            } 
            
                
        
        else
        { System.out.println("else");
         ResultSet pat_search=stmt.executeQuery("select PATIENT_ID,NAME,CONTACT,SPECIALISATION,DOC_NAME,DATE,TIME from APPOINTMENTS_RECORD_TEMPORARY where DOC_NAME like '%"+search+"%'");       
        tblAppointmentSearch.setModel(DbUtils.resultSetToTableModel(pat_search));
        tblAppointmentSearch.setEnabled(false);
        customtable(tblAppointmentSearch);
        }
    }
        catch (SQLException ex) {
                Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);}
    }//GEN-LAST:event_txtViewAppointmentSearchKeyReleased

    private void txtIndoorViewListSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIndoorViewListSearchKeyReleased
        // TODO add your handling code here:
         try{
            String search=txtIndoorViewListSearch.getText();
             if(rbtnIndoorViewListName.isSelected())
            {
                if(search.matches("[0-9]+$"))
                {
                JOptionPane.showMessageDialog(null,"Enter name. Numerical value not accepted");
                }
                else
                {
                ResultSet rs=stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR where NAME like'%"+txtIndoorViewListSearch.getText()+"%' and DISCHARGE_DATE is null");
                jTable1.setModel(DbUtils.resultSetToTableModel(rs));
                customtable(jTable1);
                }
            }
            if(rbtnIndoorViewListID.isSelected())
            {
                
                if (search.matches("[0-9]+$"))
                {
            ResultSet rs=stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR where PATIENT_ID ="+Integer.parseInt(txtIndoorViewListSearch.getText())+" and DISCHARGE_DATE is null");
                jTable1.setModel(DbUtils.resultSetToTableModel(rs));
                customtable(jTable1);
                }
            }
            if(rbtnIndoorViewListDocRef.isSelected())
            {
                if(search.matches("[0-9]+$"))
                {
                JOptionPane.showMessageDialog(null,"Enter name. Numerical value not accepted");
                }
                else
                {
            ResultSet rs=stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR where DOC_NAME like '%"+"Dr."+txtIndoorViewListSearch.getText()+"%' and DISCHARGE_DATE is null");
                jTable1.setModel(DbUtils.resultSetToTableModel(rs));
                customtable(jTable1);
            }}
            if(rbtnIndoorViewListR_W.isSelected())
            {
                if (search.matches("[0-9]+$"))
                {
            ResultSet rs=stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR where WARD_ROOM_NO="+Integer.parseInt(txtIndoorViewListSearch.getText())+" and DISCHARGE_DATE is null");
                jTable1.setModel(DbUtils.resultSetToTableModel(rs));
                customtable(jTable1);
            }}
        }
        catch (SQLException ex) {
                Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_txtIndoorViewListSearchKeyReleased

    private void txtPDSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPDSearchKeyReleased
        // TODO add your handling code here:
        try{
        String search=txtPDSearch.getText();
	if (search.matches("^[0-9]+$"))
	{
	ResultSet rs=stmt.executeQuery("select PATIENT_ID,NAME,KIN,ADDRESS from PATIENT_INFO where PATIENT_ID ="+Integer.parseInt(search)+"");
        tblPDSearch.setModel(DbUtils.resultSetToTableModel(rs));
            customtable(tblPDSearch);
        
	}
        
	else
	{ResultSet rs=stmt.executeQuery("select PATIENT_ID,NAME,KIN,ADDRESS from PATIENT_INFO where NAME like'%"+search+"%'");
        tblPDSearch.setModel(DbUtils.resultSetToTableModel(rs));
        customtable(tblPDSearch);
        }}
        catch(SQLException e){
                e.getMessage();
                
                        }
    }//GEN-LAST:event_txtPDSearchKeyReleased

    private void txtDDSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDDSearchKeyReleased
        // TODO add your handling code here:
        try{
            String search=txtDDSearch.getText();
            if(rbtnDDSearchName.isSelected())
        {
            
                ResultSet rs=stmt.executeQuery("select NAME,SPECIALISATION,CONTACT,DOC_CHARGES from DOCTOR_INFO where NAME like '%"+search+"%'");
                tblDDSearch.setModel(DbUtils.resultSetToTableModel(rs));
                customtable(tblDDSearch);
            
        }
        else
        {
        ResultSet rs=stmt.executeQuery("select NAME,SPECIALISATION,CONTACT,DOC_CHARGES from DOCTOR_INFO where SPECIALISATION like '%"+search+"%'");
        tblDDSearch.setModel(DbUtils.resultSetToTableModel(rs));
            customtable(tblDDSearch);
        }
        }
        catch (SQLException ex) {
                Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_txtDDSearchKeyReleased

    private void txtViewAppointmentSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtViewAppointmentSearchMouseClicked
        // TODO add your handling code here:
        txtViewAppointmentSearch.setText("");
        txtViewAppointmentSearch.grabFocus();
    }//GEN-LAST:event_txtViewAppointmentSearchMouseClicked

    private void rbtnDDSearchNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnDDSearchNameActionPerformed
        // TODO add your handling code here:
        txtDDSearch.setText("Doctor Name");
    }//GEN-LAST:event_rbtnDDSearchNameActionPerformed

    private void rbtnDDSearchSpecialisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnDDSearchSpecialisationActionPerformed
        // TODO add your handling code here:
        txtDDSearch.setText("Specialisation");
    }//GEN-LAST:event_rbtnDDSearchSpecialisationActionPerformed

    private void btnBookAppointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBookAppointmentActionPerformed
        // TODO add your handling code here:
        markAppointmentBook.setVisible(true);
        markAppointmentView.setVisible(false);
        appointmentcardlayout.show(pnlAppointmentContainer,"AppointmentBookingCard");
    }//GEN-LAST:event_btnBookAppointmentActionPerformed

    private void lblRecepFrontDDBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecepFrontDDBMouseClicked
        // TODO add your handling code here:
        markRecords.setVisible(false);
        markPD.setVisible(false);
        markSettings.setVisible(false);
        markHelp.setVisible(false);
        markDash.setVisible(false);
        markDD.setVisible(true);
        cardlayout.show(pnlRecepContentContainer,"DDCard");
    }//GEN-LAST:event_lblRecepFrontDDBMouseClicked

    private void lblRecordsBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecordsBackMouseClicked
        // TODO add your handling code here:
        cardlayout.show(pnlRecepContentContainer,"DashMainCard");
    }//GEN-LAST:event_lblRecordsBackMouseClicked

    private void btnRecordsConsultancyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecordsConsultancyActionPerformed
        // TODO add your handling code here:
        markRecordsConsultancy.setVisible(true);
        markRecordsIndoor.setVisible(false);
        markRecordsLab.setVisible(false);
        recordscardlayout.show(pnlRecordsContainer,"RecordsConcCard");
    }//GEN-LAST:event_btnRecordsConsultancyActionPerformed

    private void btnRecordsIndoorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecordsIndoorActionPerformed
        // TODO add your handling code here:
       markRecordsConsultancy.setVisible(false);
        markRecordsIndoor.setVisible(true);
        markRecordsLab.setVisible(false);
        recordscardlayout.show(pnlRecordsContainer,"RecordIndoorCard");
    }//GEN-LAST:event_btnRecordsIndoorActionPerformed

    private void btnRecordsLabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecordsLabActionPerformed
        // TODO add your handling code here:
        markRecordsConsultancy.setVisible(false);
        markRecordsIndoor.setVisible(false);
        markRecordsLab.setVisible(true);
        recordscardlayout.show(pnlRecordsContainer,"RecordsLabCard");
    }//GEN-LAST:event_btnRecordsLabActionPerformed

    private void lblRecordsIndoorExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecordsIndoorExpandMouseClicked
        // TODO add your handling code here:
        
        maincardlayout.show(pnlMainContainer,"RecIndoorCard");
    }//GEN-LAST:event_lblRecordsIndoorExpandMouseClicked

    private void lblRecordsConsultancyExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecordsConsultancyExpandMouseClicked
        // TODO add your handling code here:
       
        maincardlayout.show(pnlMainContainer,"RecConcCard");
    }//GEN-LAST:event_lblRecordsConsultancyExpandMouseClicked

    private void lblRecordsLabExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecordsLabExpandMouseClicked
        // TODO add your handling code here:
       
        maincardlayout.show(pnlMainContainer,"RecLabCard");
    }//GEN-LAST:event_lblRecordsLabExpandMouseClicked

    private void txtRecordsLabExpandSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtRecordsLabExpandSearchMouseClicked
        // TODO add your handling code here:
        txtRecordsLabExpandSearch.setText("");
        txtRecordsLabExpandSearch.grabFocus();
        
    }//GEN-LAST:event_txtRecordsLabExpandSearchMouseClicked

    private void lblRecordsLabCollaspMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecordsLabCollaspMouseClicked
        // TODO add your handling code here:
        txtRecordsLabExpandSearch.setText("Bill No or Name");
        maincardlayout.show(pnlMainContainer,"MainDashCard");
        cardlayout.show(pnlRecepContentContainer,"RecordsCard");
        recordscardlayout.show(pnlRecordsContainer,"RecordLabCard");
    }//GEN-LAST:event_lblRecordsLabCollaspMouseClicked

    private void lblRecordsConsultancyCollaspMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecordsConsultancyCollaspMouseClicked
        // TODO add your handling code here:
        txtRecordsConsultancyExpandSearch.setText("Bill No or Name");
        maincardlayout.show(pnlMainContainer,"MainDashCard");
        cardlayout.show(pnlRecepContentContainer,"RecordsCard");
        recordscardlayout.show(pnlRecordsContainer,"RecordConccard");
    }//GEN-LAST:event_lblRecordsConsultancyCollaspMouseClicked

    private void lblRecordsIndoorCollaspMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRecordsIndoorCollaspMouseClicked
        // TODO add your handling code here:
        txtRecordsIndoorExpandSearch.setText("");
        maincardlayout.show(pnlMainContainer,"MainDashCard");
        cardlayout.show(pnlRecepContentContainer,"RecordsCard");
        recordscardlayout.show(pnlRecordsContainer,"RecordIndoorCard");
    }//GEN-LAST:event_lblRecordsIndoorCollaspMouseClicked

    private void txtRecordsIndoorExpandSearchKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtRecordsIndoorExpandSearchKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRecordsIndoorExpandSearchKeyPressed

    private void txtRecordsIndoorExpandSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtRecordsIndoorExpandSearchKeyReleased
        // TODO add your handling code here:
       try {
        String search=txtRecordsIndoorExpandSearch.getText();
        if(search.matches("^[0-9]+$"))
        {
           
            
                ResultSet indoor_search= stmt.executeQuery("select * from INDOOR where BILL_NO ="+Integer.parseInt(search));
                tblRecordsIndoorExpand.setModel(DbUtils.resultSetToTableModel(indoor_search));
                customtable(tblRecordsIndoorExpand);
            
        }
        else
        {
        ResultSet indoor_search= stmt.executeQuery("select * from INDOOR where NAME like '%"+search+"%'");
                tblRecordsIndoorExpand.setModel(DbUtils.resultSetToTableModel(indoor_search));
                customtable(tblRecordsIndoorExpand);
                }
        } catch (SQLException ex) {
                Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_txtRecordsIndoorExpandSearchKeyReleased

    private void txtRecordsConsultancyExpandSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtRecordsConsultancyExpandSearchKeyReleased
        // TODO add your handling code here:
        try {
        String search=txtRecordsConsultancyExpandSearch.getText();
        if(search.matches("^[0-9]+$"))
        {
           
            
                ResultSet conc_search= stmt.executeQuery("select * from APPOINTMENTS_RECORD where BILL_NO ="+Integer.parseInt(search));
                tblRecordsConsultancyExpand.setModel(DbUtils.resultSetToTableModel(conc_search));
                customtable(tblRecordsConsultancyExpand);
            
        }
        else
        {
        ResultSet conc_search= stmt.executeQuery("select * from APPOINTMENTS_RECORD where NAME like '%"+search+"%'");
                tblRecordsConsultancyExpand.setModel(DbUtils.resultSetToTableModel(conc_search));
                customtable(tblRecordsConsultancyExpand);
                }
        } catch (SQLException ex) {
                Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_txtRecordsConsultancyExpandSearchKeyReleased

    private void txtRecordsLabExpandSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtRecordsLabExpandSearchKeyReleased
        // TODO add your handling code here:
        try {
        String search=txtRecordsLabExpandSearch.getText();
        if(search.matches("^[0-9]+$"))
        {
           
            
                ResultSet lab_search= stmt.executeQuery("select * from LAB_BILL where BILL_NO ="+Integer.parseInt(search));
                tblRecordsLabExpand.setModel(DbUtils.resultSetToTableModel(lab_search));
                customtable(tblRecordsLabExpand);
            
        }
        else
        {
        ResultSet lab_search= stmt.executeQuery("select * from LAB_BILL where NAME like '%"+search+"%'");
                tblRecordsLabExpand.setModel(DbUtils.resultSetToTableModel(lab_search));
                customtable(tblRecordsLabExpand);
                }
        } catch (SQLException ex) {
                Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_txtRecordsLabExpandSearchKeyReleased

    private void txtRecordsConsultancyExpandSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtRecordsConsultancyExpandSearchMouseClicked
        // TODO add your handling code here:
        txtRecordsConsultancyExpandSearch.setText("");
        txtRecordsConsultancyExpandSearch.grabFocus();
    }//GEN-LAST:event_txtRecordsConsultancyExpandSearchMouseClicked

    private void txtRecordsIndoorExpandSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtRecordsIndoorExpandSearchMouseClicked
        // TODO add your handling code here:
        txtRecordsIndoorExpandSearch.setText("");
        txtRecordsIndoorExpandSearch.grabFocus();
    }//GEN-LAST:event_txtRecordsIndoorExpandSearchMouseClicked

    private void lblAppointmentViewExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAppointmentViewExpandMouseClicked
        // TODO add your handling code here:
        maincardlayout.show(pnlMainContainer,"AppointmentViewCard");
    }//GEN-LAST:event_lblAppointmentViewExpandMouseClicked

    private void txtViewAppointmentExpandSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtViewAppointmentExpandSearchMouseClicked
        // TODO add your handling code here:
        txtViewAppointmentExpandSearch.setText("");
        txtViewAppointmentExpandSearch.grabFocus();
    }//GEN-LAST:event_txtViewAppointmentExpandSearchMouseClicked

    private void txtViewAppointmentExpandSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtViewAppointmentExpandSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtViewAppointmentExpandSearchActionPerformed

    private void txtViewAppointmentExpandSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtViewAppointmentExpandSearchKeyReleased
        // TODO add your handling code here:
         try{
        String search=txtViewAppointmentExpandSearch.getText();
        if(search.matches("^[0-9]+$"))
        {
           
            
                ResultSet pat_search=stmt.executeQuery("select PATIENT_ID,NAME,CONTACT,SPECIALISATION,DOC_NAME,DATE,TIME from APPOINTMENTS_RECORD_TEMPORARY where PATIENT_ID ="+Integer.parseInt(search));
                tblAppointmentSearchExpand.setModel(DbUtils.resultSetToTableModel(pat_search));
                tblAppointmentSearchExpand.setEnabled(false);
                customtable(tblAppointmentSearchExpand);
            } 
            
                
        
        else
        { System.out.println("else");
         ResultSet pat_search=stmt.executeQuery("select PATIENT_ID,NAME,CONTACT,SPECIALISATION,DOC_NAME,DATE,TIME from APPOINTMENTS_RECORD_TEMPORARY where DOC_NAME like '%"+search+"%'");       
        tblAppointmentSearchExpand.setModel(DbUtils.resultSetToTableModel(pat_search));
        tblAppointmentSearchExpand.setEnabled(false);
        customtable(tblAppointmentSearchExpand);
        }
    }
        catch (SQLException ex) {
                Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);}
    }//GEN-LAST:event_txtViewAppointmentExpandSearchKeyReleased

    private void lblViewAppointmentCollaspMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblViewAppointmentCollaspMouseClicked
        // TODO add your handling code here:
        txtRecordsLabExpandSearch.setText("Patient ID or Doctor Name");
        maincardlayout.show(pnlMainContainer,"MainDashCard");
        cardlayout.show(pnlRecepContentContainer,"AppointmentCard");
        appointmentcardlayout.show(pnlAppointmentContainer, "ViewAppointmentCard");
    }//GEN-LAST:event_lblViewAppointmentCollaspMouseClicked

    private void txtPDExpandSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtPDExpandSearchMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPDExpandSearchMouseClicked

    private void txtPDExpandSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPDExpandSearchKeyReleased
        // TODO add your handling code here:
        try{
        String search=txtPDExpandSearch.getText();
	if (search.matches("^[0-9]+$"))
	{
	ResultSet rs=stmt.executeQuery("select PATIENT_ID,NAME,KIN,ADDRESS from PATIENT_INFO where PATIENT_ID ="+Integer.parseInt(search)+"");
        tblPDSearchExpand.setModel(DbUtils.resultSetToTableModel(rs));
            customtable(tblPDSearchExpand);
        
	}
        
	else
	{ResultSet rs=stmt.executeQuery("select PATIENT_ID,NAME,KIN,ADDRESS from PATIENT_INFO where NAME like'%"+search+"%'");
        tblPDSearchExpand.setModel(DbUtils.resultSetToTableModel(rs));
        customtable(tblPDSearchExpand);
        }}
        catch(SQLException e){
                e.getMessage();
                
                        }
    }//GEN-LAST:event_txtPDExpandSearchKeyReleased

    private void txtViewBedWardSearchExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtViewBedWardSearchExpandMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_txtViewBedWardSearchExpandMouseClicked

    private void txtViewBedWardSearchExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtViewBedWardSearchExpandActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtViewBedWardSearchExpandActionPerformed

    private void txtViewBedWardSearchExpandKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtViewBedWardSearchExpandKeyReleased
        // TODO add your handling code here:
        try {
        String search=txtViewBedWardSearchExpand.getText();
        
        if (rbtnViewBedWardAllExpand.isSelected())
        {
        if(search.matches("^[0-9]+$"))
        {
           
                ResultSet ward_search= stmt.executeQuery("select * from WARD where WARD_NO ="+Integer.parseInt(search));
                tblViewBedWardExpand.setModel(DbUtils.resultSetToTableModel(ward_search));
                customtable(tblViewBedWardExpand);
        }
        else
        {
        ResultSet ward_search= stmt.executeQuery("select * from WARD where WARD_TYPE like '%"+search+"%'");
                tblViewBedWardExpand.setModel(DbUtils.resultSetToTableModel(ward_search));
                customtable(tblViewBedWardExpand);
        }
        }
        
        else if (rbtnViewBedWardAvblExpand.isSelected())
        {
        if(search.matches("^[0-9]+$"))
        {
           
                ResultSet ward_search= stmt.executeQuery("select  WARD_NO,WARD_TYPE,BED_NO,AC_NONAC,WARD_CHARGES  from WARD where STATUS='Not Reserved' and WARD_NO ="+Integer.parseInt(search));
                tblViewBedWardExpand.setModel(DbUtils.resultSetToTableModel(ward_search));
                customtable(tblViewBedWardExpand);
        }
        else
        {
        ResultSet ward_search= stmt.executeQuery("select WARD_NO,WARD_TYPE,BED_NO,AC_NONAC,WARD_CHARGES  from WARD where STATUS='Not Reserved' and WARD_TYPE like '%"+search+"%'");
                tblViewBedWardExpand.setModel(DbUtils.resultSetToTableModel(ward_search));
                customtable(tblViewBedWardExpand);
        }
        
        }
        
        else{
         if(search.matches("^[0-9]+$"))
        {
           
                ResultSet ward_search= stmt.executeQuery("select  WARD_NO,WARD_TYPE,BED_NO,AC_NONAC,WARD_CHARGES  from WARD where STATUS='Reserved' and WARD_NO ="+Integer.parseInt(search));
                tblViewBedWardExpand.setModel(DbUtils.resultSetToTableModel(ward_search));
                customtable(tblViewBedWardExpand);
        }
        else
        {
        ResultSet ward_search= stmt.executeQuery("select WARD_NO,WARD_TYPE,BED_NO,AC_NONAC,WARD_CHARGES  from WARD where STATUS='Reserved' and WARD_TYPE like '%"+search+"%'");
                tblViewBedWardExpand.setModel(DbUtils.resultSetToTableModel(ward_search));
                customtable(tblViewBedWardExpand);
        }
        
        }
        
        
         } catch (SQLException ex) {
                Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_txtViewBedWardSearchExpandKeyReleased

    private void rbtnViewBedWardAvblExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnViewBedWardAvblExpandActionPerformed
        // TODO add your handling code here:
         try {
            // TODO add your handling code here:
            ResultSet view_ward_avbl=stmt.executeQuery("select WARD_NO,WARD_TYPE,BED_NO,AC_NONAC,WARD_CHARGES from WARD where STATUS='Not Reserved'");
            tblViewBedWardExpand.setModel(DbUtils.resultSetToTableModel(view_ward_avbl));
            customtable(tblViewBedWardExpand);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnViewBedWardAvblExpandActionPerformed

    private void rbtnViewBedWardRevExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnViewBedWardRevExpandActionPerformed
        // TODO add your handling code here:
         try {
            // TODO add your handling code here:
            ResultSet view_ward_rev=stmt.executeQuery("select WARD_NO,WARD_TYPE,BED_NO,AC_NONAC,WARD_CHARGES from WARD where STATUS='Reserved'");
            tblViewBedWardExpand.setModel(DbUtils.resultSetToTableModel(view_ward_rev));
            customtable(tblViewBedWardExpand);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnViewBedWardRevExpandActionPerformed

    private void rbtnViewBedWardAllExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnViewBedWardAllExpandActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            ResultSet view_ward=stmt.executeQuery("select * from WARD");
            tblViewBedWardExpand.setModel(DbUtils.resultSetToTableModel(view_ward));
            customtable(tblViewBedWardExpand);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnViewBedWardAllExpandActionPerformed

    private void rbtnViewBedRoomAvblExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnViewBedRoomAvblExpandActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            ResultSet view_room_avbl=stmt.executeQuery("select ROOM_NO,ROOM_TYPE,BED_NO,AC_NONAC,ROOM_CHARGES from ROOM where STATUS='Not Reserved'");
            tblViewBedRoomExpand.setModel(DbUtils.resultSetToTableModel(view_room_avbl));
             customtable(tblViewBedRoomExpand);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnViewBedRoomAvblExpandActionPerformed

    private void rbtnViewBedRoomRevExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnViewBedRoomRevExpandActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            ResultSet view_room_rev=stmt.executeQuery("select ROOM_NO,ROOM_TYPE,BED_NO,AC_NONAC,ROOM_CHARGES from ROOM where STATUS='Reserved'");
            tblViewBedRoomExpand.setModel(DbUtils.resultSetToTableModel(view_room_rev));
             customtable(tblViewBedRoomExpand);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnViewBedRoomRevExpandActionPerformed

    private void txtViewBedRoomSearchExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtViewBedRoomSearchExpandMouseClicked
        // TODO add your handling code here:
        txtViewBedRoomSearchExpand.setText("");
        txtViewBedRoomSearchExpand.grabFocus();
    }//GEN-LAST:event_txtViewBedRoomSearchExpandMouseClicked

    private void txtViewBedRoomSearchExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtViewBedRoomSearchExpandActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtViewBedRoomSearchExpandActionPerformed

    private void txtViewBedRoomSearchExpandKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtViewBedRoomSearchExpandKeyReleased
        // TODO add your handling code here:
         try {
        String search=txtViewBedRoomSearchExpand.getText();
        
        if (rbtnViewBedRoomAllExpand.isSelected())
        {
        if(search.matches("^[0-9]+$"))
        {
           
                ResultSet room_search= stmt.executeQuery("select * from ROOM where ROOM_NO ="+Integer.parseInt(search));
                tblViewBedRoomExpand.setModel(DbUtils.resultSetToTableModel(room_search));
                customtable(tblViewBedRoomExpand);
                
        }
        else
        {
        ResultSet room_search= stmt.executeQuery("select * from ROOM where ROOM_TYPE like '%"+search+"%'");
                tblViewBedRoomExpand.setModel(DbUtils.resultSetToTableModel(room_search));
                customtable(tblViewBedRoomExpand);
        }
        }
        
        else if (rbtnViewBedRoomAvblExpand.isSelected())
        {
        if(search.matches("^[0-9]+$"))
        {
           
                ResultSet room_search= stmt.executeQuery("select  ROOM_NO,ROOM_TYPE,BED_NO,AC_NONAC,ROOM_CHARGES  from ROOM where STATUS='Not Reserved' and ROOM_NO ="+Integer.parseInt(search));
                tblViewBedRoomExpand.setModel(DbUtils.resultSetToTableModel(room_search));
                customtable(tblViewBedRoomExpand);
        }
        else
        {
        ResultSet room_search= stmt.executeQuery("select ROOM_NO,ROOM_TYPE,BED_NO,AC_NONAC,ROOM_CHARGES  from ROOM where STATUS='Not Reserved' and ROOM_TYPE like '%"+search+"%'");
                tblViewBedRoomExpand.setModel(DbUtils.resultSetToTableModel(room_search));
                customtable(tblViewBedRoomExpand);
        }
        
        }
        
        else{
         if(search.matches("^[0-9]+$"))
        {
           
                ResultSet room_search= stmt.executeQuery("select  ROOM_NO,ROOM_TYPE,BED_NO,AC_NONAC,ROOM_CHARGES  from ROOM where STATUS='Reserved' and ROOM_NO ="+Integer.parseInt(search));
                tblViewBedRoomExpand.setModel(DbUtils.resultSetToTableModel(room_search));
                customtable(tblViewBedRoomExpand);
        }
        else
        {
        ResultSet room_search= stmt.executeQuery("select ROOM_NO,ROOM_TYPE,BED_NO,AC_NONAC,ROOM_CHARGES  from ROOM where STATUS='Reserved' and ROOM_TYPE like '%"+search+"%'");
                tblViewBedRoomExpand.setModel(DbUtils.resultSetToTableModel(room_search));
                customtable(tblViewBedRoomExpand);
        }
        
        }
        
        
         } catch (SQLException ex) {
                Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_txtViewBedRoomSearchExpandKeyReleased

    private void rbtnViewBedRoomAllExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnViewBedRoomAllExpandActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            ResultSet view_room=stmt.executeQuery("select * from ROOM");
            tblViewBedRoomExpand.setModel(DbUtils.resultSetToTableModel(view_room));
             customtable(tblViewBedRoomExpand);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnViewBedRoomAllExpandActionPerformed

    private void rbtnIndoorViewListIDExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnIndoorViewListIDExpandActionPerformed
        // TODO add your handling code here:
         try {
            // TODO add your handling code here:
            txtIndoorViewListSearchExpand.setText("Patient ID");
            ResultSet rstmt =stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR");
            jTable1Expand.setModel(DbUtils.resultSetToTableModel(rstmt));
            customtable(jTable1Expand);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnIndoorViewListIDExpandActionPerformed

    private void rbtnIndoorViewListNameExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnIndoorViewListNameExpandActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            txtIndoorViewListSearchExpand.setText("Patient Name");
            ResultSet rstmt =stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR");
            jTable1Expand.setModel(DbUtils.resultSetToTableModel(rstmt));
            customtable(jTable1Expand);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnIndoorViewListNameExpandActionPerformed

    private void rbtnIndoorViewListDocRefExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnIndoorViewListDocRefExpandActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            txtIndoorViewListSearchExpand.setText("Doctor Name");
            ResultSet rstmt =stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR");
            jTable1Expand.setModel(DbUtils.resultSetToTableModel(rstmt));
            customtable(jTable1Expand);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnIndoorViewListDocRefExpandActionPerformed

    private void rbtnIndoorViewListR_WExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnIndoorViewListR_WExpandActionPerformed
        // TODO add your handling code here:
         try {
            // TODO add your handling code here:
            txtIndoorViewListSearchExpand.setText("Room/Ward");
            ResultSet rstmt =stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR");
            jTable1Expand.setModel(DbUtils.resultSetToTableModel(rstmt));
            customtable(jTable1Expand);
        } catch (SQLException ex) {
            Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_rbtnIndoorViewListR_WExpandActionPerformed

    private void txtIndoorViewListSearchExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtIndoorViewListSearchExpandMouseClicked
        // TODO add your handling code here:
         txtIndoorViewListSearchExpand.setText("");
        txtIndoorViewListSearchExpand.grabFocus();
    }//GEN-LAST:event_txtIndoorViewListSearchExpandMouseClicked

    private void txtIndoorViewListSearchExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIndoorViewListSearchExpandActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIndoorViewListSearchExpandActionPerformed

    private void txtIndoorViewListSearchExpandKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIndoorViewListSearchExpandKeyReleased
        // TODO add your handling code here:
        try{
            String search=txtIndoorViewListSearchExpand.getText();
             if(rbtnIndoorViewListNameExpand.isSelected())
            {
                if(search.matches("[0-9]+$"))
                {
                JOptionPane.showMessageDialog(null,"Enter name. Numerical value not accepted");
                }
                else
                {
                ResultSet rs=stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR where NAME like'%"+search+"%' and DISCHARGE_DATE is null");
                jTable1Expand.setModel(DbUtils.resultSetToTableModel(rs));
                customtable(jTable1Expand);
                }
            }
            if(rbtnIndoorViewListIDExpand.isSelected())
            {
                
                if (search.matches("[0-9]+$"))
                {
            ResultSet rs=stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR where PATIENT_ID ="+Integer.parseInt(search)+" and DISCHARGE_DATE is null");
                jTable1Expand.setModel(DbUtils.resultSetToTableModel(rs));
                customtable(jTable1Expand);
                }
            }
            if(rbtnIndoorViewListDocRefExpand.isSelected())
            {
                if(search.matches("[0-9]+$"))
                {
                JOptionPane.showMessageDialog(null,"Enter name. Numerical value not accepted");
                }
                else
                {
            ResultSet rs=stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR where DOC_NAME like '%"+"Dr."+search+"%' and DISCHARGE_DATE is null");
                jTable1Expand.setModel(DbUtils.resultSetToTableModel(rs));
                customtable(jTable1Expand);
            }}
            if(rbtnIndoorViewListR_WExpand.isSelected())
            {
                if (search.matches("[0-9]+$"))
                {
            ResultSet rs=stmt.executeQuery("select PATIENT_ID,NAME,GENDER,DOC_NAME_SPECIALISATION,ADMIT_DATE,WARD_ROOM_NO from INDOOR where WARD_ROOM_NO="+Integer.parseInt(search)+" and DISCHARGE_DATE is null");
                jTable1Expand.setModel(DbUtils.resultSetToTableModel(rs));
                customtable(jTable1Expand);
            }}
        }
        catch (SQLException ex) {
                Logger.getLogger(Reception_Front.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_txtIndoorViewListSearchExpandKeyReleased

    private void tblPDConfirmExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPDConfirmExpandMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tblPDConfirmExpandMouseClicked

    private void btnPDConfirmPatientExpandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDConfirmPatientExpandActionPerformed
        // TODO add your handling code here:
         DefaultTableModel model = (DefaultTableModel)tblPDConfirmExpand.getModel();
        int selectedRowIndex = tblPDConfirmExpand.getSelectedRow();
        try{
            Email email = new Email("somu178p@gmail.com","somuupsn178"); // sender email address and password
            email.setFrom   ("somu178p@gmail.com", "Saumya Patel"); // sender email address and name
            email.setSubject("User ID Confirmation"); // subject of your email
            email.setText("This mail is to inform you that your request to add a new ID to your username is accepted and confirmed.With regards,UPSN Hospital"); // any text you want to send in email
            
            email.addRecipient(model.getValueAt(selectedRowIndex, 4).toString()); // recipient email address
            email.send(); // send email
            
        }catch(UnsupportedEncodingException | MessagingException err){
            System.out.println(err);
        }
         try{
            int P = JOptionPane.showConfirmDialog(null," Are you sure want to delete ?","Confirmation",JOptionPane.YES_NO_OPTION);
            if (P==0)
            {

                String sql= "delete from PATIENT_INFO_TEMPORARY where NAME = " + model.getValueAt(selectedRowIndex, 0).toString() + "";
                PreparedStatement pst11=con.prepareStatement(sql);
                pst11.execute();
                
                JOptionPane.showMessageDialog(this,"Successfully deleted","Record",JOptionPane.INFORMATION_MESSAGE);

            }
           
        }catch(HeadlessException | SQLException ex){
            JOptionPane.showMessageDialog(this,ex);
        }
    }//GEN-LAST:event_btnPDConfirmPatientExpandActionPerformed

    private void lblIndoorPatientViewCollaspMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblIndoorPatientViewCollaspMouseClicked
        // TODO add your handling code here:
        txtRecordsLabExpandSearch.setText("Patient Name");
        rbtnIndoorViewListNameExpand.setSelected(true);
        maincardlayout.show(pnlMainContainer,"MainDashCard");
        cardlayout.show(pnlRecepContentContainer,"AddPatientCard");
        indoorpatientcardlayout.show(pnlIndoorPatientContainer,"IndoorPatientViewListCard");
    }//GEN-LAST:event_lblIndoorPatientViewCollaspMouseClicked

    private void lblBedWardViewCollaspMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBedWardViewCollaspMouseClicked
        // TODO add your handling code here:
        txtViewBedWardSearchExpand.setText("Ward Type or Ward No");
        rbtnViewBedWardAllExpand.setSelected(true);
        maincardlayout.show(pnlMainContainer,"MainDashCard");
        cardlayout.show(pnlRecepContentContainer,"ViewBedCard");
        viewbedcardlayout.show(pnlViewBedContainer, "ViewWardCard");
    }//GEN-LAST:event_lblBedWardViewCollaspMouseClicked

    private void lblBedRoomViewCollaspMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBedRoomViewCollaspMouseClicked
        // TODO add your handling code here:
         txtViewBedRoomSearchExpand.setText("Room Type or Room No");
        rbtnViewBedRoomAllExpand.setSelected(true);
        maincardlayout.show(pnlMainContainer,"MainDashCard");
        cardlayout.show(pnlRecepContentContainer,"ViewBedCard");
        viewbedcardlayout.show(pnlViewBedContainer, "ViewRoomCard");
    }//GEN-LAST:event_lblBedRoomViewCollaspMouseClicked

    private void lblPDSearchCollaspMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPDSearchCollaspMouseClicked
        // TODO add your handling code here:
        txtPDExpandSearch.setText("Patient Name");
        maincardlayout.show(pnlMainContainer,"MainDashCard");
        cardlayout.show(pnlRecepContentContainer,"PDCard");
        PDcardlayout.show(pnlPDContainer,"PDSearchCard");
        
    }//GEN-LAST:event_lblPDSearchCollaspMouseClicked

    private void lblPDConfirmCollaspMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPDConfirmCollaspMouseClicked
        // TODO add your handling code here:
        maincardlayout.show(pnlMainContainer,"MainDashCard");
        cardlayout.show(pnlRecepContentContainer,"PDCard");
        PDcardlayout.show(pnlPDContainer,"PDConfirmCard");
    }//GEN-LAST:event_lblPDConfirmCollaspMouseClicked

    private void lblViewBedRoomExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblViewBedRoomExpandMouseClicked
        // TODO add your handling code here:
        maincardlayout.show(pnlMainContainer,"BedRoomViewCard");
    }//GEN-LAST:event_lblViewBedRoomExpandMouseClicked

    private void lblViewBedWardExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblViewBedWardExpandMouseClicked
        // TODO add your handling code here:
        maincardlayout.show(pnlMainContainer,"BedWardViewCard");
    }//GEN-LAST:event_lblViewBedWardExpandMouseClicked

    private void lblPDConfirmExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPDConfirmExpandMouseClicked
        // TODO add your handling code here:
        maincardlayout.show(pnlMainContainer,"PDConfirmCard");
    }//GEN-LAST:event_lblPDConfirmExpandMouseClicked

    private void lblPDSearchExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPDSearchExpandMouseClicked
        // TODO add your handling code here:
        maincardlayout.show(pnlMainContainer,"PDSearchCard");
    }//GEN-LAST:event_lblPDSearchExpandMouseClicked

    private void lblIndoorViewListExpandMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblIndoorViewListExpandMouseClicked
        // TODO add your handling code here:
        maincardlayout.show(pnlMainContainer,"IndoorViewCard");
    }//GEN-LAST:event_lblIndoorViewListExpandMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Reception_Front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Reception_Front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Reception_Front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Reception_Front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reception_Front().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private keeptoo.KButton btnAddPatientAdmit;
    private keeptoo.KButton btnAddPatientDischarge;
    private keeptoo.KButton btnAddPatientViewList;
    private keeptoo.KButton btnBAppointmentReset;
    private keeptoo.KButton btnBAppointmentSubmit;
    private keeptoo.KButton btnBedRoom;
    private keeptoo.KButton btnBedRoomBookingBook;
    private keeptoo.KButton btnBedRoomBookingCancel;
    private keeptoo.KButton btnBedRoomCheckAvail;
    private keeptoo.KButton btnBedRoomProceed2Book;
    private keeptoo.KButton btnBedWard;
    private keeptoo.KButton btnBedWardBookingBook;
    private keeptoo.KButton btnBedWardBookingCancel;
    private keeptoo.KButton btnBedWardCheckAvail;
    private keeptoo.KButton btnBedWardProceed2Book;
    private keeptoo.KButton btnBookAppointment;
    private keeptoo.KButton btnIndoorPatientAdmitAdmit;
    private keeptoo.KButton btnIndoorPatientDischargeGenerateBill;
    private keeptoo.KButton btnNTestGenerateReciept;
    private keeptoo.KButton btnNewLabTest;
    private keeptoo.KButton btnPDAddAddPatient;
    private keeptoo.KButton btnPDAddPatient;
    private keeptoo.KButton btnPDConfirm;
    private keeptoo.KButton btnPDConfirmPatient;
    private keeptoo.KButton btnPDConfirmPatientExpand;
    private keeptoo.KButton btnPDSearchDb1;
    private javax.swing.JButton btnRecepFrontAdmitPatient;
    private javax.swing.JButton btnRecepFrontAppointment;
    private javax.swing.JButton btnRecepFrontBed;
    private javax.swing.JButton btnRecepFrontLab;
    private keeptoo.KButton btnRecordsConsultancy;
    private keeptoo.KButton btnRecordsIndoor;
    private keeptoo.KButton btnRecordsLab;
    private keeptoo.KButton btnViewAppointment;
    private keeptoo.KButton btnViewBedRoom;
    private keeptoo.KButton btnViewBedWard;
    private javax.swing.ButtonGroup btngrpBedRoomAC_NAC;
    private javax.swing.ButtonGroup btngrpBedWardAC_NAC;
    private javax.swing.ButtonGroup btngrpDDSearchFilter;
    private javax.swing.ButtonGroup btngrpIndoorPatientViewListSort;
    private javax.swing.ButtonGroup btngrpViewBedRoomrev_avlb;
    private javax.swing.ButtonGroup btngrpViewBedWardrev_avlb;
    private javax.swing.JComboBox<String> cbATime;
    private javax.swing.JComboBox<String> cbBedRoom;
    private javax.swing.JComboBox<String> cbBedWard;
    private javax.swing.JComboBox<String> cbDepartment;
    private javax.swing.JComboBox<String> cbDocName;
    private javax.swing.JComboBox<String> cbPDAddBloodGrp;
    private javax.swing.JComboBox<String> cbPDAddCity;
    private javax.swing.JComboBox<String> cbPDAddContact;
    private javax.swing.JComboBox<String> cbPDAddGender;
    private javax.swing.JComboBox<String> cbPDAddState;
    private javax.swing.JComboBox<String> cbPhnNum;
    private com.toedter.calendar.DateUtil dateUtil1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable1Expand;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private com.toedter.calendar.JDateChooser jcalADate;
    private com.toedter.calendar.JDateChooser jcalPDAddDOB;
    private keeptoo.KGradientPanel kGradientPanel1;
    private keeptoo.KGradientPanel kGradientPanel2;
    private keeptoo.KGradientPanel kGradientPanel3;
    private keeptoo.KGradientPanel kpnlAppointmentMenuBar;
    private keeptoo.KGradientPanel kpnlDDtMenuBar;
    private keeptoo.KGradientPanel kpnlLabMenuBar;
    private keeptoo.KGradientPanel kpnlPDMenuBar;
    private keeptoo.KGradientPanel kpnlRecepDash;
    private keeptoo.KGradientPanel kpnlViewBedMenuBar;
    private javax.swing.JLabel lblADate;
    private javax.swing.JLabel lblATime;
    private javax.swing.JLabel lblAddPatientBack;
    private javax.swing.JLabel lblAppointmentBack;
    private javax.swing.JLabel lblAppointmentRecieptAge;
    private javax.swing.JLabel lblAppointmentRecieptAgeTag;
    private javax.swing.JLabel lblAppointmentRecieptAmountPaid;
    private javax.swing.JLabel lblAppointmentRecieptAmountPaidTag;
    private javax.swing.JLabel lblAppointmentRecieptAppointmentDate;
    private javax.swing.JLabel lblAppointmentRecieptBackIcon;
    private javax.swing.JLabel lblAppointmentRecieptBillNo;
    private javax.swing.JLabel lblAppointmentRecieptBillNoTag;
    private javax.swing.JLabel lblAppointmentRecieptCTax;
    private javax.swing.JLabel lblAppointmentRecieptCTaxTag;
    private javax.swing.JLabel lblAppointmentRecieptConChrg;
    private javax.swing.JLabel lblAppointmentRecieptConChrgTag;
    private javax.swing.JLabel lblAppointmentRecieptDate;
    private javax.swing.JLabel lblAppointmentRecieptDateTag;
    private javax.swing.JLabel lblAppointmentRecieptDocName;
    private javax.swing.JLabel lblAppointmentRecieptDocSpec;
    private javax.swing.JLabel lblAppointmentRecieptKin;
    private javax.swing.JLabel lblAppointmentRecieptKinTag;
    private javax.swing.JLabel lblAppointmentRecieptLogo;
    private javax.swing.JLabel lblAppointmentRecieptName;
    private javax.swing.JLabel lblAppointmentRecieptNameTag;
    private javax.swing.JLabel lblAppointmentRecieptPrintIcon;
    private javax.swing.JLabel lblAppointmentRecieptRecepTag;
    private javax.swing.JLabel lblAppointmentRecieptSTax;
    private javax.swing.JLabel lblAppointmentRecieptSTaxTag;
    private javax.swing.JLabel lblAppointmentRecieptSex;
    private javax.swing.JLabel lblAppointmentRecieptSexTag;
    private javax.swing.JLabel lblAppointmentViewExpand;
    private javax.swing.JLabel lblBAppointmentInvalidDate;
    private javax.swing.JLabel lblBAppointmentMandatory;
    private javax.swing.JLabel lblBAppointmentMandatory1;
    private javax.swing.JLabel lblBedBack;
    private javax.swing.JLabel lblBedRoom1;
    private javax.swing.JLabel lblBedRoomBookingBedN;
    private javax.swing.JLabel lblBedRoomBookingBedNTag;
    private javax.swing.JLabel lblBedRoomBookingPatientID;
    private javax.swing.JLabel lblBedRoomBookingRoomN;
    private javax.swing.JLabel lblBedRoomBookingRoomNoTag;
    private javax.swing.JLabel lblBedRoomBookingRoomType;
    private javax.swing.JLabel lblBedRoomBookingRoomTypeTag;
    private javax.swing.JLabel lblBedRoomBookingWarning;
    private javax.swing.JLabel lblBedRoomViewCollasp;
    private javax.swing.JLabel lblBedWard1;
    private javax.swing.JLabel lblBedWardBookingBedN;
    private javax.swing.JLabel lblBedWardBookingBedNTag;
    private javax.swing.JLabel lblBedWardBookingPatientID;
    private javax.swing.JLabel lblBedWardBookingWardN;
    private javax.swing.JLabel lblBedWardBookingWardNoTag;
    private javax.swing.JLabel lblBedWardBookingWardType;
    private javax.swing.JLabel lblBedWardBookingWardTypeTag;
    private javax.swing.JLabel lblBedWardBookingWarning;
    private javax.swing.JLabel lblBedWardViewCollasp;
    private javax.swing.JLabel lblDDBack;
    private javax.swing.JLabel lblDepartment;
    private javax.swing.JLabel lblDischargeWarning;
    private javax.swing.JLabel lblDocName;
    private javax.swing.JLabel lblIndoorBilAdmitDate;
    private javax.swing.JLabel lblIndoorBilAge;
    private javax.swing.JLabel lblIndoorBilAgeTag;
    private javax.swing.JLabel lblIndoorBilAmountPaid;
    private javax.swing.JLabel lblIndoorBilAmountPaidTag;
    private javax.swing.JLabel lblIndoorBilBackIcon;
    private javax.swing.JLabel lblIndoorBilBillNo;
    private javax.swing.JLabel lblIndoorBilBillNoTag;
    private javax.swing.JLabel lblIndoorBilCTax;
    private javax.swing.JLabel lblIndoorBilCTaxTag;
    private javax.swing.JLabel lblIndoorBilConChrg;
    private javax.swing.JLabel lblIndoorBilConChrgTag;
    private javax.swing.JLabel lblIndoorBilDate;
    private javax.swing.JLabel lblIndoorBilDateTag;
    private javax.swing.JLabel lblIndoorBilDischargeDate;
    private javax.swing.JLabel lblIndoorBilDischargeDateTag;
    private javax.swing.JLabel lblIndoorBilDisease;
    private javax.swing.JLabel lblIndoorBilDiseaseTag;
    private javax.swing.JLabel lblIndoorBilDocName;
    private javax.swing.JLabel lblIndoorBilDocSpec;
    private javax.swing.JLabel lblIndoorBilKin;
    private javax.swing.JLabel lblIndoorBilKinTag;
    private javax.swing.JLabel lblIndoorBilLogo;
    private javax.swing.JLabel lblIndoorBilName;
    private javax.swing.JLabel lblIndoorBilNameTag;
    private javax.swing.JLabel lblIndoorBilPrintIcon;
    private javax.swing.JLabel lblIndoorBilRecepTag;
    private javax.swing.JLabel lblIndoorBilRoomChrg;
    private javax.swing.JLabel lblIndoorBilRoomChrgTag;
    private javax.swing.JLabel lblIndoorBilSC;
    private javax.swing.JLabel lblIndoorBilSCTag;
    private javax.swing.JLabel lblIndoorBilSTax;
    private javax.swing.JLabel lblIndoorBilSTaxTag;
    private javax.swing.JLabel lblIndoorBilSex;
    private javax.swing.JLabel lblIndoorBilSexTag;
    private javax.swing.JLabel lblIndoorBilTDays;
    private javax.swing.JLabel lblIndoorBilTDaysTag;
    private javax.swing.JLabel lblIndoorBillAdmitDateTag;
    private javax.swing.JLabel lblIndoorPatientViewCollasp;
    private javax.swing.JLabel lblIndoorViewListExpand;
    private javax.swing.JLabel lblLabBack;
    private javax.swing.JLabel lblLabNewTestWarning;
    private javax.swing.JLabel lblLabRecieptAge;
    private javax.swing.JLabel lblLabRecieptAgeTag;
    private javax.swing.JLabel lblLabRecieptAmountPaid;
    private javax.swing.JLabel lblLabRecieptAmountPaidTag;
    private javax.swing.JLabel lblLabRecieptBackIcon;
    private javax.swing.JLabel lblLabRecieptBillNo;
    private javax.swing.JLabel lblLabRecieptBillNoTag;
    private javax.swing.JLabel lblLabRecieptCTax;
    private javax.swing.JLabel lblLabRecieptCTaxTag;
    private javax.swing.JLabel lblLabRecieptDate;
    private javax.swing.JLabel lblLabRecieptDateTag;
    private javax.swing.JLabel lblLabRecieptKin;
    private javax.swing.JLabel lblLabRecieptKinTag;
    private javax.swing.JLabel lblLabRecieptLogo;
    private javax.swing.JLabel lblLabRecieptName;
    private javax.swing.JLabel lblLabRecieptNameTag;
    private javax.swing.JLabel lblLabRecieptPrintIcon;
    private javax.swing.JLabel lblLabRecieptRecepTag;
    private javax.swing.JLabel lblLabRecieptSTax;
    private javax.swing.JLabel lblLabRecieptSTaxTag;
    private javax.swing.JLabel lblLabRecieptSex;
    private javax.swing.JLabel lblLabRecieptSexTag;
    private javax.swing.JLabel lblLabRecieptTestName;
    private javax.swing.JLabel lblLabRecieptTestRate;
    private javax.swing.JLabel lblNTestPatientID;
    private javax.swing.JLabel lblNTestTest;
    private javax.swing.JLabel lblPDAddBloodGrpTag;
    private javax.swing.JLabel lblPDAddCityTag;
    private javax.swing.JLabel lblPDAddContactTag;
    private javax.swing.JLabel lblPDAddDOBTag;
    private javax.swing.JLabel lblPDAddGenderTag;
    private javax.swing.JLabel lblPDAddInvalidDate;
    private javax.swing.JLabel lblPDAddKinTag;
    private javax.swing.JLabel lblPDAddMandatory;
    private javax.swing.JLabel lblPDAddPatientNameTag;
    private javax.swing.JLabel lblPDAddStateTag;
    private javax.swing.JLabel lblPDAddStreetTag;
    private javax.swing.JLabel lblPDBack;
    private javax.swing.JLabel lblPDConfirmCollasp;
    private javax.swing.JLabel lblPDConfirmExpand;
    private javax.swing.JLabel lblPDSearchCollasp;
    private javax.swing.JLabel lblPDSearchExpand;
    private javax.swing.JLabel lblPatientID;
    private javax.swing.JLabel lblPhnNum;
    private javax.swing.JLabel lblRecepFrontDDB;
    private javax.swing.JLabel lblRecepFrontDash;
    private javax.swing.JLabel lblRecepFrontHelp;
    private javax.swing.JLabel lblRecepFrontIcon;
    private javax.swing.JLabel lblRecepFrontLogout;
    private javax.swing.JLabel lblRecepFrontPDB;
    private javax.swing.JLabel lblRecepFrontRecords;
    private javax.swing.JLabel lblRecepFrontSetting;
    private javax.swing.JLabel lblRecepFrontUname;
    private javax.swing.JLabel lblRecordsBack;
    private javax.swing.JLabel lblRecordsConsultancyCollasp;
    private javax.swing.JLabel lblRecordsConsultancyExpand;
    private javax.swing.JLabel lblRecordsIndoorCollasp;
    private javax.swing.JLabel lblRecordsIndoorExpand;
    private javax.swing.JLabel lblRecordsLabCollasp;
    private javax.swing.JLabel lblRecordsLabExpand;
    private javax.swing.JLabel lblViewAppointmentCollasp;
    private javax.swing.JLabel lblViewBedBack;
    private javax.swing.JLabel lblViewBedRoomExpand;
    private javax.swing.JLabel lblViewBedWardExpand;
    private keeptoo.KGradientPanel markAddPatient;
    private keeptoo.KGradientPanel markAdmitPatient;
    private keeptoo.KGradientPanel markAppointmentBook;
    private keeptoo.KGradientPanel markAppointmentView;
    private keeptoo.KGradientPanel markBedBookingRoom;
    private keeptoo.KGradientPanel markBedBookingWard;
    private keeptoo.KGradientPanel markBedListRoom;
    private keeptoo.KGradientPanel markBedListWard;
    private keeptoo.KGradientPanel markDD;
    private keeptoo.KGradientPanel markDash;
    private keeptoo.KGradientPanel markDischargePatient;
    private keeptoo.KGradientPanel markHelp;
    private keeptoo.KGradientPanel markIndoorList;
    private keeptoo.KGradientPanel markLabNewTest;
    private keeptoo.KGradientPanel markPD;
    private keeptoo.KGradientPanel markPDConfirm;
    private keeptoo.KGradientPanel markPdSearch;
    private keeptoo.KGradientPanel markRecords;
    private keeptoo.KGradientPanel markRecordsConsultancy;
    private keeptoo.KGradientPanel markRecordsIndoor;
    private keeptoo.KGradientPanel markRecordsLab;
    private keeptoo.KGradientPanel markSettings;
    private com.toedter.calendar.MinMaxDateEvaluator minMaxDateEvaluator1;
    private javax.swing.JPanel pnlAddPatientCard;
    private javax.swing.JPanel pnlApointmentReciept;
    private javax.swing.JPanel pnlAppointmentCard;
    private javax.swing.JPanel pnlAppointmentContainer;
    private javax.swing.JPanel pnlAppointmentRecieptContainer;
    private javax.swing.JPanel pnlAppointmentViewExpand;
    private javax.swing.JPanel pnlBAppointment;
    private javax.swing.JPanel pnlBedCard;
    private javax.swing.JPanel pnlBedContainer;
    private javax.swing.JPanel pnlBedRoom;
    private javax.swing.JPanel pnlBedRoomBooking;
    private javax.swing.JPanel pnlBedRoomViewExpand;
    private javax.swing.JPanel pnlBedWard;
    private javax.swing.JPanel pnlBedWardBooking;
    private javax.swing.JPanel pnlBedWardViewExpand;
    private javax.swing.JPanel pnlDDCard;
    private javax.swing.JPanel pnlDashMainCard;
    private javax.swing.JPanel pnlIndoorBill;
    private javax.swing.JPanel pnlIndoorPatientAdmit;
    private javax.swing.JPanel pnlIndoorPatientBillContainer;
    private javax.swing.JPanel pnlIndoorPatientContainer;
    private javax.swing.JPanel pnlIndoorPatientDischarge;
    private javax.swing.JPanel pnlIndoorPatientViewExpand;
    private javax.swing.JPanel pnlIndoorPatientViewList;
    private javax.swing.JPanel pnlLabCard;
    private javax.swing.JPanel pnlLabContainer;
    private javax.swing.JPanel pnlLabReciept;
    private javax.swing.JPanel pnlLabRecieptContainer;
    private javax.swing.JPanel pnlMainContainer;
    private javax.swing.JPanel pnlMainDashContainer;
    private javax.swing.JPanel pnlNewTest;
    private javax.swing.JPanel pnlPDAdd;
    private javax.swing.JPanel pnlPDCard;
    private javax.swing.JPanel pnlPDConfirm;
    private javax.swing.JPanel pnlPDConfirmExpand;
    private javax.swing.JPanel pnlPDContainer;
    private javax.swing.JPanel pnlPDSearch;
    private javax.swing.JPanel pnlPDSearchExpand;
    private javax.swing.JPanel pnlRecepContentContainer;
    private javax.swing.JPanel pnlRecords;
    private javax.swing.JPanel pnlRecordsConsultancy;
    private javax.swing.JPanel pnlRecordsConsultancyExpand;
    private javax.swing.JPanel pnlRecordsContainer;
    private javax.swing.JPanel pnlRecordsIndoor;
    private javax.swing.JPanel pnlRecordsIndoorExpand;
    private javax.swing.JPanel pnlRecordsLab;
    private javax.swing.JPanel pnlRecordsLabExpand;
    private javax.swing.JPanel pnlViewAppointment;
    private javax.swing.JPanel pnlViewBedCard;
    private javax.swing.JPanel pnlViewBedContainer;
    private javax.swing.JPanel pnlViewBedRoom;
    private javax.swing.JPanel pnlViewBedWard;
    private javax.swing.JRadioButton rbtnBedRoomAC;
    private javax.swing.JRadioButton rbtnBedRoomNAC;
    private javax.swing.JRadioButton rbtnBedWardAC;
    private javax.swing.JRadioButton rbtnBedWardNAC;
    private javax.swing.JRadioButton rbtnDDSearchName;
    private javax.swing.JRadioButton rbtnDDSearchSpecialisation;
    private javax.swing.JRadioButton rbtnIndoorViewListDocRef;
    private javax.swing.JRadioButton rbtnIndoorViewListDocRefExpand;
    private javax.swing.JRadioButton rbtnIndoorViewListID;
    private javax.swing.JRadioButton rbtnIndoorViewListIDExpand;
    private javax.swing.JRadioButton rbtnIndoorViewListName;
    private javax.swing.JRadioButton rbtnIndoorViewListNameExpand;
    private javax.swing.JRadioButton rbtnIndoorViewListR_W;
    private javax.swing.JRadioButton rbtnIndoorViewListR_WExpand;
    private javax.swing.JRadioButton rbtnViewBedRoomAll;
    private javax.swing.JRadioButton rbtnViewBedRoomAllExpand;
    private javax.swing.JRadioButton rbtnViewBedRoomAvbl;
    private javax.swing.JRadioButton rbtnViewBedRoomAvblExpand;
    private javax.swing.JRadioButton rbtnViewBedRoomRev;
    private javax.swing.JRadioButton rbtnViewBedRoomRevExpand;
    private javax.swing.JRadioButton rbtnViewBedWardAll;
    private javax.swing.JRadioButton rbtnViewBedWardAllExpand;
    private javax.swing.JRadioButton rbtnViewBedWardAvbl;
    private javax.swing.JRadioButton rbtnViewBedWardAvblExpand;
    private javax.swing.JRadioButton rbtnViewBedWardRev;
    private javax.swing.JRadioButton rbtnViewBedWardRevExpand;
    private javax.swing.JScrollPane spBedRoom;
    private javax.swing.JScrollPane spBedWard;
    private javax.swing.JScrollPane spDDSearch;
    private javax.swing.JScrollPane spPDSearch;
    private javax.swing.JScrollPane spPDSearch1;
    private javax.swing.JScrollPane spPDSearch2;
    private javax.swing.JScrollPane spPDSearch3;
    private javax.swing.JTable tblAppointmentSearch;
    private javax.swing.JTable tblAppointmentSearchExpand;
    private javax.swing.JTable tblBedRoom;
    private javax.swing.JTable tblBedWard;
    private javax.swing.JTable tblDDSearch;
    private javax.swing.JTable tblLabNewTest;
    private javax.swing.JTable tblPDConfirm;
    private javax.swing.JTable tblPDConfirmExpand;
    private javax.swing.JTable tblPDSearch;
    private javax.swing.JTable tblPDSearchExpand;
    private javax.swing.JTable tblRecordsConsultancy;
    private javax.swing.JTable tblRecordsConsultancyExpand;
    private javax.swing.JTable tblRecordsIndoor;
    private javax.swing.JTable tblRecordsIndoorExpand;
    private javax.swing.JTable tblRecordsLab;
    private javax.swing.JTable tblRecordsLabExpand;
    private javax.swing.JTable tblViewBedRoom;
    private javax.swing.JTable tblViewBedRoomExpand;
    private javax.swing.JTable tblViewBedWard;
    private javax.swing.JTable tblViewBedWardExpand;
    private javax.swing.JTextField txtBedRoomBookingPatientID;
    private javax.swing.JTextField txtBedWardBookingPatientID;
    private javax.swing.JTextField txtDDSearch;
    private javax.swing.JTextField txtIndoorPatientDischargePatientID;
    private javax.swing.JTextField txtIndoorViewListSearch;
    private javax.swing.JTextField txtIndoorViewListSearchExpand;
    private javax.swing.JTextField txtLabNewTest;
    private javax.swing.JTextField txtNTestPatientID;
    private javax.swing.JTextField txtPDAddContact;
    private javax.swing.JTextField txtPDAddKin;
    private javax.swing.JTextField txtPDAddPatientName;
    private javax.swing.JTextField txtPDAddStreet;
    private javax.swing.JTextField txtPDExpandSearch;
    private javax.swing.JTextField txtPDSearch;
    private javax.swing.JTextField txtPatientID;
    private javax.swing.JTextField txtPhnNum;
    private javax.swing.JTextField txtRecordsConsultancyExpandSearch;
    private javax.swing.JTextField txtRecordsIndoorExpandSearch;
    private javax.swing.JTextField txtRecordsLabExpandSearch;
    private javax.swing.JTextField txtViewAppointmentExpandSearch;
    private javax.swing.JTextField txtViewAppointmentSearch;
    private javax.swing.JTextField txtViewBedRoomSearch;
    private javax.swing.JTextField txtViewBedRoomSearchExpand;
    private javax.swing.JTextField txtViewBedWardSearch;
    private javax.swing.JTextField txtViewBedWardSearchExpand;
    // End of variables declaration//GEN-END:variables
}
