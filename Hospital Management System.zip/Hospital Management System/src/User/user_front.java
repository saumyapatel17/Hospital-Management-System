/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import Doctor.Doctor_front;
import Login.*;
import Reception.Reception_Front;
import java.sql.*;
import hospital.management.system.*;
import java.lang.*;
import java.awt.*;
import Login.*;
import static hospital.management.system.HospitalManagementSystem.Age_calc;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.text.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import javax.sound.midi.Soundbank;
import javax.swing.*;
import jdk.jfr.Period;
import net.proteanit.sql.DbUtils;
import org.apache.derby.client.am.DateTime;

/**
 *
 * @author HP
 */
public class user_front extends HospitalManagementSystem {

    /**
     * Creates new form user_front
     */
    CardLayout appointmentcardlayout,cardlayout,managecardlayout,viewbillcardlayout;
    
    Statement stmt;
    PreparedStatement pstmt;
    PreparedStatement pstmt1;
    Connection con;
     
    String useruname;
    public user_front() {
    }
    public user_front(String user_name)
    {
        con=DB_Link();
        initComponents();
       
        useruname = user_name;
        
        
        //main cardlayout
        cardlayout=(CardLayout)(pnlUserFrontContainer.getLayout());
        cardlayout.show(pnlUserFrontContainer,"DashCard");
        
        //appointment cardlayout
        appointmentcardlayout=(CardLayout)(pnlUserAppointmentContainer.getLayout());
        appointmentcardlayout.show(pnlUserAppointmentContainer,"BookAppointmentCard");
        
        //manage cardlayout
        managecardlayout=(CardLayout)(pnlUserManageIDContainer.getLayout());
        managecardlayout.show(pnlUserManageIDContainer,"ManageIDAddCard");
        
        //bill cardlayout
        viewbillcardlayout=(CardLayout)(pnlUserViewBillsContainer.getLayout());
        viewbillcardlayout.show(pnlUserViewBillsContainer,"IndoorBillCard");
        
        //patient db 
        lblPDAddInvalidDate.setVisible(false);
        lblPDAddMandatory.setVisible(false);
        
        //appointment booking
        lblBAppointmentMandatory1.setVisible(false);
        lblBAppointmentInvalidDate.setVisible(false);
        lblCAppointmentMandatory.setVisible(false);
        
        //manage id 
        lblManageExistingIDWarning.setVisible(false);
        
        
        //dash marks
        markDash.setVisible(true);
        markHelp.setVisible(false);
        markSettings.setVisible(false);
        
        //manageID marks
        markAddID.setVisible(true);
        markExistingID.setVisible(false);
        
        //appointment marks
        markBAppointment.setVisible(true);
        markCAppointment.setVisible(false);
        
        //bill marks
        markIndoorBill.setVisible(true);
        markConcBill.setVisible(false);
        markLabBill.setVisible(false);
        
    try{
           
        stmt=con.createStatement();
          ResultSet name=stmt.executeQuery("select NAME from USER_PORTAL where USERNAME='"+useruname+"'");
          name.next();
          lblUserFrontUname.setText(name.getString("NAME"));
            
            ResultSet rst=stmt.executeQuery("select distinct SPECIALISATION from DOCTOR_INFO");
        cbDepartment.addItem("Select Specialisation");
         cbDepartment1.addItem("Select Specialisation");
        while(rst.next())
        {
        cbDepartment.addItem(rst.getString("SPECIALISATION"));
        cbDepartment1.addItem(rst.getString("SPECIALISATION"));
        
        }
            
        ResultSet rst1=stmt.executeQuery("select PATIENT_ID from PATIENT_INFO where USERNAME='"+useruname+"'");
                
        cbUsermanageIDExistingIDSel.addItem("Select PATIENT_ID");
        while(rst1.next())
        {
        cbUsermanageIDExistingIDSel.addItem(rst1.getString("PATIENT_ID"));
        
        }
        
        ResultSet indoorpsearch=stmt.executeQuery("select PATIENT_ID from PATIENT_INFO where USERNAME='"+useruname+"'");
                
        cbIndoorPSearch.addItem("Select PATIENT_ID");
        while(indoorpsearch.next())
        {
        cbIndoorPSearch.addItem(indoorpsearch.getString("PATIENT_ID"));
        
        }
        
        ResultSet consultpsearch=stmt.executeQuery("select PATIENT_ID from PATIENT_INFO where USERNAME='"+useruname+"'");
                
        cbConsultancyPSearch.addItem("Select PATIENT_ID");
        while(consultpsearch.next())
        {
        cbConsultancyPSearch.addItem(consultpsearch.getString("PATIENT_ID"));
        
        }
        
        ResultSet labpsearch=stmt.executeQuery("select PATIENT_ID from PATIENT_INFO where USERNAME='"+useruname+"'");
                
        cbLabPSearch.addItem("Select PATIENT_ID");
        while(labpsearch.next())
        {
        cbLabPSearch.addItem(labpsearch.getString("PATIENT_ID"));
        
        }
         ResultSet rst2=stmt.executeQuery("select PATIENT_ID from PATIENT_INFO where USERNAME='"+useruname+"'");
                
        cbPatientId.addItem("Select PATIENT_ID");
        cbPatientId1.addItem("Select PATIENT_ID");
        while(rst2.next())
        {
        cbPatientId.addItem(rst2.getString("PATIENT_ID"));
        cbPatientId1.addItem(rst2.getString("PATIENT_ID"));
        
        }
       
        customtable(tblIndoorBill);
        customtable(tblConsultancyBill);
        customtable(tblLabBill);
        
        
        ResultSet rs=stmt.executeQuery("select distinct STATES from statewise_cities");
        cbUsermanageIDAddNewState.addItem("Select State");
        while(rs.next())
        {
        cbUsermanageIDAddNewState.addItem(rs.getString("STATES"));
        
        }
       }
    catch(SQLException e)
    {java.util.logging.Logger.getLogger(user_front.class.getName()).log(java.util.logging.Level.SEVERE, null, e);
    }
    
    

       
        
        
        
       
       
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kpnlUserFrontDash = new keeptoo.KGradientPanel();
        lblUserFrontLogout = new javax.swing.JLabel();
        lblUserFrontHns = new javax.swing.JLabel();
        lblUserFrontSettings = new javax.swing.JLabel();
        lblUserFrontIcon = new javax.swing.JLabel();
        lblUserFrontUname = new javax.swing.JLabel();
        lblUserFrontDash = new javax.swing.JLabel();
        markDash = new keeptoo.KGradientPanel();
        markSettings = new keeptoo.KGradientPanel();
        markHelp = new keeptoo.KGradientPanel();
        pnlUserFrontContainer = new javax.swing.JPanel();
        pnlUserDashCard = new javax.swing.JPanel();
        btnUserFrontViewBills = new javax.swing.JButton();
        btnUserFrontAppointment = new javax.swing.JButton();
        btnUserFrontManageID = new javax.swing.JButton();
        pnlUserManageIdCard = new javax.swing.JPanel();
        kGradientPanel1 = new keeptoo.KGradientPanel();
        lblUserManageIDback = new javax.swing.JLabel();
        btnUserManageIDGeneratingID = new keeptoo.KButton();
        btnUserManageIDChngingExistingID = new keeptoo.KButton();
        markAddID = new keeptoo.KGradientPanel();
        markExistingID = new keeptoo.KGradientPanel();
        pnlUserManageIDContainer = new javax.swing.JPanel();
        pnlUsermanageIDAddNew = new javax.swing.JPanel();
        lblUsermanageIDAddNewNameTag = new javax.swing.JLabel();
        lblUsermanageIDAddNewKinTag = new javax.swing.JLabel();
        UsermanageIDAddNewKin = new javax.swing.JTextField();
        cbUsermanageIDAddNewGender = new javax.swing.JComboBox<>();
        lblUsermanageIDAddNewGenderTag = new javax.swing.JLabel();
        lblUsermanageIDAddNewDobTag = new javax.swing.JLabel();
        lblUsermanageIDAddNewContactTag = new javax.swing.JLabel();
        txtUsermanageIDAddNewContact = new javax.swing.JTextField();
        lblUsermanageIDAddNewBloodGrpTag = new javax.swing.JLabel();
        cbUsermanageIDAddNewBloodGrp = new javax.swing.JComboBox<>();
        lblUsermanageIDAddNewStreetTag = new javax.swing.JLabel();
        txtUsermanageIDAddNewStreet = new javax.swing.JTextField();
        lblUsermanageIDAddNewStateTag = new javax.swing.JLabel();
        cbUsermanageIDAddNewState = new javax.swing.JComboBox<>();
        cbUsermanageIDAddNewCity = new javax.swing.JComboBox<>();
        lblUsermanageIDAddNewCityTag = new javax.swing.JLabel();
        btnUsermanageIDAddNewAdd = new keeptoo.KButton();
        lblPDAddMandatory = new javax.swing.JLabel();
        cbPDAddContact = new javax.swing.JComboBox<>();
        dateUsermanageIDAddNewDOB = new com.toedter.calendar.JDateChooser();
        txtUsermanageIDAddNewName = new javax.swing.JTextField();
        lblUsermanageIDAddNewStateTag1 = new javax.swing.JLabel();
        txtUsermanageIDAddEmail = new javax.swing.JTextField();
        lblPDAddInvalidDate = new javax.swing.JLabel();
        pnlUsermanageIDExisting = new javax.swing.JPanel();
        lblUsermanageIDExistingSelID = new javax.swing.JLabel();
        cbUsermanageIDExistingIDSel = new javax.swing.JComboBox<>();
        btnUsermanageIDExistingDltID = new keeptoo.KButton();
        txtUsermanageIDExistingIDEnter = new javax.swing.JTextField();
        btnUsermanageIDExistingLinkID = new keeptoo.KButton();
        lblUsermanageIDExistingSelID1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        lblManageExistingIDWarning = new javax.swing.JLabel();
        pnlUserAppointments = new javax.swing.JPanel();
        kGradientPanel2 = new keeptoo.KGradientPanel();
        lblUserAppointmentback = new javax.swing.JLabel();
        btnUserAppointmentBook = new keeptoo.KButton();
        btnUserAppointmentCancel = new keeptoo.KButton();
        markBAppointment = new keeptoo.KGradientPanel();
        markCAppointment = new keeptoo.KGradientPanel();
        pnlUserAppointmentContainer = new javax.swing.JPanel();
        pnlBAppointment = new javax.swing.JPanel();
        lblPatientID = new javax.swing.JLabel();
        lblPhnNum = new javax.swing.JLabel();
        txtPhnNum = new javax.swing.JTextField();
        lblDepartment = new javax.swing.JLabel();
        cbDepartment = new javax.swing.JComboBox<>();
        lblDocName = new javax.swing.JLabel();
        cbDocName = new javax.swing.JComboBox<>();
        lblADate = new javax.swing.JLabel();
        lblATime = new javax.swing.JLabel();
        cbATime = new javax.swing.JComboBox<>();
        btnBAppointmentSubmit = new keeptoo.KButton();
        jcalADate = new com.toedter.calendar.JDateChooser();
        cbPatientId = new javax.swing.JComboBox<>();
        cbPhnNum = new javax.swing.JComboBox<>();
        lblBAppointmentMandatory1 = new javax.swing.JLabel();
        btnBAppointmentReset = new keeptoo.KButton();
        lblBAppointmentInvalidDate = new javax.swing.JLabel();
        pnlCAppointment = new javax.swing.JPanel();
        lblPatientID1 = new javax.swing.JLabel();
        cbPatientId1 = new javax.swing.JComboBox<>();
        lblDocName1 = new javax.swing.JLabel();
        cbDocName1 = new javax.swing.JComboBox<>();
        lblADate1 = new javax.swing.JLabel();
        jcalADate1 = new com.toedter.calendar.JDateChooser();
        lblATime1 = new javax.swing.JLabel();
        cbATime1 = new javax.swing.JComboBox<>();
        lblCAppointmentMandatory = new javax.swing.JLabel();
        btnCAppointmentCannel = new keeptoo.KButton();
        lblDepartment1 = new javax.swing.JLabel();
        cbDepartment1 = new javax.swing.JComboBox<>();
        pnlAppointmentReceiptContainer = new javax.swing.JPanel();
        pnlAppointmentRecieptContainer = new javax.swing.JPanel();
        pnlApointmentReciept = new javax.swing.JPanel();
        lblAppointmentRecieptBillNoTag = new javax.swing.JLabel();
        lblAppointmentRecieptLogo = new javax.swing.JLabel();
        lblAppointmentRecieptBillNo = new javax.swing.JLabel();
        lblAppointmentRecieptNameTag = new javax.swing.JLabel();
        lblAppointmentRecieptName = new javax.swing.JLabel();
        lblAppointmentRecieptKin = new javax.swing.JLabel();
        lblAppointmentRecieptKinTag = new javax.swing.JLabel();
        lblAppointmentRecieptAgeTag = new javax.swing.JLabel();
        lblAppointmentRecieptAge = new javax.swing.JLabel();
        lblAppointmentRecieptDateTag = new javax.swing.JLabel();
        lblAppointmentRecieptSex = new javax.swing.JLabel();
        lblAppointmentRecieptSexTag = new javax.swing.JLabel();
        lblAppointmentRecieptDate = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        lblAppointmentRecieptDocName = new javax.swing.JLabel();
        lblAppointmentRecieptConChrg = new javax.swing.JLabel();
        lblAppointmentRecieptSTax = new javax.swing.JLabel();
        lblAppointmentRecieptCTax = new javax.swing.JLabel();
        lblAppointmentRecieptAmountPaid = new javax.swing.JLabel();
        lblAppointmentRecieptSTaxTag = new javax.swing.JLabel();
        lblAppointmentRecieptCTaxTag = new javax.swing.JLabel();
        lblAppointmentRecieptAmountPaidTag = new javax.swing.JLabel();
        lblAppointmentRecieptRecepTag = new javax.swing.JLabel();
        lblAppointmentRecieptConChrgTag = new javax.swing.JLabel();
        lblAppointmentRecieptDocSpec = new javax.swing.JLabel();
        lblAppointmentRecieptAppointmentDate = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        lblAppointmentRecieptPrintIcon = new javax.swing.JLabel();
        lblAppointmentRecieptBackIcon = new javax.swing.JLabel();
        pnlUserViewBills = new javax.swing.JPanel();
        kGradientPanel3 = new keeptoo.KGradientPanel();
        lblUserViewBillsBack = new javax.swing.JLabel();
        btnUserManageIDViewIndoorBill = new keeptoo.KButton();
        btnUserManageIDViewLabBill = new keeptoo.KButton();
        btnUserManageIDViewConsultancyBill = new keeptoo.KButton();
        markIndoorBill = new keeptoo.KGradientPanel();
        markConcBill = new keeptoo.KGradientPanel();
        markLabBill = new keeptoo.KGradientPanel();
        pnlUserViewBillsContainer = new javax.swing.JPanel();
        pnlViewIndoorBills = new javax.swing.JPanel();
        spIndoorBill = new javax.swing.JScrollPane();
        tblIndoorBill = new javax.swing.JTable();
        lblIndoorPSearchIcon = new javax.swing.JLabel();
        cbIndoorPSearch = new javax.swing.JComboBox<>();
        pnlViewLabBills = new javax.swing.JPanel();
        spLabBill = new javax.swing.JScrollPane();
        tblLabBill = new javax.swing.JTable();
        lblLabPSearchIcon = new javax.swing.JLabel();
        cbLabPSearch = new javax.swing.JComboBox<>();
        pnlViewConsultancyBills = new javax.swing.JPanel();
        lblConsultancyPSearchIcon = new javax.swing.JLabel();
        spConsultancyBill = new javax.swing.JScrollPane();
        tblConsultancyBill = new javax.swing.JTable();
        cbConsultancyPSearch = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1080, 768));
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kpnlUserFrontDash.setForeground(new java.awt.Color(255, 255, 255));
        kpnlUserFrontDash.setkBorderRadius(0);
        kpnlUserFrontDash.setkEndColor(new java.awt.Color(153, 153, 255));
        kpnlUserFrontDash.setkGradientFocus(1000);
        kpnlUserFrontDash.setkStartColor(new java.awt.Color(0, 0, 51));
        kpnlUserFrontDash.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblUserFrontLogout.setBackground(new java.awt.Color(255, 255, 255));
        lblUserFrontLogout.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblUserFrontLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblUserFrontLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/User/log-out.png"))); // NOI18N
        lblUserFrontLogout.setText("Log Out");
        lblUserFrontLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUserFrontLogoutMouseClicked(evt);
            }
        });
        kpnlUserFrontDash.add(lblUserFrontLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 560, 300, 50));

        lblUserFrontHns.setBackground(new java.awt.Color(255, 255, 255));
        lblUserFrontHns.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblUserFrontHns.setForeground(new java.awt.Color(255, 255, 255));
        lblUserFrontHns.setIcon(new javax.swing.ImageIcon(getClass().getResource("/User/help_icon.png"))); // NOI18N
        lblUserFrontHns.setText("Help and Support");
        lblUserFrontHns.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUserFrontHnsMouseClicked(evt);
            }
        });
        kpnlUserFrontDash.add(lblUserFrontHns, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 500, 300, 50));

        lblUserFrontSettings.setBackground(new java.awt.Color(255, 255, 255));
        lblUserFrontSettings.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblUserFrontSettings.setForeground(new java.awt.Color(255, 255, 255));
        lblUserFrontSettings.setIcon(new javax.swing.ImageIcon(getClass().getResource("/User/d88y06v-9bf586ed-3aa1-42b8-8ca5-343fc26843a2.png"))); // NOI18N
        lblUserFrontSettings.setText("Settings and Privacy");
        lblUserFrontSettings.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUserFrontSettingsMouseClicked(evt);
            }
        });
        kpnlUserFrontDash.add(lblUserFrontSettings, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 440, 300, 50));

        lblUserFrontIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/User/userlogo.png"))); // NOI18N
        kpnlUserFrontDash.add(lblUserFrontIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 50, 200, 200));

        lblUserFrontUname.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblUserFrontUname.setForeground(new java.awt.Color(255, 255, 255));
        lblUserFrontUname.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        kpnlUserFrontDash.add(lblUserFrontUname, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 240, 50));

        lblUserFrontDash.setFont(new java.awt.Font("Leelawadee UI", 1, 24)); // NOI18N
        lblUserFrontDash.setForeground(new java.awt.Color(255, 255, 255));
        lblUserFrontDash.setIcon(new javax.swing.ImageIcon(getClass().getResource("/User/dashboard-icon.png"))); // NOI18N
        lblUserFrontDash.setText("Dashboard");
        lblUserFrontDash.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUserFrontDashMouseClicked(evt);
            }
        });
        kpnlUserFrontDash.add(lblUserFrontDash, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 300, 50));

        markDash.setkBorderRadius(20);
        markDash.setkEndColor(new java.awt.Color(255, 255, 0));
        markDash.setkGradientFocus(30);
        markDash.setkStartColor(new java.awt.Color(255, 153, 0));
        markDash.setOpaque(false);

        javax.swing.GroupLayout markDashLayout = new javax.swing.GroupLayout(markDash);
        markDash.setLayout(markDashLayout);
        markDashLayout.setHorizontalGroup(
            markDashLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        markDashLayout.setVerticalGroup(
            markDashLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        kpnlUserFrontDash.add(markDash, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 380, 10, 50));

        markSettings.setkBorderRadius(20);
        markSettings.setkEndColor(new java.awt.Color(255, 255, 0));
        markSettings.setkGradientFocus(30);
        markSettings.setkStartColor(new java.awt.Color(255, 153, 0));
        markSettings.setOpaque(false);

        javax.swing.GroupLayout markSettingsLayout = new javax.swing.GroupLayout(markSettings);
        markSettings.setLayout(markSettingsLayout);
        markSettingsLayout.setHorizontalGroup(
            markSettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        markSettingsLayout.setVerticalGroup(
            markSettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        kpnlUserFrontDash.add(markSettings, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 440, 10, 50));

        markHelp.setkBorderRadius(20);
        markHelp.setkEndColor(new java.awt.Color(255, 255, 0));
        markHelp.setkGradientFocus(30);
        markHelp.setkStartColor(new java.awt.Color(255, 153, 0));
        markHelp.setOpaque(false);

        javax.swing.GroupLayout markHelpLayout = new javax.swing.GroupLayout(markHelp);
        markHelp.setLayout(markHelpLayout);
        markHelpLayout.setHorizontalGroup(
            markHelpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        markHelpLayout.setVerticalGroup(
            markHelpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        kpnlUserFrontDash.add(markHelp, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 500, 10, 50));

        getContentPane().add(kpnlUserFrontDash, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 310, 768));

        pnlUserFrontContainer.setBackground(new java.awt.Color(255, 255, 255));
        pnlUserFrontContainer.setLayout(new java.awt.CardLayout());

        pnlUserDashCard.setBackground(new java.awt.Color(255, 255, 255));
        pnlUserDashCard.setToolTipText("");
        pnlUserDashCard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnUserFrontViewBills.setBackground(new java.awt.Color(255, 255, 255));
        btnUserFrontViewBills.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnUserFrontViewBills.setIcon(new javax.swing.ImageIcon(getClass().getResource("/User/bill_icon_250px.jpg"))); // NOI18N
        btnUserFrontViewBills.setText("View Bills");
        btnUserFrontViewBills.setBorder(null);
        btnUserFrontViewBills.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnUserFrontViewBills.setOpaque(false);
        btnUserFrontViewBills.setPreferredSize(new java.awt.Dimension(250, 250));
        btnUserFrontViewBills.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        btnUserFrontViewBills.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnUserFrontViewBills.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserFrontViewBillsActionPerformed(evt);
            }
        });
        pnlUserDashCard.add(btnUserFrontViewBills, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, 290, 290));

        btnUserFrontAppointment.setBackground(new java.awt.Color(255, 255, 255));
        btnUserFrontAppointment.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnUserFrontAppointment.setIcon(new javax.swing.ImageIcon(getClass().getResource("/User/Appointment icon 250px.png"))); // NOI18N
        btnUserFrontAppointment.setText("Book Appointment");
        btnUserFrontAppointment.setBorder(null);
        btnUserFrontAppointment.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnUserFrontAppointment.setOpaque(false);
        btnUserFrontAppointment.setPreferredSize(new java.awt.Dimension(250, 250));
        btnUserFrontAppointment.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        btnUserFrontAppointment.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnUserFrontAppointment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserFrontAppointmentActionPerformed(evt);
            }
        });
        pnlUserDashCard.add(btnUserFrontAppointment, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 30, 290, 290));

        btnUserFrontManageID.setBackground(new java.awt.Color(255, 255, 255));
        btnUserFrontManageID.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnUserFrontManageID.setIcon(new javax.swing.ImageIcon(getClass().getResource("/User/Manage Id Icon 250px.png"))); // NOI18N
        btnUserFrontManageID.setText("Manage ID");
        btnUserFrontManageID.setBorder(null);
        btnUserFrontManageID.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnUserFrontManageID.setOpaque(false);
        btnUserFrontManageID.setPreferredSize(new java.awt.Dimension(250, 250));
        btnUserFrontManageID.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        btnUserFrontManageID.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnUserFrontManageID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserFrontManageIDActionPerformed(evt);
            }
        });
        pnlUserDashCard.add(btnUserFrontManageID, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 410, 290, 290));

        pnlUserFrontContainer.add(pnlUserDashCard, "DashCard");

        pnlUserManageIdCard.setBackground(new java.awt.Color(255, 255, 255));
        pnlUserManageIdCard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel1.setkBorderRadius(0);
        kGradientPanel1.setkEndColor(new java.awt.Color(153, 153, 255));
        kGradientPanel1.setkGradientFocus(1000);
        kGradientPanel1.setkStartColor(new java.awt.Color(0, 0, 51));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblUserManageIDback.setIcon(new javax.swing.ImageIcon(getClass().getResource("/User/uturn_icon_50.png"))); // NOI18N
        lblUserManageIDback.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUserManageIDbackMouseClicked(evt);
            }
        });
        kGradientPanel1.add(lblUserManageIDback, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 5, -1, -1));

        btnUserManageIDGeneratingID.setText("Add ID");
        btnUserManageIDGeneratingID.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnUserManageIDGeneratingID.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnUserManageIDGeneratingID.setkBorderRadius(15);
        btnUserManageIDGeneratingID.setkEndColor(new java.awt.Color(102, 255, 102));
        btnUserManageIDGeneratingID.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnUserManageIDGeneratingID.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnUserManageIDGeneratingID.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnUserManageIDGeneratingID.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnUserManageIDGeneratingID.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnUserManageIDGeneratingID.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnUserManageIDGeneratingID.setkStartColor(new java.awt.Color(0, 153, 0));
        btnUserManageIDGeneratingID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserManageIDGeneratingIDActionPerformed(evt);
            }
        });
        kGradientPanel1.add(btnUserManageIDGeneratingID, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 5, -1, 50));

        btnUserManageIDChngingExistingID.setText("Existing ID");
        btnUserManageIDChngingExistingID.setDoubleBuffered(true);
        btnUserManageIDChngingExistingID.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnUserManageIDChngingExistingID.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnUserManageIDChngingExistingID.setkBorderRadius(15);
        btnUserManageIDChngingExistingID.setkEndColor(new java.awt.Color(102, 255, 102));
        btnUserManageIDChngingExistingID.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnUserManageIDChngingExistingID.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnUserManageIDChngingExistingID.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnUserManageIDChngingExistingID.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnUserManageIDChngingExistingID.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnUserManageIDChngingExistingID.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnUserManageIDChngingExistingID.setkStartColor(new java.awt.Color(0, 153, 0));
        btnUserManageIDChngingExistingID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserManageIDChngingExistingIDActionPerformed(evt);
            }
        });
        kGradientPanel1.add(btnUserManageIDChngingExistingID, new org.netbeans.lib.awtextra.AbsoluteConstraints(313, 5, -1, 50));

        markAddID.setkBorderRadius(20);
        markAddID.setkEndColor(new java.awt.Color(255, 255, 0));
        markAddID.setkGradientFocus(120);
        markAddID.setkStartColor(new java.awt.Color(255, 153, 0));
        markAddID.setOpaque(false);

        javax.swing.GroupLayout markAddIDLayout = new javax.swing.GroupLayout(markAddID);
        markAddID.setLayout(markAddIDLayout);
        markAddIDLayout.setHorizontalGroup(
            markAddIDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markAddIDLayout.setVerticalGroup(
            markAddIDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel1.add(markAddID, new org.netbeans.lib.awtextra.AbsoluteConstraints(41, 50, 180, 10));

        markExistingID.setkBorderRadius(20);
        markExistingID.setkEndColor(new java.awt.Color(255, 255, 0));
        markExistingID.setkGradientFocus(120);
        markExistingID.setkStartColor(new java.awt.Color(255, 153, 0));
        markExistingID.setOpaque(false);

        javax.swing.GroupLayout markExistingIDLayout = new javax.swing.GroupLayout(markExistingID);
        markExistingID.setLayout(markExistingIDLayout);
        markExistingIDLayout.setHorizontalGroup(
            markExistingIDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markExistingIDLayout.setVerticalGroup(
            markExistingIDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel1.add(markExistingID, new org.netbeans.lib.awtextra.AbsoluteConstraints(316, 50, 180, 10));

        pnlUserManageIdCard.add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 60));

        pnlUserManageIDContainer.setLayout(new java.awt.CardLayout());

        pnlUsermanageIDAddNew.setBackground(new java.awt.Color(255, 255, 255));
        pnlUsermanageIDAddNew.setMaximumSize(new java.awt.Dimension(770, 708));
        pnlUsermanageIDAddNew.setPreferredSize(new java.awt.Dimension(770, 708));
        pnlUsermanageIDAddNew.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblUsermanageIDAddNewNameTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblUsermanageIDAddNewNameTag.setText("Patient Name");
        pnlUsermanageIDAddNew.add(lblUsermanageIDAddNewNameTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 78, 166, 30));

        lblUsermanageIDAddNewKinTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblUsermanageIDAddNewKinTag.setText("S/o-D/o-W/o");
        pnlUsermanageIDAddNew.add(lblUsermanageIDAddNewKinTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(399, 78, -1, 30));

        UsermanageIDAddNewKin.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        UsermanageIDAddNewKin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UsermanageIDAddNewKinActionPerformed(evt);
            }
        });
        pnlUsermanageIDAddNew.add(UsermanageIDAddNewKin, new org.netbeans.lib.awtextra.AbsoluteConstraints(545, 78, 200, 30));

        cbUsermanageIDAddNewGender.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbUsermanageIDAddNewGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Gender", "Male", "Female", "Other" }));
        pnlUsermanageIDAddNew.add(cbUsermanageIDAddNewGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 152, 227, -1));

        lblUsermanageIDAddNewGenderTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblUsermanageIDAddNewGenderTag.setText("Gender");
        pnlUsermanageIDAddNew.add(lblUsermanageIDAddNewGenderTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(66, 152, -1, 36));

        lblUsermanageIDAddNewDobTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblUsermanageIDAddNewDobTag.setText("DOB");
        pnlUsermanageIDAddNew.add(lblUsermanageIDAddNewDobTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 150, -1, 36));

        lblUsermanageIDAddNewContactTag.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        lblUsermanageIDAddNewContactTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblUsermanageIDAddNewContactTag.setText("Contact");
        pnlUsermanageIDAddNew.add(lblUsermanageIDAddNewContactTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 238, 93, 35));

        txtUsermanageIDAddNewContact.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtUsermanageIDAddNewContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsermanageIDAddNewContactActionPerformed(evt);
            }
        });
        pnlUsermanageIDAddNew.add(txtUsermanageIDAddNewContact, new org.netbeans.lib.awtextra.AbsoluteConstraints(169, 238, 202, 30));

        lblUsermanageIDAddNewBloodGrpTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblUsermanageIDAddNewBloodGrpTag.setText("Blood Group");
        pnlUsermanageIDAddNew.add(lblUsermanageIDAddNewBloodGrpTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(375, 238, -1, -1));

        cbUsermanageIDAddNewBloodGrp.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        cbUsermanageIDAddNewBloodGrp.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Blood Group", "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-" }));
        pnlUsermanageIDAddNew.add(cbUsermanageIDAddNewBloodGrp, new org.netbeans.lib.awtextra.AbsoluteConstraints(533, 243, 212, -1));

        lblUsermanageIDAddNewStreetTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblUsermanageIDAddNewStreetTag.setText("Street");
        lblUsermanageIDAddNewStreetTag.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        pnlUsermanageIDAddNew.add(lblUsermanageIDAddNewStreetTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(46, 323, -1, 30));

        txtUsermanageIDAddNewStreet.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtUsermanageIDAddNewStreet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsermanageIDAddNewStreetActionPerformed(evt);
            }
        });
        pnlUsermanageIDAddNew.add(txtUsermanageIDAddNewStreet, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 323, 620, 30));

        lblUsermanageIDAddNewStateTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblUsermanageIDAddNewStateTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblUsermanageIDAddNewStateTag.setText("Email Id");
        lblUsermanageIDAddNewStateTag.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        pnlUsermanageIDAddNew.add(lblUsermanageIDAddNewStateTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 394, 128, 30));

        cbUsermanageIDAddNewState.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbUsermanageIDAddNewState.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbUsermanageIDAddNewStateItemStateChanged(evt);
            }
        });
        pnlUsermanageIDAddNew.add(cbUsermanageIDAddNewState, new org.netbeans.lib.awtextra.AbsoluteConstraints(173, 451, 232, 30));

        cbUsermanageIDAddNewCity.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        pnlUsermanageIDAddNew.add(cbUsermanageIDAddNewCity, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 450, 200, 30));

        lblUsermanageIDAddNewCityTag.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblUsermanageIDAddNewCityTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblUsermanageIDAddNewCityTag.setText("City");
        lblUsermanageIDAddNewCityTag.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        pnlUsermanageIDAddNew.add(lblUsermanageIDAddNewCityTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 450, 100, 30));

        btnUsermanageIDAddNewAdd.setText("Add Data");
        btnUsermanageIDAddNewAdd.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnUsermanageIDAddNewAdd.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnUsermanageIDAddNewAdd.setkBorderRadius(15);
        btnUsermanageIDAddNewAdd.setkEndColor(new java.awt.Color(102, 255, 102));
        btnUsermanageIDAddNewAdd.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnUsermanageIDAddNewAdd.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnUsermanageIDAddNewAdd.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnUsermanageIDAddNewAdd.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnUsermanageIDAddNewAdd.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnUsermanageIDAddNewAdd.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnUsermanageIDAddNewAdd.setkStartColor(new java.awt.Color(0, 153, 0));
        btnUsermanageIDAddNewAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUsermanageIDAddNewAddActionPerformed(evt);
            }
        });
        pnlUsermanageIDAddNew.add(btnUsermanageIDAddNewAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(283, 538, -1, 50));

        lblPDAddMandatory.setBackground(new java.awt.Color(255, 255, 255));
        lblPDAddMandatory.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblPDAddMandatory.setForeground(new java.awt.Color(255, 0, 0));
        lblPDAddMandatory.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPDAddMandatory.setText("**All fields are mandatory**");
        pnlUsermanageIDAddNew.add(lblPDAddMandatory, new org.netbeans.lib.awtextra.AbsoluteConstraints(266, 606, 219, -1));

        cbPDAddContact.setEditable(true);
        cbPDAddContact.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        cbPDAddContact.setForeground(new java.awt.Color(255, 255, 255));
        cbPDAddContact.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "+91", "+43", "+32", "+359", "+385", "+357", "+420", "+33", "+49", "+39", "+47", "+34", "+44" }));
        cbPDAddContact.setBorder(null);
        cbPDAddContact.setDoubleBuffered(true);
        cbPDAddContact.setOpaque(false);
        cbPDAddContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPDAddContactActionPerformed(evt);
            }
        });
        pnlUsermanageIDAddNew.add(cbPDAddContact, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 239, 60, 30));

        dateUsermanageIDAddNewDOB.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        pnlUsermanageIDAddNew.add(dateUsermanageIDAddNewDOB, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 150, 200, 36));

        txtUsermanageIDAddNewName.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtUsermanageIDAddNewName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtUsermanageIDAddNewName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsermanageIDAddNewNameActionPerformed(evt);
            }
        });
        pnlUsermanageIDAddNew.add(txtUsermanageIDAddNewName, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 78, 219, 30));

        lblUsermanageIDAddNewStateTag1.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblUsermanageIDAddNewStateTag1.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblUsermanageIDAddNewStateTag1.setText("State");
        lblUsermanageIDAddNewStateTag1.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        pnlUsermanageIDAddNew.add(lblUsermanageIDAddNewStateTag1, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 451, 128, 30));

        txtUsermanageIDAddEmail.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtUsermanageIDAddEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsermanageIDAddEmailActionPerformed(evt);
            }
        });
        pnlUsermanageIDAddNew.add(txtUsermanageIDAddEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(169, 394, 368, 30));

        lblPDAddInvalidDate.setBackground(new java.awt.Color(255, 255, 255));
        lblPDAddInvalidDate.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblPDAddInvalidDate.setForeground(new java.awt.Color(255, 0, 0));
        lblPDAddInvalidDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPDAddInvalidDate.setText("**Invalid Date of Birth **");
        pnlUsermanageIDAddNew.add(lblPDAddInvalidDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(266, 637, 219, -1));

        pnlUserManageIDContainer.add(pnlUsermanageIDAddNew, "ManageIDAddCard");

        pnlUsermanageIDExisting.setBackground(new java.awt.Color(255, 255, 255));
        pnlUsermanageIDExisting.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N

        lblUsermanageIDExistingSelID.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblUsermanageIDExistingSelID.setText("Existing Patient ID");

        btnUsermanageIDExistingDltID.setText("Delete");
        btnUsermanageIDExistingDltID.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnUsermanageIDExistingDltID.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnUsermanageIDExistingDltID.setkBorderRadius(15);
        btnUsermanageIDExistingDltID.setkEndColor(new java.awt.Color(102, 255, 102));
        btnUsermanageIDExistingDltID.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnUsermanageIDExistingDltID.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnUsermanageIDExistingDltID.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnUsermanageIDExistingDltID.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnUsermanageIDExistingDltID.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnUsermanageIDExistingDltID.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnUsermanageIDExistingDltID.setkStartColor(new java.awt.Color(0, 153, 0));
        btnUsermanageIDExistingDltID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUsermanageIDExistingDltIDActionPerformed(evt);
            }
        });

        txtUsermanageIDExistingIDEnter.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtUsermanageIDExistingIDEnter.setForeground(new java.awt.Color(51, 51, 51));
        txtUsermanageIDExistingIDEnter.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtUsermanageIDExistingIDEnter.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtUsermanageIDExistingIDEnter.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtUsermanageIDExistingIDEnterMouseClicked(evt);
            }
        });

        btnUsermanageIDExistingLinkID.setText("Link");
        btnUsermanageIDExistingLinkID.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnUsermanageIDExistingLinkID.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnUsermanageIDExistingLinkID.setkBorderRadius(15);
        btnUsermanageIDExistingLinkID.setkEndColor(new java.awt.Color(102, 255, 102));
        btnUsermanageIDExistingLinkID.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnUsermanageIDExistingLinkID.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnUsermanageIDExistingLinkID.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnUsermanageIDExistingLinkID.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnUsermanageIDExistingLinkID.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnUsermanageIDExistingLinkID.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnUsermanageIDExistingLinkID.setkStartColor(new java.awt.Color(0, 153, 0));
        btnUsermanageIDExistingLinkID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUsermanageIDExistingLinkIDActionPerformed(evt);
            }
        });

        lblUsermanageIDExistingSelID1.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblUsermanageIDExistingSelID1.setText("Select ID");

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));

        lblManageExistingIDWarning.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblManageExistingIDWarning.setForeground(new java.awt.Color(255, 0, 0));
        lblManageExistingIDWarning.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblManageExistingIDWarning.setText("**Field can't be blank**");

        javax.swing.GroupLayout pnlUsermanageIDExistingLayout = new javax.swing.GroupLayout(pnlUsermanageIDExisting);
        pnlUsermanageIDExisting.setLayout(pnlUsermanageIDExistingLayout);
        pnlUsermanageIDExistingLayout.setHorizontalGroup(
            pnlUsermanageIDExistingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUsermanageIDExistingLayout.createSequentialGroup()
                .addGap(0, 82, Short.MAX_VALUE)
                .addGroup(pnlUsermanageIDExistingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUsermanageIDExistingLayout.createSequentialGroup()
                        .addComponent(lblUsermanageIDExistingSelID1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(72, 72, 72)
                        .addComponent(cbUsermanageIDExistingIDSel, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(198, 198, 198))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUsermanageIDExistingLayout.createSequentialGroup()
                        .addComponent(lblUsermanageIDExistingSelID, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)
                        .addComponent(txtUsermanageIDExistingIDEnter, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(189, 189, 189))))
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(pnlUsermanageIDExistingLayout.createSequentialGroup()
                .addGroup(pnlUsermanageIDExistingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlUsermanageIDExistingLayout.createSequentialGroup()
                        .addGap(268, 268, 268)
                        .addComponent(btnUsermanageIDExistingDltID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlUsermanageIDExistingLayout.createSequentialGroup()
                        .addGap(287, 287, 287)
                        .addGroup(pnlUsermanageIDExistingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnUsermanageIDExistingLinkID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblManageExistingIDWarning, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlUsermanageIDExistingLayout.setVerticalGroup(
            pnlUsermanageIDExistingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUsermanageIDExistingLayout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(pnlUsermanageIDExistingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cbUsermanageIDExistingIDSel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblUsermanageIDExistingSelID1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(80, 80, 80)
                .addComponent(btnUsermanageIDExistingDltID, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 120, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addGroup(pnlUsermanageIDExistingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtUsermanageIDExistingIDEnter, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblUsermanageIDExistingSelID, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(100, 100, 100)
                .addComponent(btnUsermanageIDExistingLinkID, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(lblManageExistingIDWarning)
                .addGap(63, 63, 63))
        );

        pnlUserManageIDContainer.add(pnlUsermanageIDExisting, "ManageIDExistingCard");

        pnlUserManageIdCard.add(pnlUserManageIDContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 770, 710));

        pnlUserFrontContainer.add(pnlUserManageIdCard, "ManageIDCard");

        pnlUserAppointments.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel2.setkBorderRadius(0);
        kGradientPanel2.setkEndColor(new java.awt.Color(153, 153, 255));
        kGradientPanel2.setkGradientFocus(1000);
        kGradientPanel2.setkStartColor(new java.awt.Color(0, 0, 51));
        kGradientPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblUserAppointmentback.setIcon(new javax.swing.ImageIcon(getClass().getResource("/User/uturn_icon_50.png"))); // NOI18N
        lblUserAppointmentback.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUserAppointmentbackMouseClicked(evt);
            }
        });
        kGradientPanel2.add(lblUserAppointmentback, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 5, -1, -1));

        btnUserAppointmentBook.setText("Book Appointment");
        btnUserAppointmentBook.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnUserAppointmentBook.setkAllowTab(true);
        btnUserAppointmentBook.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnUserAppointmentBook.setkBorderRadius(15);
        btnUserAppointmentBook.setkEndColor(new java.awt.Color(102, 255, 102));
        btnUserAppointmentBook.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnUserAppointmentBook.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnUserAppointmentBook.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnUserAppointmentBook.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnUserAppointmentBook.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnUserAppointmentBook.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnUserAppointmentBook.setkStartColor(new java.awt.Color(0, 153, 0));
        btnUserAppointmentBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserAppointmentBookActionPerformed(evt);
            }
        });
        kGradientPanel2.add(btnUserAppointmentBook, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 5, 238, 50));

        btnUserAppointmentCancel.setText("Cancel Appointment");
        btnUserAppointmentCancel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnUserAppointmentCancel.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnUserAppointmentCancel.setkBorderRadius(15);
        btnUserAppointmentCancel.setkEndColor(new java.awt.Color(102, 255, 102));
        btnUserAppointmentCancel.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnUserAppointmentCancel.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnUserAppointmentCancel.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnUserAppointmentCancel.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnUserAppointmentCancel.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnUserAppointmentCancel.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnUserAppointmentCancel.setkStartColor(new java.awt.Color(0, 153, 0));
        btnUserAppointmentCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserAppointmentCancelActionPerformed(evt);
            }
        });
        kGradientPanel2.add(btnUserAppointmentCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(313, 5, 259, 50));

        markBAppointment.setkBorderRadius(20);
        markBAppointment.setkEndColor(new java.awt.Color(255, 255, 0));
        markBAppointment.setkGradientFocus(120);
        markBAppointment.setkStartColor(new java.awt.Color(255, 153, 0));
        markBAppointment.setOpaque(false);

        javax.swing.GroupLayout markBAppointmentLayout = new javax.swing.GroupLayout(markBAppointment);
        markBAppointment.setLayout(markBAppointmentLayout);
        markBAppointmentLayout.setHorizontalGroup(
            markBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 231, Short.MAX_VALUE)
        );
        markBAppointmentLayout.setVerticalGroup(
            markBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel2.add(markBAppointment, new org.netbeans.lib.awtextra.AbsoluteConstraints(43, 50, 231, 10));

        markCAppointment.setkBorderRadius(20);
        markCAppointment.setkEndColor(new java.awt.Color(255, 255, 0));
        markCAppointment.setkGradientFocus(120);
        markCAppointment.setkStartColor(new java.awt.Color(255, 153, 0));
        markCAppointment.setOpaque(false);

        javax.swing.GroupLayout markCAppointmentLayout = new javax.swing.GroupLayout(markCAppointment);
        markCAppointment.setLayout(markCAppointmentLayout);
        markCAppointmentLayout.setHorizontalGroup(
            markCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 250, Short.MAX_VALUE)
        );
        markCAppointmentLayout.setVerticalGroup(
            markCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel2.add(markCAppointment, new org.netbeans.lib.awtextra.AbsoluteConstraints(319, 50, 250, 10));

        pnlUserAppointments.add(kGradientPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 60));

        pnlUserAppointmentContainer.setLayout(new java.awt.CardLayout());

        pnlBAppointment.setBackground(new java.awt.Color(255, 255, 255));

        lblPatientID.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPatientID.setText("Patient ID");

        lblPhnNum.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPhnNum.setText("Phone Number: ");
        lblPhnNum.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentMoved(java.awt.event.ComponentEvent evt) {
                lblPhnNumComponentMoved(evt);
            }
        });

        txtPhnNum.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        txtPhnNum.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtPhnNum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPhnNumActionPerformed(evt);
            }
        });

        lblDepartment.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblDepartment.setText("Department");

        cbDepartment.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbDepartment.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbDepartmentItemStateChanged(evt);
            }
        });

        lblDocName.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblDocName.setText("Docter Name: ");

        cbDocName.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbDocName.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Doctor" }));
        cbDocName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbDocNameActionPerformed(evt);
            }
        });

        lblADate.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblADate.setText("Date of Appointment");

        lblATime.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblATime.setText("Time of Appointment");

        cbATime.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbATime.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Time", "10:00AM - 11:00AM", "12:00PM - 01:00PM", "04:00PM - 05:00PM", "07:00PM - 08:00PM" }));
        cbATime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbATimeActionPerformed(evt);
            }
        });

        btnBAppointmentSubmit.setText("Submit");
        btnBAppointmentSubmit.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBAppointmentSubmit.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBAppointmentSubmit.setkBorderRadius(15);
        btnBAppointmentSubmit.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBAppointmentSubmit.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBAppointmentSubmit.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBAppointmentSubmit.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBAppointmentSubmit.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBAppointmentSubmit.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBAppointmentSubmit.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBAppointmentSubmit.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBAppointmentSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBAppointmentSubmitActionPerformed(evt);
            }
        });

        jcalADate.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N

        cbPatientId.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbPatientId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPatientIdActionPerformed(evt);
            }
        });

        cbPhnNum.setEditable(true);
        cbPhnNum.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        cbPhnNum.setForeground(new java.awt.Color(255, 255, 255));
        cbPhnNum.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "+91", "+43", "+32", "+359", "+385", "+357", "+420", "+33", "+49", "+39", "+47", "+34", "+44" }));
        cbPhnNum.setBorder(null);
        cbPhnNum.setDoubleBuffered(true);
        cbPhnNum.setOpaque(false);
        cbPhnNum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPhnNumActionPerformed(evt);
            }
        });

        lblBAppointmentMandatory1.setBackground(new java.awt.Color(255, 255, 255));
        lblBAppointmentMandatory1.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblBAppointmentMandatory1.setForeground(new java.awt.Color(255, 0, 0));
        lblBAppointmentMandatory1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBAppointmentMandatory1.setText("**All fields are mandatory**");

        btnBAppointmentReset.setText("Reset");
        btnBAppointmentReset.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnBAppointmentReset.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnBAppointmentReset.setkBorderRadius(15);
        btnBAppointmentReset.setkEndColor(new java.awt.Color(102, 255, 102));
        btnBAppointmentReset.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnBAppointmentReset.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnBAppointmentReset.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnBAppointmentReset.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnBAppointmentReset.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnBAppointmentReset.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnBAppointmentReset.setkStartColor(new java.awt.Color(0, 153, 0));
        btnBAppointmentReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBAppointmentResetActionPerformed(evt);
            }
        });

        lblBAppointmentInvalidDate.setBackground(new java.awt.Color(255, 255, 255));
        lblBAppointmentInvalidDate.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblBAppointmentInvalidDate.setForeground(new java.awt.Color(255, 0, 0));
        lblBAppointmentInvalidDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBAppointmentInvalidDate.setText("**Invalid Date of Appointment**");

        javax.swing.GroupLayout pnlBAppointmentLayout = new javax.swing.GroupLayout(pnlBAppointment);
        pnlBAppointment.setLayout(pnlBAppointmentLayout);
        pnlBAppointmentLayout.setHorizontalGroup(
            pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addComponent(lblATime)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                        .addComponent(cbATime, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(125, 125, 125))
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                                .addComponent(lblDocName)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cbDocName, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                                        .addComponent(lblPhnNum)
                                        .addGap(18, 18, 18)
                                        .addComponent(cbPhnNum, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lblPatientID))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtPhnNum)
                                    .addComponent(cbPatientId, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                                .addComponent(lblDepartment)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cbDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(78, 78, 78))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlBAppointmentLayout.createSequentialGroup()
                .addContainerGap(267, Short.MAX_VALUE)
                .addComponent(jcalADate, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(261, 261, 261))
            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addGap(275, 275, 275)
                        .addComponent(lblADate))
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addGap(268, 268, 268)
                        .addComponent(lblBAppointmentMandatory1, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addGap(145, 145, 145)
                        .addComponent(btnBAppointmentSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(95, 95, 95)
                        .addComponent(btnBAppointmentReset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addGap(247, 247, 247)
                        .addComponent(lblBAppointmentInvalidDate, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlBAppointmentLayout.setVerticalGroup(
            pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlBAppointmentLayout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addComponent(lblPatientID)
                        .addGap(20, 20, 20))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlBAppointmentLayout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(cbPatientId, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtPhnNum, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cbPhnNum, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblPhnNum))
                .addGap(26, 26, 26)
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cbDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDepartment))
                .addGap(27, 27, 27)
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cbDocName, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDocName))
                .addGap(18, 18, 18)
                .addComponent(lblADate)
                .addGap(18, 18, 18)
                .addComponent(jcalADate, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblATime)
                    .addComponent(cbATime, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(pnlBAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBAppointmentSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBAppointmentReset, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(66, 66, 66)
                .addComponent(lblBAppointmentMandatory1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblBAppointmentInvalidDate)
                .addGap(21, 21, 21))
        );

        pnlUserAppointmentContainer.add(pnlBAppointment, "BookAppointmentCard");

        pnlCAppointment.setBackground(new java.awt.Color(255, 255, 255));
        pnlCAppointment.setFocusCycleRoot(true);
        pnlCAppointment.setPreferredSize(new java.awt.Dimension(770, 710));

        lblPatientID1.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblPatientID1.setText("Patient ID");

        cbPatientId1.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbPatientId1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPatientId1ActionPerformed(evt);
            }
        });

        lblDocName1.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblDocName1.setText("Docter Name: ");

        cbDocName1.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbDocName1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Doctor" }));
        cbDocName1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbDocName1ActionPerformed(evt);
            }
        });

        lblADate1.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblADate1.setText("Date of Appointment");

        jcalADate1.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N

        lblATime1.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblATime1.setText("Time of Appointment");

        cbATime1.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbATime1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Time", "10:00AM - 11:00AM", "12:00PM - 01:00PM", "04:00PM - 05:00PM", "07:00PM - 08:00PM" }));
        cbATime1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbATime1ActionPerformed(evt);
            }
        });

        lblCAppointmentMandatory.setBackground(new java.awt.Color(255, 255, 255));
        lblCAppointmentMandatory.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblCAppointmentMandatory.setForeground(new java.awt.Color(255, 0, 0));
        lblCAppointmentMandatory.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCAppointmentMandatory.setText("**All fields are mandatory**");

        btnCAppointmentCannel.setText("Delete");
        btnCAppointmentCannel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnCAppointmentCannel.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnCAppointmentCannel.setkBorderRadius(15);
        btnCAppointmentCannel.setkEndColor(new java.awt.Color(102, 255, 102));
        btnCAppointmentCannel.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnCAppointmentCannel.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnCAppointmentCannel.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnCAppointmentCannel.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnCAppointmentCannel.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnCAppointmentCannel.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnCAppointmentCannel.setkStartColor(new java.awt.Color(0, 153, 0));
        btnCAppointmentCannel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCAppointmentCannelActionPerformed(evt);
            }
        });

        lblDepartment1.setFont(new java.awt.Font("Candara", 1, 28)); // NOI18N
        lblDepartment1.setText("Department");

        cbDepartment1.setFont(new java.awt.Font("Candara", 0, 24)); // NOI18N
        cbDepartment1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbDepartment1ItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout pnlCAppointmentLayout = new javax.swing.GroupLayout(pnlCAppointment);
        pnlCAppointment.setLayout(pnlCAppointmentLayout);
        pnlCAppointmentLayout.setHorizontalGroup(
            pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCAppointmentLayout.createSequentialGroup()
                .addGroup(pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCAppointmentLayout.createSequentialGroup()
                        .addGap(277, 277, 277)
                        .addComponent(btnCAppointmentCannel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlCAppointmentLayout.createSequentialGroup()
                        .addGap(258, 258, 258)
                        .addComponent(lblCAppointmentMandatory, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(pnlCAppointmentLayout.createSequentialGroup()
                .addGap(126, 126, 126)
                .addGroup(pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPatientID1)
                    .addComponent(lblDocName1)
                    .addComponent(lblADate1)
                    .addComponent(lblATime1)
                    .addComponent(lblDepartment1))
                .addGap(22, 22, 22)
                .addGroup(pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCAppointmentLayout.createSequentialGroup()
                        .addGroup(pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cbDocName1, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(cbPatientId1, 0, 285, Short.MAX_VALUE)
                                .addComponent(cbDepartment1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(0, 77, Short.MAX_VALUE))
                    .addGroup(pnlCAppointmentLayout.createSequentialGroup()
                        .addGroup(pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jcalADate1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbATime1, 0, 285, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        pnlCAppointmentLayout.setVerticalGroup(
            pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCAppointmentLayout.createSequentialGroup()
                .addGap(147, 147, 147)
                .addGroup(pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbPatientId1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPatientID1))
                .addGap(32, 32, 32)
                .addGroup(pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDepartment1)
                    .addComponent(cbDepartment1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblDocName1)
                    .addComponent(cbDocName1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblADate1)
                    .addComponent(jcalADate1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(pnlCAppointmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblATime1)
                    .addComponent(cbATime1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addComponent(lblCAppointmentMandatory)
                .addGap(39, 39, 39)
                .addComponent(btnCAppointmentCannel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(98, Short.MAX_VALUE))
        );

        pnlUserAppointmentContainer.add(pnlCAppointment, "CancelAppointmentCard");

        pnlApointmentReciept.setBackground(new java.awt.Color(255, 255, 255));
        pnlApointmentReciept.setBorder(new javax.swing.border.MatteBorder(null));

        lblAppointmentRecieptBillNoTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblAppointmentRecieptBillNoTag.setText("Bill No.    :");

        lblAppointmentRecieptLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/logo.png"))); // NOI18N

        lblAppointmentRecieptBillNo.setBackground(new java.awt.Color(51, 0, 51));
        lblAppointmentRecieptBillNo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblAppointmentRecieptNameTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblAppointmentRecieptNameTag.setText("Name      :");

        lblAppointmentRecieptName.setBackground(new java.awt.Color(51, 0, 51));
        lblAppointmentRecieptName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblAppointmentRecieptKin.setBackground(new java.awt.Color(51, 0, 51));
        lblAppointmentRecieptKin.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblAppointmentRecieptKinTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblAppointmentRecieptKinTag.setText("Kin          :");

        lblAppointmentRecieptAgeTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblAppointmentRecieptAgeTag.setText("Age         :");

        lblAppointmentRecieptAge.setBackground(new java.awt.Color(51, 0, 51));
        lblAppointmentRecieptAge.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblAppointmentRecieptDateTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblAppointmentRecieptDateTag.setText("Date        :");

        lblAppointmentRecieptSex.setBackground(new java.awt.Color(51, 0, 51));
        lblAppointmentRecieptSex.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblAppointmentRecieptSexTag.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblAppointmentRecieptSexTag.setText("Sex         :");

        lblAppointmentRecieptDate.setBackground(new java.awt.Color(51, 0, 51));
        lblAppointmentRecieptDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));

        lblAppointmentRecieptDocName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        lblAppointmentRecieptConChrg.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        lblAppointmentRecieptSTax.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        lblAppointmentRecieptCTax.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        lblAppointmentRecieptAmountPaid.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        lblAppointmentRecieptSTaxTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblAppointmentRecieptSTaxTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblAppointmentRecieptSTaxTag.setText("State GST 9%");

        lblAppointmentRecieptCTaxTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblAppointmentRecieptCTaxTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblAppointmentRecieptCTaxTag.setText("Central GST 9%");

        lblAppointmentRecieptAmountPaidTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblAppointmentRecieptAmountPaidTag.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblAppointmentRecieptAmountPaidTag.setText("Total Amount Paid");

        lblAppointmentRecieptRecepTag.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblAppointmentRecieptRecepTag.setText("Receptionist");

        lblAppointmentRecieptConChrgTag.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblAppointmentRecieptConChrgTag.setText("Consultation Charges");

        lblAppointmentRecieptDocSpec.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblAppointmentRecieptDocSpec.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);

        lblAppointmentRecieptAppointmentDate.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        jLabel1.setFont(new java.awt.Font("MS PGothic", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("(A unit of UPSN Medical & Research Centre Pvt. Ltd.)");

        jLabel2.setFont(new java.awt.Font("MS UI Gothic", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 102));
        jLabel2.setText("UPSN HOSPITALS");

        jLabel3.setFont(new java.awt.Font("MS PGothic", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 102));
        jLabel3.setText("Sector - 10, Near Mahindra SEZ, Ajmer Road, Mahapura, Rajasthan 302026");

        jLabel5.setFont(new java.awt.Font("MS PGothic", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("Tel. : 1234567 * Fax : 0011-1234567 * Email : support@upsnhospitals.in");

        jLabel6.setFont(new java.awt.Font("MS PGothic", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("CIN No. X00000YZ1111JKL333333");

        javax.swing.GroupLayout pnlApointmentRecieptLayout = new javax.swing.GroupLayout(pnlApointmentReciept);
        pnlApointmentReciept.setLayout(pnlApointmentRecieptLayout);
        pnlApointmentRecieptLayout.setHorizontalGroup(
            pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator2)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlApointmentRecieptLayout.createSequentialGroup()
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblAppointmentRecieptRecepTag, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                                .addComponent(lblAppointmentRecieptConChrgTag, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblAppointmentRecieptDocName, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblAppointmentRecieptDocSpec, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblAppointmentRecieptAppointmentDate))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 109, Short.MAX_VALUE)
                                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblAppointmentRecieptSTaxTag, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblAppointmentRecieptAmountPaidTag, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblAppointmentRecieptCTaxTag, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addGap(18, 18, 18)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblAppointmentRecieptSTax, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
                            .addComponent(lblAppointmentRecieptConChrg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblAppointmentRecieptCTax, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblAppointmentRecieptAmountPaid, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(61, 61, 61))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlApointmentRecieptLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptBillNoTag)
                        .addGap(10, 10, 10)
                        .addComponent(lblAppointmentRecieptBillNo, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlApointmentRecieptLayout.createSequentialGroup()
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblAppointmentRecieptNameTag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblAppointmentRecieptKinTag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblAppointmentRecieptKin, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlApointmentRecieptLayout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(lblAppointmentRecieptName, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblAppointmentRecieptDateTag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblAppointmentRecieptAgeTag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblAppointmentRecieptSexTag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblAppointmentRecieptDate, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                    .addComponent(lblAppointmentRecieptSex, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                    .addComponent(lblAppointmentRecieptAge, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptLogo)
                        .addGap(66, 66, 66)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                    .addGap(229, 229, 229)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(113, 113, 113)))
        );
        pnlApointmentRecieptLayout.setVerticalGroup(
            pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(lblAppointmentRecieptLogo))
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addComponent(jLabel3)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addGap(25, 25, 25)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblAppointmentRecieptAge, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAppointmentRecieptAgeTag))
                        .addGap(6, 6, 6)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                                .addComponent(lblAppointmentRecieptDate, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAppointmentRecieptSex, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                                .addComponent(lblAppointmentRecieptDateTag)
                                .addGap(6, 6, 6)
                                .addComponent(lblAppointmentRecieptSexTag))))
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblAppointmentRecieptBillNoTag, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAppointmentRecieptBillNo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblAppointmentRecieptNameTag)
                            .addComponent(lblAppointmentRecieptName, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblAppointmentRecieptKinTag, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAppointmentRecieptKin, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(34, 34, 34)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptConChrg, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblAppointmentRecieptSTax, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAppointmentRecieptSTaxTag, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptConChrgTag, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblAppointmentRecieptDocName, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAppointmentRecieptCTax, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAppointmentRecieptCTaxTag, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAppointmentRecieptDocSpec, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptAmountPaidTag, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                        .addComponent(lblAppointmentRecieptAppointmentDate)
                        .addGap(40, 40, 40)
                        .addComponent(lblAppointmentRecieptRecepTag, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptAmountPaid, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(pnlApointmentRecieptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlApointmentRecieptLayout.createSequentialGroup()
                    .addGap(20, 20, 20)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(535, Short.MAX_VALUE)))
        );

        lblAppointmentRecieptPrintIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_print_64_64.png"))); // NOI18N
        lblAppointmentRecieptPrintIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAppointmentRecieptPrintIconMouseClicked(evt);
            }
        });

        lblAppointmentRecieptBackIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/icons8_undo_black_64.png"))); // NOI18N
        lblAppointmentRecieptBackIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAppointmentRecieptBackIconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlAppointmentRecieptContainerLayout = new javax.swing.GroupLayout(pnlAppointmentRecieptContainer);
        pnlAppointmentRecieptContainer.setLayout(pnlAppointmentRecieptContainerLayout);
        pnlAppointmentRecieptContainerLayout.setHorizontalGroup(
            pnlAppointmentRecieptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAppointmentRecieptContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlAppointmentRecieptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlApointmentReciept, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAppointmentRecieptContainerLayout.createSequentialGroup()
                        .addComponent(lblAppointmentRecieptPrintIcon)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblAppointmentRecieptBackIcon)))
                .addContainerGap())
        );
        pnlAppointmentRecieptContainerLayout.setVerticalGroup(
            pnlAppointmentRecieptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAppointmentRecieptContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlAppointmentRecieptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAppointmentRecieptPrintIcon)
                    .addComponent(lblAppointmentRecieptBackIcon))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlApointmentReciept, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlAppointmentReceiptContainerLayout = new javax.swing.GroupLayout(pnlAppointmentReceiptContainer);
        pnlAppointmentReceiptContainer.setLayout(pnlAppointmentReceiptContainerLayout);
        pnlAppointmentReceiptContainerLayout.setHorizontalGroup(
            pnlAppointmentReceiptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 777, Short.MAX_VALUE)
            .addGroup(pnlAppointmentReceiptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlAppointmentReceiptContainerLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(pnlAppointmentRecieptContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        pnlAppointmentReceiptContainerLayout.setVerticalGroup(
            pnlAppointmentReceiptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 710, Short.MAX_VALUE)
            .addGroup(pnlAppointmentReceiptContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlAppointmentReceiptContainerLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(pnlAppointmentRecieptContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pnlUserAppointmentContainer.add(pnlAppointmentReceiptContainer, "AppointmentReceiptCard");

        pnlUserAppointments.add(pnlUserAppointmentContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 770, 710));

        pnlUserFrontContainer.add(pnlUserAppointments, "AppointmentCard");

        pnlUserViewBills.setBackground(new java.awt.Color(255, 255, 255));
        pnlUserViewBills.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel3.setkBorderRadius(0);
        kGradientPanel3.setkEndColor(new java.awt.Color(153, 153, 255));
        kGradientPanel3.setkGradientFocus(1000);
        kGradientPanel3.setkStartColor(new java.awt.Color(0, 0, 51));
        kGradientPanel3.setName(""); // NOI18N
        kGradientPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblUserViewBillsBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/User/uturn_icon_50.png"))); // NOI18N
        lblUserViewBillsBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUserViewBillsBackMouseClicked(evt);
            }
        });
        kGradientPanel3.add(lblUserViewBillsBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 5, -1, -1));

        btnUserManageIDViewIndoorBill.setText("Indoor Bill");
        btnUserManageIDViewIndoorBill.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnUserManageIDViewIndoorBill.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnUserManageIDViewIndoorBill.setkBorderRadius(15);
        btnUserManageIDViewIndoorBill.setkEndColor(new java.awt.Color(102, 255, 102));
        btnUserManageIDViewIndoorBill.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnUserManageIDViewIndoorBill.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnUserManageIDViewIndoorBill.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnUserManageIDViewIndoorBill.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnUserManageIDViewIndoorBill.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnUserManageIDViewIndoorBill.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnUserManageIDViewIndoorBill.setkStartColor(new java.awt.Color(0, 153, 0));
        btnUserManageIDViewIndoorBill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserManageIDViewIndoorBillActionPerformed(evt);
            }
        });
        kGradientPanel3.add(btnUserManageIDViewIndoorBill, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 5, -1, 50));

        btnUserManageIDViewLabBill.setText("Lab Bill");
        btnUserManageIDViewLabBill.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnUserManageIDViewLabBill.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnUserManageIDViewLabBill.setkBorderRadius(15);
        btnUserManageIDViewLabBill.setkEndColor(new java.awt.Color(102, 255, 102));
        btnUserManageIDViewLabBill.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnUserManageIDViewLabBill.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnUserManageIDViewLabBill.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnUserManageIDViewLabBill.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnUserManageIDViewLabBill.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnUserManageIDViewLabBill.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnUserManageIDViewLabBill.setkStartColor(new java.awt.Color(0, 153, 0));
        btnUserManageIDViewLabBill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserManageIDViewLabBillActionPerformed(evt);
            }
        });
        kGradientPanel3.add(btnUserManageIDViewLabBill, new org.netbeans.lib.awtextra.AbsoluteConstraints(445, 5, -1, 50));

        btnUserManageIDViewConsultancyBill.setText("Consultancy Bill");
        btnUserManageIDViewConsultancyBill.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnUserManageIDViewConsultancyBill.setkBackGroundColor(new java.awt.Color(0, 0, 51));
        btnUserManageIDViewConsultancyBill.setkBorderRadius(15);
        btnUserManageIDViewConsultancyBill.setkEndColor(new java.awt.Color(102, 255, 102));
        btnUserManageIDViewConsultancyBill.setkHoverColor(new java.awt.Color(153, 51, 255));
        btnUserManageIDViewConsultancyBill.setkHoverEndColor(new java.awt.Color(102, 0, 153));
        btnUserManageIDViewConsultancyBill.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btnUserManageIDViewConsultancyBill.setkHoverStartColor(new java.awt.Color(153, 153, 255));
        btnUserManageIDViewConsultancyBill.setkPressedColor(new java.awt.Color(0, 181, 111));
        btnUserManageIDViewConsultancyBill.setkSelectedColor(new java.awt.Color(0, 181, 111));
        btnUserManageIDViewConsultancyBill.setkStartColor(new java.awt.Color(0, 153, 0));
        btnUserManageIDViewConsultancyBill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserManageIDViewConsultancyBillActionPerformed(evt);
            }
        });
        kGradientPanel3.add(btnUserManageIDViewConsultancyBill, new org.netbeans.lib.awtextra.AbsoluteConstraints(242, 5, -1, 50));

        markIndoorBill.setkBorderRadius(20);
        markIndoorBill.setkEndColor(new java.awt.Color(255, 255, 0));
        markIndoorBill.setkGradientFocus(120);
        markIndoorBill.setkStartColor(new java.awt.Color(255, 153, 0));
        markIndoorBill.setOpaque(false);

        javax.swing.GroupLayout markIndoorBillLayout = new javax.swing.GroupLayout(markIndoorBill);
        markIndoorBill.setLayout(markIndoorBillLayout);
        markIndoorBillLayout.setHorizontalGroup(
            markIndoorBillLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markIndoorBillLayout.setVerticalGroup(
            markIndoorBillLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel3.add(markIndoorBill, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 50, 180, 10));

        markConcBill.setkBorderRadius(20);
        markConcBill.setkEndColor(new java.awt.Color(255, 255, 0));
        markConcBill.setkGradientFocus(120);
        markConcBill.setkStartColor(new java.awt.Color(255, 153, 0));
        markConcBill.setOpaque(false);

        javax.swing.GroupLayout markConcBillLayout = new javax.swing.GroupLayout(markConcBill);
        markConcBill.setLayout(markConcBillLayout);
        markConcBillLayout.setHorizontalGroup(
            markConcBillLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markConcBillLayout.setVerticalGroup(
            markConcBillLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel3.add(markConcBill, new org.netbeans.lib.awtextra.AbsoluteConstraints(245, 50, 180, 10));

        markLabBill.setkBorderRadius(20);
        markLabBill.setkEndColor(new java.awt.Color(255, 255, 0));
        markLabBill.setkGradientFocus(120);
        markLabBill.setkStartColor(new java.awt.Color(255, 153, 0));
        markLabBill.setOpaque(false);

        javax.swing.GroupLayout markLabBillLayout = new javax.swing.GroupLayout(markLabBill);
        markLabBill.setLayout(markLabBillLayout);
        markLabBillLayout.setHorizontalGroup(
            markLabBillLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        markLabBillLayout.setVerticalGroup(
            markLabBillLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        kGradientPanel3.add(markLabBill, new org.netbeans.lib.awtextra.AbsoluteConstraints(448, 50, 180, 10));

        pnlUserViewBills.add(kGradientPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 60));

        pnlUserViewBillsContainer.setLayout(new java.awt.CardLayout());

        pnlViewIndoorBills.setBackground(new java.awt.Color(255, 255, 255));
        pnlViewIndoorBills.setPreferredSize(new java.awt.Dimension(771, 710));
        pnlViewIndoorBills.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        spIndoorBill.setBackground(new java.awt.Color(255, 255, 255));
        spIndoorBill.setBorder(new javax.swing.border.MatteBorder(null));
        spIndoorBill.setAutoscrolls(true);
        spIndoorBill.setPreferredSize(new java.awt.Dimension(750, 600));

        tblIndoorBill.setAutoCreateRowSorter(true);
        tblIndoorBill.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblIndoorBill.setEnabled(false);
        tblIndoorBill.setGridColor(new java.awt.Color(51, 51, 255));
        tblIndoorBill.setPreferredSize(new java.awt.Dimension(750, 600));
        tblIndoorBill.setRowHeight(20);
        tblIndoorBill.setShowGrid(true);
        spIndoorBill.setViewportView(tblIndoorBill);

        pnlViewIndoorBills.add(spIndoorBill, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 750, 600));

        lblIndoorPSearchIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/search_30.png"))); // NOI18N
        lblIndoorPSearchIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblIndoorPSearchIconMouseClicked(evt);
            }
        });
        pnlViewIndoorBills.add(lblIndoorPSearchIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 40, -1, -1));

        pnlViewIndoorBills.add(cbIndoorPSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 260, 30));

        pnlUserViewBillsContainer.add(pnlViewIndoorBills, "IndoorBillCard");
        pnlViewIndoorBills.getAccessibleContext().setAccessibleDescription("");

        pnlViewLabBills.setBackground(new java.awt.Color(255, 255, 255));
        pnlViewLabBills.setMinimumSize(new java.awt.Dimension(771, 710));
        pnlViewLabBills.setPreferredSize(new java.awt.Dimension(771, 710));
        pnlViewLabBills.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        spLabBill.setBackground(new java.awt.Color(255, 255, 255));
        spLabBill.setBorder(new javax.swing.border.MatteBorder(null));
        spLabBill.setAutoscrolls(true);
        spLabBill.setPreferredSize(new java.awt.Dimension(750, 600));

        tblLabBill.setAutoCreateRowSorter(true);
        tblLabBill.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblLabBill.setEnabled(false);
        tblLabBill.setGridColor(new java.awt.Color(51, 51, 255));
        tblLabBill.setMinimumSize(new java.awt.Dimension(60, 80));
        tblLabBill.setPreferredSize(new java.awt.Dimension(750, 600));
        tblLabBill.setRowHeight(20);
        tblLabBill.setShowGrid(true);
        spLabBill.setViewportView(tblLabBill);

        pnlViewLabBills.add(spLabBill, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 750, 600));

        lblLabPSearchIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/search_30.png"))); // NOI18N
        lblLabPSearchIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLabPSearchIconMouseClicked(evt);
            }
        });
        pnlViewLabBills.add(lblLabPSearchIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 40, -1, -1));

        pnlViewLabBills.add(cbLabPSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 260, 30));

        pnlUserViewBillsContainer.add(pnlViewLabBills, "LabBillCard");

        pnlViewConsultancyBills.setBackground(new java.awt.Color(255, 255, 255));
        pnlViewConsultancyBills.setMinimumSize(new java.awt.Dimension(760, 700));
        pnlViewConsultancyBills.setPreferredSize(new java.awt.Dimension(770, 710));
        pnlViewConsultancyBills.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblConsultancyPSearchIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Reception/search_30.png"))); // NOI18N
        lblConsultancyPSearchIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblConsultancyPSearchIconMouseClicked(evt);
            }
        });
        pnlViewConsultancyBills.add(lblConsultancyPSearchIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 40, -1, -1));

        spConsultancyBill.setBackground(new java.awt.Color(255, 255, 255));
        spConsultancyBill.setBorder(new javax.swing.border.MatteBorder(null));
        spConsultancyBill.setAutoscrolls(true);
        spConsultancyBill.setPreferredSize(new java.awt.Dimension(750, 600));

        tblConsultancyBill.setAutoCreateRowSorter(true);
        tblConsultancyBill.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblConsultancyBill.setEnabled(false);
        tblConsultancyBill.setGridColor(new java.awt.Color(51, 51, 255));
        tblConsultancyBill.setMinimumSize(new java.awt.Dimension(60, 80));
        tblConsultancyBill.setPreferredSize(new java.awt.Dimension(750, 600));
        tblConsultancyBill.setRowHeight(20);
        tblConsultancyBill.setShowGrid(true);
        spConsultancyBill.setViewportView(tblConsultancyBill);

        pnlViewConsultancyBills.add(spConsultancyBill, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 750, 600));

        pnlViewConsultancyBills.add(cbConsultancyPSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 260, 30));

        pnlUserViewBillsContainer.add(pnlViewConsultancyBills, "ConsultancyBillCard");

        pnlUserViewBills.add(pnlUserViewBillsContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 59, 771, 709));

        pnlUserFrontContainer.add(pnlUserViewBills, "ViewBillsCard");

        getContentPane().add(pnlUserFrontContainer, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 0, 770, 768));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnUserFrontAppointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserFrontAppointmentActionPerformed
        // TODO add your handling code here:
        cardlayout.show(pnlUserFrontContainer,"AppointmentCard");
    }//GEN-LAST:event_btnUserFrontAppointmentActionPerformed

    private void UsermanageIDAddNewKinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsermanageIDAddNewKinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UsermanageIDAddNewKinActionPerformed

    private void txtUsermanageIDAddNewContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsermanageIDAddNewContactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsermanageIDAddNewContactActionPerformed

    private void txtUsermanageIDAddNewStreetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsermanageIDAddNewStreetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsermanageIDAddNewStreetActionPerformed

    private void lblPhnNumComponentMoved(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_lblPhnNumComponentMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_lblPhnNumComponentMoved

    private void txtPhnNumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPhnNumActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhnNumActionPerformed

    private void cbDocNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbDocNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbDocNameActionPerformed

    private void cbATimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbATimeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbATimeActionPerformed

    private void btnBAppointmentSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBAppointmentSubmitActionPerformed
        try {
            
            Statement stmt =con.createStatement();
                    String select = "select * from appointments_record_temporary";
                    ResultSet rsst = stmt.executeQuery(select);

                     SimpleDateFormat sdf= new SimpleDateFormat("dd-MM-yyyy");
                String date_today= LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
                String date_a=sdf.format(jcalADate.getDate());
                
                int a;
                a= date_a.compareToIgnoreCase(date_today);
                    int fl=0;

                    while(rsst.next())
                    {

                        if(rsst.getString("time").equals(String.valueOf(cbATime.getSelectedItem()))){
                            if (rsst.getString("date").equals(date_a)){
                                if (rsst.getString("Patient_id").equals(String.valueOf(cbPatientId.getSelectedItem()))){

                                fl=fl+1;
                                break;
                            }
 
                            }
                        }

                    }

                    if(fl!=0){
                        JOptionPane.showMessageDialog(null, "Appointment is already booked");

                        Reset();
                    }else
                    {
            pstmt=con.prepareStatement("insert into APPOINTMENTS_RECORD (PATIENT_ID,NAME,DOC_NAME,SPECIALISATION,CONTACT,DATE,TIME,DATE_BILL,DOC_CHARGES,AMOUNT) values (?,?,?,?,?,?,?,?,?,?)");
          
            pstmt1=con.prepareStatement("insert into APPOINTMENTS_RECORD_TEMPORARY (PATIENT_ID,NAME,DOC_NAME,SPECIALISATION,CONTACT,DATE,TIME,DATE_BILL) values (?,?,?,?,?,?,?,?)");
          
            ResultSet rs=stmt.executeQuery("select * from PATIENT_INFO where PATIENT_ID="+Integer.parseInt(String.valueOf(cbPatientId.getSelectedItem())));
            
            int flag=0;
            if (cbPatientId.getSelectedIndex()==0)
            {
                lblBAppointmentMandatory1.setVisible(true);
            }
            else
            {
                
                pstmt.setString(1,String.valueOf(cbPatientId.getSelectedItem()));
                 pstmt1.setString(1,String.valueOf(cbPatientId.getSelectedItem()));
              
                flag++;
                
            }
           
            if (cbATime.getSelectedIndex()==0)
            {
                lblBAppointmentMandatory1.setVisible(true);
                
            }
            else
            {
                pstmt.setString(7,String.valueOf(cbATime.getSelectedItem()));
                pstmt1.setString(7,String.valueOf(cbATime.getSelectedItem()));
                flag++;
                
            }
            if(txtPhnNum.getText().trim().isEmpty())
            {
                lblBAppointmentMandatory1.setVisible(true);
                
            }
            else
            {
                pstmt.setString(5,String.valueOf(cbPhnNum.getSelectedItem())+txtPhnNum.getText());
                  pstmt1.setString(5,String.valueOf(cbPhnNum.getSelectedItem())+txtPhnNum.getText());
               
                flag++;
                
            }
            if(cbDepartment.getSelectedIndex()==0)
            {
                lblBAppointmentMandatory1.setVisible(true);
                
            }
            else
            {
                pstmt.setString(4,String.valueOf(cbDepartment.getSelectedItem()));
                 pstmt1.setString(4,String.valueOf(cbDepartment.getSelectedItem()));
                flag++;
                
            }
            if(cbDocName.getSelectedIndex()==0)
            {
                lblBAppointmentMandatory1.setVisible(true);
                
            }
            else
            {
                pstmt.setString(3,String.valueOf(cbDocName.getSelectedItem()));
                 pstmt1.setString(3,String.valueOf(cbDocName.getSelectedItem()));
               
                flag++;
                
            }
            
            if(flag==5)
            {
                rs.next();
                pstmt.setString(2,rs.getString("NAME"));
                 pstmt1.setString(2,rs.getString("NAME"));
                 lblAppointmentRecieptSex.setText(rs.getString("GENDER"));
                lblAppointmentRecieptName.setText(rs.getString("NAME"));
                lblAppointmentRecieptKin.setText(rs.getString("KIN"));
                lblAppointmentRecieptAge.setText((Age_calc(rs.getString("DOB"),date_today)));
              
                String[] doc_n=String.valueOf(cbDocName.getSelectedItem()).split("[.]+");
                String doc_name=doc_n[1];
                ResultSet docinfo=stmt.executeQuery("select * from DOCTOR_INFO where NAME='"+doc_name+"'");
                docinfo.next();
                double fee=docinfo.getDouble("DOC_CHARGES");
                lblAppointmentRecieptConChrg.setText(String.valueOf(fee));
                double state_gst= fee*0.09;
                double central_gst=fee*0.09;
                double total=fee+state_gst+central_gst;
               
                
                if (a<0)
                {
                lblBAppointmentInvalidDate.setVisible(true);
                }
                else
                {
                pstmt.setString(6,date_a );
                  pstmt1.setString(6,date_a );
                pstmt.setString(8,date_today );
                 pstmt1.setString(8,date_today );
                }
                
                pstmt.setDouble(9, fee);
                pstmt.setDouble(10, total);
                pstmt.executeUpdate();
                
                 pstmt1.executeUpdate();
                 
                
                Statement stat=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                ResultSet rst=stat.executeQuery("select * from APPOINTMENTS_RECORD ");
                rst.last();
                lblAppointmentRecieptBillNo.setText(String.valueOf(rst.getInt(1)));
                lblAppointmentRecieptDate.setText(String.valueOf(date_today));
                lblAppointmentRecieptDocName.setText(String.valueOf(cbDocName.getSelectedItem()));
                lblAppointmentRecieptDocSpec.setText(String.valueOf(cbDepartment.getSelectedItem()));
                
                lblAppointmentRecieptAppointmentDate.setText("Date of Appointment : "+date_a);
                
                
                
                lblAppointmentRecieptSTax.setText(String.valueOf(state_gst));
                lblAppointmentRecieptCTax.setText(String.valueOf(central_gst));
                lblAppointmentRecieptAmountPaid.setText(String.valueOf(total));
                appointmentcardlayout.show(pnlUserAppointmentContainer,"AppointmentReceiptCard");
                
            }
            else{
                
                JOptionPane.showMessageDialog(user_front.this,"Error");
                Reset();
            }}
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(user_front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            
        }
            

    }//GEN-LAST:event_btnBAppointmentSubmitActionPerformed

    private void Reset()
    {
        cbPatientId.setSelectedIndex(0);
        cbATime.setSelectedIndex(0);
        txtPhnNum.setText("");
        cbDepartment.setSelectedIndex(0);
        cbDocName.setSelectedIndex(0);
        jcalADate.setDate(null);
    }
    
    private void btnUserAppointmentCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserAppointmentCancelActionPerformed
        // TODO add your handling code here:
        markBAppointment.setVisible(false);
        markCAppointment.setVisible(true);
        appointmentcardlayout.show(pnlUserAppointmentContainer,"CancelAppointmentCard");
    }//GEN-LAST:event_btnUserAppointmentCancelActionPerformed

    private void cbPatientIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPatientIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbPatientIdActionPerformed

    private void btnUsermanageIDExistingLinkIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUsermanageIDExistingLinkIDActionPerformed
        // TODO add your handling code here:
        try{
            if (txtUsermanageIDExistingIDEnter.getText().trim().isEmpty())
            {
                lblManageExistingIDWarning.setVisible(true);
                
            }
            else
            {
            
            ResultSet rs=stmt.executeQuery("Select USERNAME from PATIENT_INFO where PATIENT_ID ="+Integer.parseInt(txtUsermanageIDExistingIDEnter.getText()));
            rs.next();
               
                
            
                
            if(rs.getString("username")==null)
            {
                
                pstmt=con.prepareStatement("update PATIENT_INFO set USERNAME='"+useruname+"' where PATIENT_ID="+Integer.parseInt(txtUsermanageIDExistingIDEnter.getText()));
                pstmt.executeUpdate();
                cbUsermanageIDExistingIDSel.addItem(String.valueOf(Integer.parseInt(txtUsermanageIDExistingIDEnter.getText())));
                
            }
            
            else if(rs.getString("USERNAME")==useruname)
            {
            JOptionPane.showMessageDialog(null,"This Patient ID is already linked to your account.");
            }
            else
            {
                JOptionPane.showMessageDialog(null,"Sorry, this Patient ID is already linked with another User.");
                
            }
        }}
         catch(SQLException e){
        
        java.util.logging.Logger.getLogger(user_front.class.getName()).log(java.util.logging.Level.SEVERE, null, e);
        
        }
    }//GEN-LAST:event_btnUsermanageIDExistingLinkIDActionPerformed

    private void lblAppointmentRecieptBackIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAppointmentRecieptBackIconMouseClicked
        // TODO add your handling code here:
        appointmentcardlayout.show(pnlUserAppointmentContainer,"BookAppointmentCard");
    }//GEN-LAST:event_lblAppointmentRecieptBackIconMouseClicked

    private void cbPhnNumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPhnNumActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbPhnNumActionPerformed

    private void btnUsermanageIDAddNewAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUsermanageIDAddNewAddActionPerformed
        // TODO add your handling code here:
         try{
                SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
                String date=sdf.format(dateUsermanageIDAddNewDOB.getDate());
                String date_today= LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
                int a=date_today.compareToIgnoreCase(date);
                
                pstmt=con.prepareStatement("insert into PATIENT_INFO_TEMPORARY (USERNAME,NAME,GENDER,DOB,BG,CONTACT,ADDRESS,KIN,EMAIL) values(?,?,?,?,?,?,?,?,?)");
                int flag=0;
                
                if(txtUsermanageIDAddNewName.getText().trim().isEmpty())
                {
                    lblPDAddMandatory.setVisible(true);
                }
                else
                {
                    pstmt.setString(2,String.valueOf(txtUsermanageIDAddNewName.getText()));
              
                flag++;
                
                }
                if(UsermanageIDAddNewKin.getText().trim().isEmpty())
                {
                    lblPDAddMandatory.setVisible(true);
                }
                else
                {
                pstmt.setString(8, UsermanageIDAddNewKin.getText());
                flag++;
                
                }
                if(txtUsermanageIDAddEmail.getText().trim().isEmpty())
                {
                    lblPDAddMandatory.setVisible(true);
                }
                else
                {
                pstmt.setString(9, txtUsermanageIDAddEmail.getText());
                flag++;
                
                }
                if(txtUsermanageIDAddNewContact.getText().trim().isEmpty())
                {
                    lblPDAddMandatory.setVisible(true);
                }
                else
                {
                String phn= String.valueOf(cbPDAddContact.getSelectedItem())+txtUsermanageIDAddNewContact.getText();
                pstmt.setString(6,phn);
                flag++;
                
                }
                if(cbUsermanageIDAddNewBloodGrp.getSelectedIndex()==0)
                {
                lblPDAddMandatory.setVisible(true);
                }
                else
                {
                pstmt.setString(5,String.valueOf(cbUsermanageIDAddNewBloodGrp.getSelectedItem()));
                flag++;
                }
                if (cbUsermanageIDAddNewGender.getSelectedIndex()==0)
                {
                lblPDAddMandatory.setVisible(true);
                }
                else{
                pstmt.setString(3,String.valueOf(cbUsermanageIDAddNewGender.getSelectedItem()));
                flag++;
                
                }
                if(dateUsermanageIDAddNewDOB.getDate()==null)
                {
                lblPDAddMandatory.setVisible(true);
                }
                else if(a<0)
                        {
                        lblPDAddInvalidDate.setVisible(true);
                        
                        }
                else
                {
                
                pstmt.setString(4,date);
                flag++;
                
                }
                if(txtUsermanageIDAddNewStreet.getText().trim().isEmpty())
                {
                
                lblPDAddMandatory.setVisible(true);
                }
                else
                {
                if(cbUsermanageIDAddNewState.getSelectedIndex()==0)
                {
                lblPDAddMandatory.setVisible(true);
                }
                else
                {
                if(cbUsermanageIDAddNewCity.getSelectedIndex()==0)
                {
                lblPDAddMandatory.setVisible(true);
                }
                else
                {
                String Address= (txtUsermanageIDAddNewStreet.getText())+", "+String.valueOf(cbUsermanageIDAddNewCity.getSelectedItem())+", "+String.valueOf(cbUsermanageIDAddNewState.getSelectedItem());
                pstmt.setString(7, Address);
                flag++;
                
                }
                }
                }
                
                if(flag==8){ 
                    pstmt.setString(1,useruname);
                    pstmt.executeUpdate();
                    txtUsermanageIDAddNewContact.setText("");
                    UsermanageIDAddNewKin.setText("");
                    txtUsermanageIDAddNewName.setText("");
                    txtUsermanageIDAddNewStreet.setText("");
                    txtUsermanageIDAddEmail.setText("");
                    cbUsermanageIDAddNewBloodGrp.setSelectedIndex(0);
                    cbUsermanageIDAddNewCity.setSelectedIndex(1);
                    cbUsermanageIDAddNewGender.setSelectedIndex(0);
                    cbUsermanageIDAddNewState.setSelectedIndex(0);
                    dateUsermanageIDAddNewDOB.setDate(null);
                    
                    JOptionPane.showMessageDialog(null,"Registration request is in queue. Kindly wait for the confirmation notification.");}
        
        }
        catch(SQLException e){
        
        
        java.util.logging.Logger.getLogger(user_front.class.getName()).log(java.util.logging.Level.SEVERE, null, e);
        }
        
    }//GEN-LAST:event_btnUsermanageIDAddNewAddActionPerformed

    private void cbPDAddContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPDAddContactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbPDAddContactActionPerformed

    private void btnUsermanageIDExistingDltIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUsermanageIDExistingDltIDActionPerformed
        // TODO add your handling code here:
         try{
            int P = JOptionPane.showConfirmDialog(null," Are you sure want to delete this UserId from your username ?","Confirmation",JOptionPane.YES_NO_OPTION);
            if (P==0)
            {
                pstmt=con.prepareStatement("Update PATIENT_INFO set USERNAME="+null+" where PATIENT_ID ="+Integer.parseInt(String.valueOf(cbUsermanageIDExistingIDSel.getSelectedItem())));
                
               
                pstmt.executeUpdate();
            
                JOptionPane.showMessageDialog(this,"Successfully deleted","Record",JOptionPane.INFORMATION_MESSAGE);

                cbUsermanageIDExistingIDSel.removeItem((cbUsermanageIDExistingIDSel.getSelectedItem()));
                cbUsermanageIDExistingIDSel.setSelectedIndex(0);
            }
            else{
                JOptionPane.showMessageDialog(null,"No Specific Id Found");
            }
        }catch(HeadlessException | SQLException ex){
            java.util.logging.Logger.getLogger(user_front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnUsermanageIDExistingDltIDActionPerformed

    private void lblUserFrontDashMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUserFrontDashMouseClicked
        // TODO add your handling code here:
        markDash.setVisible(true);
        markHelp.setVisible(false);
        markSettings.setVisible(false);
        cardlayout.show(pnlUserFrontContainer,"DashCard");
    }//GEN-LAST:event_lblUserFrontDashMouseClicked

    private void lblUserFrontSettingsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUserFrontSettingsMouseClicked
        // TODO add your handling code here:
        markDash.setVisible(false);
        markHelp.setVisible(false);
        markSettings.setVisible(true);
        lblUserFrontSettings.setOpaque(true);
    }//GEN-LAST:event_lblUserFrontSettingsMouseClicked

    private void lblUserFrontHnsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUserFrontHnsMouseClicked
        // TODO add your handling code here:
        markDash.setVisible(false);
        markHelp.setVisible(true);
        markSettings.setVisible(false);
        lblUserFrontSettings.setOpaque(false);
    }//GEN-LAST:event_lblUserFrontHnsMouseClicked

    private void lblUserFrontLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUserFrontLogoutMouseClicked
        // TODO add your handling code here:
        lblUserFrontDash.setOpaque(false);
        lblUserFrontHns.setOpaque(false);
        lblUserFrontLogout.setOpaque(true);
        lblUserFrontSettings.setOpaque(false);
        new user_login().setVisible(true);
        dispose();
    }//GEN-LAST:event_lblUserFrontLogoutMouseClicked

    private void btnUserManageIDViewIndoorBillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserManageIDViewIndoorBillActionPerformed
        // TODO add your handling code here:
        markIndoorBill.setVisible(true);
        markConcBill.setVisible(false);
        markLabBill.setVisible(false);
        viewbillcardlayout.show(pnlUserViewBillsContainer,"IndoorBillCard");
    }//GEN-LAST:event_btnUserManageIDViewIndoorBillActionPerformed

    private void btnUserManageIDViewLabBillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserManageIDViewLabBillActionPerformed
        // TODO add your handling code here:
        markIndoorBill.setVisible(false);
        markConcBill.setVisible(false);
        markLabBill.setVisible(true);
        viewbillcardlayout.show(pnlUserViewBillsContainer,"LabBillCard");
    }//GEN-LAST:event_btnUserManageIDViewLabBillActionPerformed

    private void btnUserManageIDViewConsultancyBillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserManageIDViewConsultancyBillActionPerformed
        // TODO add your handling code here:
        markIndoorBill.setVisible(false);
        markConcBill.setVisible(true);
        markLabBill.setVisible(false);
        viewbillcardlayout.show(pnlUserViewBillsContainer,"ConsultancyBillCard");
    }//GEN-LAST:event_btnUserManageIDViewConsultancyBillActionPerformed

    private void lblIndoorPSearchIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblIndoorPSearchIconMouseClicked
        // TODO add your handling code here:
        try{
            stmt=con.createStatement();

            ResultSet rs=stmt.executeQuery("select BILL_NO,PATIENT_ID,NAME,CONSULTATION_CHARGES,UTILITY_CHARGES,SERVICE_CHARGES,TOTAL_AMT from INDOOR where PATIENT_ID="+Integer.parseInt(String.valueOf(cbIndoorPSearch.getSelectedItem())));
            tblIndoorBill.setModel(DbUtils.resultSetToTableModel(rs));
            customtable(tblIndoorBill);

        }
        catch(SQLException e){
           java.util.logging.Logger.getLogger(user_front.class.getName()).log(java.util.logging.Level.SEVERE, null, e);

        }
    }//GEN-LAST:event_lblIndoorPSearchIconMouseClicked

    private void lblConsultancyPSearchIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblConsultancyPSearchIconMouseClicked
        // TODO add your handling code here:
        try{
            stmt=con.createStatement();

            ResultSet rs=stmt.executeQuery("select BILL_NO,PATIENT_ID,NAME,DOC_CHARGES,AMOUNT from APPOINTMENTS_RECORD where PATIENT_ID="+Integer.parseInt(String.valueOf(cbIndoorPSearch.getSelectedItem())));
            tblConsultancyBill.setModel(DbUtils.resultSetToTableModel(rs));
            customtable(tblConsultancyBill);

        }
        catch(SQLException e){
            java.util.logging.Logger.getLogger(user_front.class.getName()).log(java.util.logging.Level.SEVERE, null, e);

        }
    }//GEN-LAST:event_lblConsultancyPSearchIconMouseClicked

    private void lblLabPSearchIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLabPSearchIconMouseClicked
        // TODO add your handling code here:
        try{
            stmt=con.createStatement();

            ResultSet rs=stmt.executeQuery("select BILL_NO,PATIENT_ID,NAME,TEST_NAME,TEST_CHARGES from LAB_BILL where PATIENT_ID="+Integer.parseInt(String.valueOf(cbIndoorPSearch.getSelectedItem())));
            tblLabBill.setModel(DbUtils.resultSetToTableModel(rs));
            customtable(tblLabBill);

        }
        catch(SQLException e){
           java.util.logging.Logger.getLogger(user_front.class.getName()).log(java.util.logging.Level.SEVERE, null, e);

        }
    }//GEN-LAST:event_lblLabPSearchIconMouseClicked

    private void txtUsermanageIDAddNewNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsermanageIDAddNewNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsermanageIDAddNewNameActionPerformed

    private void cbUsermanageIDAddNewStateItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbUsermanageIDAddNewStateItemStateChanged
        // TODO add your handling code here:
         try{
        stmt=con.createStatement();
        ResultSet rs=stmt.executeQuery("select CITIES from statewise_cities where STATES='"+String.valueOf(cbUsermanageIDAddNewState.getSelectedItem())+"'");
        cbUsermanageIDAddNewCity.removeAllItems();
        cbUsermanageIDAddNewCity.addItem("Select City");
        while(rs.next())
        {
        cbUsermanageIDAddNewCity.addItem(rs.getString("CITIES"));
        
        }
        
        }
        catch(SQLException e){
            e.getMessage();
        }
    
    }//GEN-LAST:event_cbUsermanageIDAddNewStateItemStateChanged

    private void cbDepartmentItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbDepartmentItemStateChanged
        // TODO add your handling code here:
        try{
        stmt=con.createStatement();
        ResultSet rst=stmt.executeQuery("select NAME from DOCTOR_INFO where SPECIALISATION='"+String.valueOf(cbDepartment.getSelectedItem())+"'");
        cbDocName.removeAllItems();
        cbDocName.addItem("Select Doctor");
        while(rst.next())
        {
        cbDocName.addItem("Dr."+rst.getString("Name"));
        
        }
        
        }
        catch(SQLException e){
            e.getMessage();
        }
    }//GEN-LAST:event_cbDepartmentItemStateChanged

    private void txtUsermanageIDAddEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsermanageIDAddEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsermanageIDAddEmailActionPerformed

    private void lblAppointmentRecieptPrintIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAppointmentRecieptPrintIconMouseClicked
        // TODO add your handling code here:
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName("Print Data");
        job.setPrintable(new Printable(){
        public int print(Graphics pg,PageFormat pf,int pageNum){
            if(pageNum>0)
              {return Printable.NO_SUCH_PAGE;}
            Graphics2D g2 = (Graphics2D)pg;
            g2.translate(pf.getImageableX(), pf.getImageableY());
            g2.scale(0.75,0.75);
            pnlApointmentReciept.paint(g2);// panel which you want to print
            return Printable.PAGE_EXISTS;
        }
        });
        boolean ok = job.printDialog();
        if(ok){
            try{
                job.print();
            }
            catch(PrinterException ex){
                
                
            }}
    }//GEN-LAST:event_lblAppointmentRecieptPrintIconMouseClicked

    private void btnUserFrontManageIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserFrontManageIDActionPerformed
        // TODO add your handling code here:
        cardlayout.show(pnlUserFrontContainer,"ManageIDCard");
    }//GEN-LAST:event_btnUserFrontManageIDActionPerformed

    private void btnUserFrontViewBillsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserFrontViewBillsActionPerformed
        // TODO add your handling code here:
        cardlayout.show(pnlUserFrontContainer,"ViewBillsCard");
    }//GEN-LAST:event_btnUserFrontViewBillsActionPerformed

    private void btnUserManageIDGeneratingIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserManageIDGeneratingIDActionPerformed
        // TODO add your handling code here:
        markAddID.setVisible(true);
        markExistingID.setVisible(false);
         managecardlayout.show(pnlUserManageIDContainer,"ManageIDAddCard");
    }//GEN-LAST:event_btnUserManageIDGeneratingIDActionPerformed

    private void btnUserManageIDChngingExistingIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserManageIDChngingExistingIDActionPerformed
        // TODO add your handling code here:
        markAddID.setVisible(false);
        markExistingID.setVisible(true);
        managecardlayout.show(pnlUserManageIDContainer,"ManageIDExistingCard");
    }//GEN-LAST:event_btnUserManageIDChngingExistingIDActionPerformed

    private void btnUserAppointmentBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserAppointmentBookActionPerformed
        // TODO add your handling code here:
        markBAppointment.setVisible(true);
        markCAppointment.setVisible(false);
        appointmentcardlayout.show(pnlUserAppointmentContainer,"BookAppointmentCard");
    }//GEN-LAST:event_btnUserAppointmentBookActionPerformed

    private void lblUserManageIDbackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUserManageIDbackMouseClicked
        // TODO add your handling code here:
        cardlayout.show(pnlUserFrontContainer,"DashCard");
    }//GEN-LAST:event_lblUserManageIDbackMouseClicked

    private void lblUserViewBillsBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUserViewBillsBackMouseClicked
        // TODO add your handling code here:
        cardlayout.show(pnlUserFrontContainer,"DashCard");
    }//GEN-LAST:event_lblUserViewBillsBackMouseClicked

    private void lblUserAppointmentbackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUserAppointmentbackMouseClicked
        // TODO add your handling code here:
        cardlayout.show(pnlUserFrontContainer,"DashCard");
    }//GEN-LAST:event_lblUserAppointmentbackMouseClicked

    private void cbPatientId1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPatientId1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbPatientId1ActionPerformed

    private void cbDocName1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbDocName1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbDocName1ActionPerformed

    private void cbATime1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbATime1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbATime1ActionPerformed

    private void btnCAppointmentCannelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCAppointmentCannelActionPerformed
        // TODO add your handling code here:
         try{
            int P = JOptionPane.showConfirmDialog(null," Are you sure want to cancel this appointment ?","Confirmation",JOptionPane.YES_NO_OPTION);
            if (P==0)
            {
                SimpleDateFormat sdf= new SimpleDateFormat("dd-MM-yyyy");
                String date_today= LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
                String date_a=sdf.format(jcalADate1.getDate());

                int a= date_a.compareToIgnoreCase(date_today);
                if (a>0)
                {
                String sql= "delete from APPOINTMENT_INFO_TEMPORARY where PATIENT_ID = " + cbPatientId1.getSelectedItem() + " and DATE = '"+date_a+"' and TIME = '"+cbATime1.getSelectedItem()+"' and DOC_NAME = '"+cbDocName1.getSelectedItem()+"'";
                PreparedStatement pst11=con.prepareStatement(sql);
                pst11.execute();
                JOptionPane.showMessageDialog(this,"Successfully cancelled","Record",JOptionPane.INFORMATION_MESSAGE);

                }
            else{
                JOptionPane.showMessageDialog(null,"Cancelation time has already passed.");
 
                }
            
            }
         
         }catch(HeadlessException | SQLException ex){
            JOptionPane.showMessageDialog(this,ex);
        }
    }//GEN-LAST:event_btnCAppointmentCannelActionPerformed

    private void cbDepartment1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbDepartment1ItemStateChanged
        // TODO add your handling code here:
        try{
        stmt=con.createStatement();
        ResultSet rst=stmt.executeQuery("select NAME from DOCTOR_INFO where SPECIALISATION='"+String.valueOf(cbDepartment1.getSelectedItem())+"'");
        cbDocName1.removeAllItems();
        cbDocName1.addItem("Select Doctor");
        while(rst.next())
        {
        cbDocName1.addItem("Dr."+rst.getString("Name"));
        
        }
        
        }
        catch(SQLException e){
            e.getMessage();
        }
    }//GEN-LAST:event_cbDepartment1ItemStateChanged

    private void btnBAppointmentResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBAppointmentResetActionPerformed
        // TODO add your handling code here:
        Reset();
    }//GEN-LAST:event_btnBAppointmentResetActionPerformed

    private void txtUsermanageIDExistingIDEnterMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtUsermanageIDExistingIDEnterMouseClicked
        // TODO add your handling code here:
        lblManageExistingIDWarning.setVisible(false);
        txtUsermanageIDExistingIDEnter.setText("");
        txtUsermanageIDExistingIDEnter.grabFocus();
        
    }//GEN-LAST:event_txtUsermanageIDExistingIDEnterMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(user_front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(user_front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(user_front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(user_front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new user_front().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField UsermanageIDAddNewKin;
    private keeptoo.KButton btnBAppointmentReset;
    private keeptoo.KButton btnBAppointmentSubmit;
    private keeptoo.KButton btnCAppointmentCannel;
    private keeptoo.KButton btnUserAppointmentBook;
    private keeptoo.KButton btnUserAppointmentCancel;
    private javax.swing.JButton btnUserFrontAppointment;
    private javax.swing.JButton btnUserFrontManageID;
    private javax.swing.JButton btnUserFrontViewBills;
    private keeptoo.KButton btnUserManageIDChngingExistingID;
    private keeptoo.KButton btnUserManageIDGeneratingID;
    private keeptoo.KButton btnUserManageIDViewConsultancyBill;
    private keeptoo.KButton btnUserManageIDViewIndoorBill;
    private keeptoo.KButton btnUserManageIDViewLabBill;
    private keeptoo.KButton btnUsermanageIDAddNewAdd;
    private keeptoo.KButton btnUsermanageIDExistingDltID;
    private keeptoo.KButton btnUsermanageIDExistingLinkID;
    private javax.swing.JComboBox<String> cbATime;
    private javax.swing.JComboBox<String> cbATime1;
    private javax.swing.JComboBox<String> cbConsultancyPSearch;
    private javax.swing.JComboBox<String> cbDepartment;
    private javax.swing.JComboBox<String> cbDepartment1;
    private javax.swing.JComboBox<String> cbDocName;
    private javax.swing.JComboBox<String> cbDocName1;
    private javax.swing.JComboBox<String> cbIndoorPSearch;
    private javax.swing.JComboBox<String> cbLabPSearch;
    private javax.swing.JComboBox<String> cbPDAddContact;
    private javax.swing.JComboBox<String> cbPatientId;
    private javax.swing.JComboBox<String> cbPatientId1;
    private javax.swing.JComboBox<String> cbPhnNum;
    private javax.swing.JComboBox<String> cbUsermanageIDAddNewBloodGrp;
    private javax.swing.JComboBox<String> cbUsermanageIDAddNewCity;
    private javax.swing.JComboBox<String> cbUsermanageIDAddNewGender;
    private javax.swing.JComboBox<String> cbUsermanageIDAddNewState;
    private javax.swing.JComboBox<String> cbUsermanageIDExistingIDSel;
    private com.toedter.calendar.JDateChooser dateUsermanageIDAddNewDOB;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private com.toedter.calendar.JDateChooser jcalADate;
    private com.toedter.calendar.JDateChooser jcalADate1;
    private keeptoo.KGradientPanel kGradientPanel1;
    private keeptoo.KGradientPanel kGradientPanel2;
    private keeptoo.KGradientPanel kGradientPanel3;
    private keeptoo.KGradientPanel kpnlUserFrontDash;
    private javax.swing.JLabel lblADate;
    private javax.swing.JLabel lblADate1;
    private javax.swing.JLabel lblATime;
    private javax.swing.JLabel lblATime1;
    private javax.swing.JLabel lblAppointmentRecieptAge;
    private javax.swing.JLabel lblAppointmentRecieptAgeTag;
    private javax.swing.JLabel lblAppointmentRecieptAmountPaid;
    private javax.swing.JLabel lblAppointmentRecieptAmountPaidTag;
    private javax.swing.JLabel lblAppointmentRecieptAppointmentDate;
    private javax.swing.JLabel lblAppointmentRecieptBackIcon;
    private javax.swing.JLabel lblAppointmentRecieptBillNo;
    private javax.swing.JLabel lblAppointmentRecieptBillNoTag;
    private javax.swing.JLabel lblAppointmentRecieptCTax;
    private javax.swing.JLabel lblAppointmentRecieptCTaxTag;
    private javax.swing.JLabel lblAppointmentRecieptConChrg;
    private javax.swing.JLabel lblAppointmentRecieptConChrgTag;
    private javax.swing.JLabel lblAppointmentRecieptDate;
    private javax.swing.JLabel lblAppointmentRecieptDateTag;
    private javax.swing.JLabel lblAppointmentRecieptDocName;
    private javax.swing.JLabel lblAppointmentRecieptDocSpec;
    private javax.swing.JLabel lblAppointmentRecieptKin;
    private javax.swing.JLabel lblAppointmentRecieptKinTag;
    private javax.swing.JLabel lblAppointmentRecieptLogo;
    private javax.swing.JLabel lblAppointmentRecieptName;
    private javax.swing.JLabel lblAppointmentRecieptNameTag;
    private javax.swing.JLabel lblAppointmentRecieptPrintIcon;
    private javax.swing.JLabel lblAppointmentRecieptRecepTag;
    private javax.swing.JLabel lblAppointmentRecieptSTax;
    private javax.swing.JLabel lblAppointmentRecieptSTaxTag;
    private javax.swing.JLabel lblAppointmentRecieptSex;
    private javax.swing.JLabel lblAppointmentRecieptSexTag;
    private javax.swing.JLabel lblBAppointmentInvalidDate;
    private javax.swing.JLabel lblBAppointmentMandatory1;
    private javax.swing.JLabel lblCAppointmentMandatory;
    private javax.swing.JLabel lblConsultancyPSearchIcon;
    private javax.swing.JLabel lblDepartment;
    private javax.swing.JLabel lblDepartment1;
    private javax.swing.JLabel lblDocName;
    private javax.swing.JLabel lblDocName1;
    private javax.swing.JLabel lblIndoorPSearchIcon;
    private javax.swing.JLabel lblLabPSearchIcon;
    private javax.swing.JLabel lblManageExistingIDWarning;
    private javax.swing.JLabel lblPDAddInvalidDate;
    private javax.swing.JLabel lblPDAddMandatory;
    private javax.swing.JLabel lblPatientID;
    private javax.swing.JLabel lblPatientID1;
    private javax.swing.JLabel lblPhnNum;
    private javax.swing.JLabel lblUserAppointmentback;
    private javax.swing.JLabel lblUserFrontDash;
    private javax.swing.JLabel lblUserFrontHns;
    private javax.swing.JLabel lblUserFrontIcon;
    private javax.swing.JLabel lblUserFrontLogout;
    private javax.swing.JLabel lblUserFrontSettings;
    private javax.swing.JLabel lblUserFrontUname;
    private javax.swing.JLabel lblUserManageIDback;
    private javax.swing.JLabel lblUserViewBillsBack;
    private javax.swing.JLabel lblUsermanageIDAddNewBloodGrpTag;
    private javax.swing.JLabel lblUsermanageIDAddNewCityTag;
    private javax.swing.JLabel lblUsermanageIDAddNewContactTag;
    private javax.swing.JLabel lblUsermanageIDAddNewDobTag;
    private javax.swing.JLabel lblUsermanageIDAddNewGenderTag;
    private javax.swing.JLabel lblUsermanageIDAddNewKinTag;
    private javax.swing.JLabel lblUsermanageIDAddNewNameTag;
    private javax.swing.JLabel lblUsermanageIDAddNewStateTag;
    private javax.swing.JLabel lblUsermanageIDAddNewStateTag1;
    private javax.swing.JLabel lblUsermanageIDAddNewStreetTag;
    private javax.swing.JLabel lblUsermanageIDExistingSelID;
    private javax.swing.JLabel lblUsermanageIDExistingSelID1;
    private keeptoo.KGradientPanel markAddID;
    private keeptoo.KGradientPanel markBAppointment;
    private keeptoo.KGradientPanel markCAppointment;
    private keeptoo.KGradientPanel markConcBill;
    private keeptoo.KGradientPanel markDash;
    private keeptoo.KGradientPanel markExistingID;
    private keeptoo.KGradientPanel markHelp;
    private keeptoo.KGradientPanel markIndoorBill;
    private keeptoo.KGradientPanel markLabBill;
    private keeptoo.KGradientPanel markSettings;
    private javax.swing.JPanel pnlApointmentReciept;
    private javax.swing.JPanel pnlAppointmentReceiptContainer;
    private javax.swing.JPanel pnlAppointmentRecieptContainer;
    private javax.swing.JPanel pnlBAppointment;
    private javax.swing.JPanel pnlCAppointment;
    private javax.swing.JPanel pnlUserAppointmentContainer;
    private javax.swing.JPanel pnlUserAppointments;
    private javax.swing.JPanel pnlUserDashCard;
    private javax.swing.JPanel pnlUserFrontContainer;
    private javax.swing.JPanel pnlUserManageIDContainer;
    private javax.swing.JPanel pnlUserManageIdCard;
    private javax.swing.JPanel pnlUserViewBills;
    private javax.swing.JPanel pnlUserViewBillsContainer;
    private javax.swing.JPanel pnlUsermanageIDAddNew;
    private javax.swing.JPanel pnlUsermanageIDExisting;
    private javax.swing.JPanel pnlViewConsultancyBills;
    private javax.swing.JPanel pnlViewIndoorBills;
    private javax.swing.JPanel pnlViewLabBills;
    private javax.swing.JScrollPane spConsultancyBill;
    private javax.swing.JScrollPane spIndoorBill;
    private javax.swing.JScrollPane spLabBill;
    private javax.swing.JTable tblConsultancyBill;
    private javax.swing.JTable tblIndoorBill;
    private javax.swing.JTable tblLabBill;
    private javax.swing.JTextField txtPhnNum;
    private javax.swing.JTextField txtUsermanageIDAddEmail;
    private javax.swing.JTextField txtUsermanageIDAddNewContact;
    private javax.swing.JTextField txtUsermanageIDAddNewName;
    private javax.swing.JTextField txtUsermanageIDAddNewStreet;
    private javax.swing.JTextField txtUsermanageIDExistingIDEnter;
    // End of variables declaration//GEN-END:variables
}
