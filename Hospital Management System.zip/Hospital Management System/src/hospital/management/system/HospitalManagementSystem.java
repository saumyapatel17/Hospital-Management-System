/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital.management.system;
import Front_Page.*;
import java.awt.Color;
import java.awt.Font;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author HP
 */
public class HospitalManagementSystem extends javax.swing.JFrame {
    
    
   
    public static Connection DB_Link()
    {
        Connection con=null;
        try {
            String host="jdbc:derby:upsn_hospital";
            String uname="upsn";
            String upass="upsn";
            
            
            con=DriverManager.getConnection(host, uname, upass);
            
        } catch (SQLException ex) {
            Logger.getLogger(HospitalManagementSystem.class.getName()).log(Level.SEVERE, null, ex);
        }
    return con;
    
    
    }
    
    public static String Age_calc(String dob,String today)
	    {
	    String age;
	        String[] dob_array_s=(dob.split("-"));
	    String[] today_array_s=(today.split("-"));
	    int[] dob_array_i= new int[3];
	    int[] today_array_i= new int[3];
	    for(int i=0;i<dob_array_s.length;i++)
	    {
	    dob_array_i[i]=Integer.parseInt(dob_array_s[i]);
	    today_array_i[i]=Integer.parseInt(today_array_s[i]);
	    
	    }
	    
	    int year_diff=today_array_i[2]-dob_array_i[2];
	    int mnth_diff=today_array_i[1]-dob_array_i[1];
	    if (mnth_diff<0)
	    {
	    	
	    	mnth_diff=12+mnth_diff;
	    	
	    }
	    int day_diff=today_array_i[0]-dob_array_i[0];
	    if (day_diff<0)
	    {
	    	
	    	day_diff=31+day_diff;
	    	
	    }
	    if(today_array_i[1]<dob_array_i[1])
	    {
	    year_diff=year_diff-1;
	    
	    }
	    else
	    {
	    if(today_array_i[0]<dob_array_i[0])
	    {
	    year_diff=year_diff-1;
	    }
	    else
	    {
	    year_diff=year_diff;
	    }
	    
	    }
	    
	  
	    if (year_diff==0)
	    {
	        if(mnth_diff==0)
	        {
	        if (day_diff==0)
	        {
	        age="1 Day";
	        
	        }
	        else
	        {
	        age=String.valueOf(day_diff)+" Days";
	        }
	        
	        }
	        else if (mnth_diff==0 | mnth_diff==1)
	        {
	        age="1 Month";
	        }
	        else
	        {
	        age=String.valueOf(mnth_diff)+" Months";
	        }
	        
	    }
	    else if (year_diff==1)
	    {
	    age="1 Year";
	    }
	    else{
	    	age=String.valueOf(year_diff)+" Years";	    
	    }
	        return age;
	    }
    
    public static int days(String admit_date,String discharge_date)
    {

        long diffDays = ChronoUnit.DAYS.between(LocalDate.parse(admit_date),LocalDate.parse(discharge_date) );
        return (int)diffDays;
    
    }
    
    
    public static void customtable(JTable table)
    {
    
    ((DefaultTableCellRenderer)table.getTableHeader().getDefaultRenderer()).setHorizontalAlignment(JLabel.CENTER);
            DefaultTableCellRenderer cellren = new DefaultTableCellRenderer();
            cellren.setHorizontalAlignment(JLabel.CENTER);
            for(int i = 0 ; i < table.getColumnCount() ; i++){
                table.getColumnModel().getColumn(i).setCellRenderer(cellren);
            }
            table.getTableHeader().setForeground(new Color(255,255,255));
            table.getTableHeader().setBackground(new Color(0,102,102));
            table.getTableHeader().setFont(new Font("Bahnschrift", Font.BOLD,18));
            table.getTableHeader().setSize(771, 30);
            table.getTableHeader().setOpaque(false);
            table.setRowHeight(25);
            table.setFont(new Font("Bahnschrift", Font.PLAIN,14));
            table.setSelectionBackground(new Color(102,102,255));
    
    }
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Front_Page().setVisible(true);
    }
    
}
